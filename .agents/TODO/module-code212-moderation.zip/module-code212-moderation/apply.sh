#!/usr/bin/env bash
#
# Intégration du module « Espace workspaces modérateur » dans Code212 Quest.
#
#   ./apply.sh [RACINE_DU_PROJET] [DOSSIER_DU_MODULE]
#
# Par défaut : RACINE_DU_PROJET = répertoire courant, DOSSIER_DU_MODULE = dossier du script.
# Le script est idempotent : le rejouer sur un projet déjà intégré ne modifie rien
# et ne laisse aucun fichier .rej dans le dépôt.

set -euo pipefail

MODULE_DIR="${2:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
TARGET="${1:-$PWD}"

if [ ! -d "$TARGET/apps/web" ] || [ ! -d "$TARGET/apps/api" ]; then
  echo "ERREUR : '$TARGET' ne ressemble pas à un dépôt Code212 Quest (apps/web et apps/api attendus)." >&2
  exit 1
fi

if ! command -v patch >/dev/null 2>&1; then
  echo "ERREUR : l'outil 'patch' est introuvable. Installez 'patch' ou appliquez les diffs à la main." >&2
  exit 1
fi

echo "=============================================================="
echo " Intégration du module « Espace workspaces modérateur »"
echo " Module  : $MODULE_DIR"
echo " Cible   : $TARGET"
echo "=============================================================="

# ---------------------------------------------------------------- 1. copie
echo ""
echo "[1/2] Copie des fichiers nouveaux"
copied=0
while IFS= read -r -d '' f; do
  rel="${f#$MODULE_DIR/new-files/}"
  mkdir -p "$TARGET/$(dirname "$rel")"
  cp "$f" "$TARGET/$rel"
  echo "      + $rel"
  copied=$((copied+1))
done < <(find "$MODULE_DIR/new-files" -type f -print0)
echo "      $copied fichier(s) copié(s)"

# ---------------------------------------------------------------- 2. patchs
echo ""
echo "[2/2] Application des patchs sur les fichiers existants"
applied=0
skipped=0
for p in "$MODULE_DIR"/patches/*.patch; do
  [ -e "$p" ] || continue
  name="$(basename "$p")"
  if patch -p1 --forward --batch --silent -d "$TARGET" < "$p"; then
    echo "      OK   $name"
    applied=$((applied+1))
  else
    # Soit le module est déjà intégré, soit le contexte a changé.
    # On conserve le motif dans le rapport mais on ne laisse pas de .rej dans le dépôt.
    rejects="$(find "$TARGET" -name '*.rej' -newer "$p" 2>/dev/null | head -3)"
    if [ -n "$rejects" ]; then
      echo "      SKIP $name (déjà appliqué, ou conflit sur : $(echo "$rejects" | tr '\n' ' '))"
    else
      echo "      SKIP $name (déjà appliqué)"
    fi
    find "$TARGET" -name '*.rej' -delete 2>/dev/null || true
    skipped=$((skipped+1))
  fi
done
echo "      $applied patch(s) appliqué(s), $skipped déjà intégré(s)"

echo ""
echo "=============================================================="
echo " Intégration terminée."
echo ""
echo " À faire maintenant :"
echo "   cd $TARGET/apps/web && npm run typecheck && npm run build"
echo "   cd $TARGET/apps/api  && php artisan migrate --seed && php artisan test"
echo "=============================================================="
