# Guide d'intégration — module « Espace workspaces modérateur »

Public visé : un·e développeur·se qui reprend le paquet dans le monorepo
`code212-quest` et qui n'a pas participé à la conception du module.

Durée indicative : 1 journée d'intégration + validation.

---

## 0. Pré-requis

- Node 20+ et npm (front).
- PHP 8.2+ et Composer (API).
- PostgreSQL (la configuration existante du projet convient).
- L'outil `patch` pour l'application automatique des correctifs.

Vérification :

```bash
node -v && npm -v && php -v && composer -V && patch --version | head -1
```

---

## 1. Poser le paquet

```bash
unzip module-code212-moderation.zip -d /tmp/module-code212-moderation
cd /tmp/module-code212-moderation
```

Vérification de l'archive :

```bash
find . -type f | wc -l          # 86 fichiers attendus
ls new-files patches patches/nouveaux-fichiers demo
```

---

## 2. Appliquer le module

```bash
cd /chemin/vers/code212-quest
bash /tmp/module-code212-moderation/apply.sh .
```

Le script :

1. copie les 34 fichiers nouveaux (`new-files/`) à leur place ;
2. applique les 18 patchs (`patches/*.patch`) sur les fichiers existants.

### 2.1 Sortie attendue

```
[1/2] Copie des fichiers nouveaux
      34 fichier(s) copié(s)
[2/2] Application des patchs sur les fichiers existants
      18 patch(s) appliqué(s), 0 déjà intégré(s)
```

Un `SKIP` signale un patch déjà appliqué ou un contexte qui a bougé. Dans les
deux cas, **aucun fichier `.rej` n'est laissé** dans le dépôt : il faut alors
comparer le fichier concerné avec la version du paquet.

### 2.2 Application manuelle (sans `patch`)

Pour chaque fichier listé au § 2.2 du `README.md` :

- les correctifs sont disponibles en lecture seule dans
  `patches/nouveaux-fichiers/` (diff `/dev/null` → fichier) ;
- les modifications de fichiers existants sont dans `patches/` (diff unifié).

```bash
cd /chemin/vers/code212-quest
patch -p1 < /tmp/module-code212-moderation/patches/01-apps-web-src-types-index.patch
```

---

## 3. Front (`apps/web`)

### 3.1 Ce qui arrive

- une nouvelle page `src/pages/moderator/moderator-queue-page.tsx` ;
- trois composants `src/components/moderator/*` ;
- un référentiel `src/lib/moderation.ts` ;
- un troisième espace de travail dans `lib/workspace.tsx`
  (`'student' | 'moderator' | 'admin'`), avec bascule depuis le menu
  « Changer d'espace » de la barre latérale ;
- une entrée de navigation `moderatorNav` dans `lib/navigation.ts` ;
- la route `/moderator/queue` dans `App.tsx` ;
- les types (`types/index.ts`), la façade API (`services/api.ts`), les hooks
  (`hooks/use-api.ts`) et le jeu de données de démonstration
  (`services/mock/*`).

### 3.2 Vérification

```bash
cd apps/web
npm install
npm run typecheck     # attendu : aucune erreur
npm run build         # attendu : build vert
```

### 3.3 Smoke test manuel

```bash
npm run dev
```

- http://localhost:5173/moderator/queue
- les cinq onglets s'affichent et les indicateurs sont cohérents ;
- « Bannir (1–7 j) » ouvre un dialogue, la durée est bornée à 1–7, la date de
  fin s'affiche, la voie de recours est visible ;
- « Escalader » ouvre le dossier à transmettre ;
- « Ouvrir » affiche le dossier complet d'un compte.

> En mode démo (`VITE_USE_MOCK=true`, par défaut) les actions sont appliquées
> en mémoire : un rechargement de page rétablit l'état initial.

---

## 4. API (`apps/api`)

### 4.1 Ce qui arrive

- 8 énumérations métier, un catalogue (`Support/ModerationCatalog.php`), deux
  modèles (`ModerationAction`, `BanRequest`), un service
  (`ModerationService`), deux notifications, une policy, un contrôleur, trois
  form-requests, cinq resources ;
- 4 migrations (`…000042` à `…000045`) ;
- 5 routes sous `/api/v1/moderator/*` et `/api/v1/admin/moderation/*` ;
- une policy appliquée à `ForgeReport`, `ForgeBan` et `BanRequest`.

### 4.2 Migrations

```bash
cd apps/api
composer install
php artisan migrate --seed
```

Les migrations ajoutent des colonnes à `forge_reports` et `forge_bans` et
créent `moderation_actions` et `ban_requests`. La migration `…000044` rend
`forge_bans.category_id` nullable (les sanctions de modération portent leur
rubrique dans `section_slug`).

Point d'attention : la migration `…000045` **recrée** la contrainte de statut
de `forge_reports` (`forge_reports_status_check`) pour ajouter les valeurs
`en_traitement` et `escaladee`. Si la base a été créée hors de Laravel, vérifier
que la contrainte existe au nom attendu avant de migrer.

### 4.3 Tests

```bash
php artisan test --filter=ModeratorQueueTest
```

Les 11 tests couvrent : l'accès par rôle, le filtrage par périmètre, la
journalisation et la notification d'une décision, la borne 1–7 jours, le refus
hors périmètre, la transmission et la notification d'une escalade, l'interdiction
de statuer pour un modérateur, l'exclusion définitive prononcée par la
Direction, la levée d'un bannissement temporaire et l'obligation de motiver.

> Ces tests n'ont **pas** pu être exécutés dans l'environnement de préparation
> (PHP absent). C'est le premier point à valider à l'intégration.

### 4.4 Smoke test manuel

```bash
php artisan serve
```

```bash
# vue d'ensemble (compte moderation avec un perimetre)
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/moderator/queue

# bannissement temporaire de 3 jours
curl -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"decision":"bannir_temporaire","durationDays":3,"note":"Récidive."}' \
  http://localhost:8000/api/v1/moderator/queue/reports/12/resolve

# refus attendu : 8 jours
curl -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"decision":"bannir_temporaire","durationDays":8,"note":"Trop long."}' \
  http://localhost:8000/api/v1/moderator/queue/reports/12/resolve   # -> 422
```

---

## 5. Recette fonctionnelle

Scénario proposé à la Direction :

1. nommer un modérateur sur la rubrique *Entraide* (module « Rôles & accès »,
   onglet « Modérateurs ») ;
2. se connecter avec ce compte → l'espace « Modérateur » apparaît dans le
   menu « Changer d'espace » ;
3. traiter un signalement de la rubrique *Entraide* → vérifier le journal
   (`Suivi & journal`) et le compte concerné ;
4. tenter un traitement hors périmètre → l'action est refusée ;
5. bannir 3 jours → vérifier la date de fin, la notification et la voie de
   recours affichée ;
6. escalader un dossier → vérifier l'apparition dans l'onglet « Escalades » ;
7. côté Direction : statuer sur le dossier → exclusion définitive ou refus ;
8. vérifier que la personne sanctionnée a bien reçu la notification.

---

## 6. Repli

Le module est réversible : conserver une copie de `apps/` avant intégration.
Pour revenir en arrière, appliquer les patchs en sens inverse :

```bash
cd /chemin/vers/code212-quest
for p in /tmp/module-code212-moderation/patches/*.patch; do
  patch -p1 -R --batch --silent < "$p"
done
rm -rf apps/web/src/components/moderator apps/web/src/pages/moderator
rm -f apps/web/src/lib/moderation.ts
```

---

## 7. Points à confirmer avec la Direction

- la durée maximale d'un bannissement temporaire (1–7 jours aujourd'hui) ;
- le délai de traitement cible d'un signalement (48 h aujourd'hui) ;
- la composition exacte de la voie de recours (formulaire dédié ? courriel ?) ;
- la liste des rubriques de La Forge (5 aujourd'hui) ;
- l'accusé de réception obligatoire après une décision.
