# Module « Espace workspaces modérateur » — Code212 Quest

Paquet autonome, prêt à.integration dans le monorepo `code212-quest`
(`apps/web` React + TypeScript, `apps/api` Laravel 11).

> **Ce module est un complément à l'application existante.** Il n'a pas vocation à
> régénérer l'application : il apporte un espace de travail de plus
> (`/moderator/queue`), ses règles de gouvernance, et l'API qui les porte.

---

## 1. Ce que le module apporte

Un **espace de travail « modérateur »** : le compte en charge de la
communauté de La Forge y traite les signalements des rubriques qui lui sont
confiées.

### 1.1 Séparation des pouvoirs (règle structurante)

| Décision | Qui décide | Portée |
|---|---|---|
| Classer sans suite, masquer un contenu, avertir | Modérateur | Rubriques confiées |
| Bannissement **temporaire** (1 à 7 jours) | Modérateur | Rubrique concernée |
| Bannissement **définitif** | **Direction** (administrateur) | Plateforme |
| Lever un bannissement temporaire | Modérateur (sa rubrique) | Rubrique concernée |
| Lever une exclusion définitive | Direction | Plateforme |

Un modérateur **ne prononce jamais** d'exclusion définitive. Il *escalade* le
dossier : la Direction statue. Une escalade n'est pas une sanction — le compte
reste actif tant que la Direction n'a pas décidé.

Aucune sanction automatique : chaque décision est un acte humain, motivé et
journalisé.

### 1.2 La page `/moderator/queue`

Cinq onglets, un indicateur par onglet :

| Onglet | Contenu |
|---|---|
| **File** | Signalements à traiter : contexte, motif, gravité, actions. Filtres (rubriques, statut, gravité, recherche). |
| **Signalés** | Vue globale des comptes signalés : filière, établissement, nombre de signalements, niveau de risque, statut. |
| **Bannis** | Bannissements en vigueur (avec échéance et jours restants) et historique. Lever un bannissement. |
| **Escalades** | Dossiers transmis à la Direction : motif, pièces, priorité, état de la décision. |
| **Suivi & journal** | Niveau de risque par compte + journal complet des décisions de modération. |

Sur la page : 5 indicateurs (en attente, dont hors délai de 48 h ; traités sur
7 jours ; bannissements actifs ; escalades en attente ; comptes signalés) et un
panneau « charge de modération » par rubrique de La Forge.

### 1.3 Actions disponibles sur un signalement

- **Classer sans suite** — accusé de réception, aucune sanction.
- **Masquer** — le contenu est retiré de la rubrique, l'auteur est informé.
- **Avertir** — avertissement écrit, sans sanction.
- **Bannir (1–7 j)** — exclusion temporaire, durée choisie pas à pas, date de
  fin affichée.
- **Escalader** — ouverture d'un dossier de bannissement définitif à l'adresse
  de la Direction (motif, pièces, priorité normale ou haute).

Chaque action demande une **note de modération** : le motif est consigné avec
la décision.

### 1.4 Traçabilité et recours

- **Journal** : chaque décision produit une ligne (`moderation_actions`) —
  qui, quoi, sur qui, dans quelle rubrique, pourquoi. Le journal est visible
  dans l'onglet « Suivi & journal ».
- **Notification** : la personne sanctionnée reçoit une notification qui
  rappelle la décision, la durée, l'échéance et **la voie de recours**.
- **Voie de recours standardisée** (`ModerationCatalog::APPEAL_PATH`,
  `APPEAL_PATH` côté front) : contestation sous 7 jours, examen par un
  administrateur *différent* de celui qui a décidé.

---

## 2. Contenu du paquet

```
module-code212-moderation/
├── README.md                     ce document
├── INTEGRATION.md                guide d'intégration pas à pas
├── apply.sh                      application idempotente (copie + patchs)
├── new-files/                    34 fichiers entièrement nouveaux
│   ├── apps/web/…                page, composants, lib de modération
│   └── apps/api/…                enums, modèles, service, contrôleur,
│                                 policy, notifications, migrations, tests
├── patches/                      18 patchs sur les fichiers existants
│   └── nouveaux-fichiers/        34 diffs /dev/null des fichiers nouveaux
└── demo/                         harnais de démonstration autonome
    └── (Vite + React + Tailwind, données en mémoire, port 5174)
```

### 2.1 Fichiers nouveaux (34)

**Front (`apps/web/src`)**

| Fichier | Rôle |
|---|---|
| `lib/moderation.ts` | Référentiel : motifs, décisions, voie de recours, calcul du niveau de risque, bornes 1–7 j, délai de 48 h. |
| `components/moderator/report-card.tsx` | Carte de signalement + barre d'actions. |
| `components/moderator/risk-badge.tsx` | Badges de risque / statut / gravité + dossier complet d'un compte. |
| `components/moderator/sanction-dialog.tsx` | Dialogue de bannissement temporaire (1–7 j) + dialogue d'escalade. |
| `pages/moderator/moderator-queue-page.tsx` | La page `/moderator/queue` (5 onglets). |

**API (`apps/api`)**

| Fichier | Rôle |
|---|---|
| `app/Enums/{ModerationMotif,ModerationSeverity,ModerationDecision,ModerationRiskLevel,ModerationStatus,BanType,EscalationStatus,EscalationPriority}.php` | États et vocabulaire métier. |
| `app/Support/ModerationCatalog.php` | Source de vérité serveur : motifs, décisions, voie de recours, bornes. |
| `app/Models/ModerationAction.php` | Journal des décisions. |
| `app/Models/BanRequest.php` | Dossier d'exclusion définitive (escalade). |
| `app/Services/ModerationService.php` | Règles métier : périmètre, bornes, journalisation, notifications. |
| `app/Notifications/{ModerationDecisionNotification,BanEscalationNotification}.php` | Notification au sanctionné / à la Direction. |
| `app/Policies/ModeratorQueuePolicy.php` | Autorisations par rôle. |
| `app/Http/Controllers/Api/V1/Moderator/ModeratorQueueController.php` | 5 points d'entrée. |
| `app/Http/Requests/{ResolveModerationReportRequest,EscalateBanRequest,DecideBanEscalationRequest}.php` | Validation (dont la borne 1–7 j côté serveur). |
| `app/Http/Resources/{ModerationReportResource,ModerationBanResource,BanEscalationResource,ModerationActionResource,ModeratorQueueResource}.php` | Sérialisation (camelCase). |
| `database/migrations/2024_01_01_000042…000045` | `moderation_actions`, `ban_requests`, extensions de `forge_bans` et `forge_reports`. |
| `tests/Feature/ModeratorQueueTest.php` | 11 tests de feature. |

### 2.2 Fichiers modifiés (18)

**Front** — `types/index.ts`, `lib/utils.ts`, `lib/workspace.tsx`,
`lib/navigation.ts`, `components/layout/{sidebar,topbar,app-shell}.tsx`,
`components/ui/toast.tsx`, `services/api.ts`, `services/mock/db.ts`,
`services/mock/server.ts`, `hooks/use-api.ts`, `App.tsx`.

**API** — `app/Enums/ForgeReportStatus.php`, `app/Models/ForgeReport.php`,
`app/Models/ForgeBan.php`, `app/Providers/AppServiceProvider.php`,
`routes/api.php`.

> Le catalogue de permissions (`PermissionCatalog` / `lib/permissions.ts`) **n'est
> pas modifié** : l'accès à l'espace passe par le rôle `moderator` et par le
> périmètre de rubrique. Les deux modules restent indépendants.

---

## 3. Modèle de données

```
forge_reports        + motif, severity, section_slug, resolution_decision,
                       handled_by, handled_at
forge_bans           + type (temporaire|definitif), scope (rubrique|plateforme),
                       section_slug, duration_days, appeal_path, notified_at, source
                       (category_id devient nullable)
moderation_actions   NOUVEAU  — journal des décisions
                       (actor, action, cible, section, note, métadonnées)
ban_requests         NOUVEAU  — dossiers d'exclusion définitive
                       (demandeur, motif, pièces, priorité, état, décision)
```

`moderator_scopes` (issu du module « Rôles & accès ») porte le périmètre :
la liste des rubriques confiées au compte.

---

## 4. API

Toutes les routes sont sous `/api/v1` et exigent une authentification Sanctum.

| Méthode | Route | Rôle | Accès |
|---|---|---|---|
| `GET` | `/moderator/queue` | Vue d'ensemble (filtre sur le périmètre) | `moderator` / `admin` |
| `POST` | `/moderator/queue/reports/{report}/resolve` | Traiter un signalement | `moderator` / `admin` |
| `POST` | `/moderator/queue/escalations` | Transmettre un dossier à la Direction | `moderator` / `admin` |
| `DELETE` | `/moderator/queue/bans/{ban}` | Lever un bannissement | `moderator` (temporaire) / `admin` |
| `POST` | `/admin/moderation/escalations/{banRequest}/decide` | Statuer sur une escalade | `admin` |

Payloads :

```jsonc
// POST /moderator/queue/reports/12/resolve
{ "decision": "bannir_temporaire", "durationDays": 3, "note": "Récidive." }
// decision ∈ classer_sans_suite | masquer_contenu | avertir_auteur | bannir_temporaire

// POST /moderator/queue/escalations
{ "userId": 42, "section": "entraide", "reason": "…", "evidence": "…",
  "reportIds": [12, 18], "priority": "haute" }

// DELETE /moderator/queue/bans/7   (body)
{ "note": "Recours accepté." }
```

---

## 5. Installation

```bash
bash apply.sh /chemin/vers/code212-quest

cd /chemin/vers/code212-quest/apps/web
npm install && npm run typecheck && npm run build

cd ../api
composer install
php artisan migrate --seed
php artisan test
```

`apply.sh` est **idempotent** : le rejouer ne modifie rien et ne laisse aucun
`.rej`. Les patchs ont été vérifiés en rejouant l'intégration depuis l'état
« avant » et en comparant le résultat **octet par octet** avec l'état cible.

---

## 6. Harnais de démonstration

```bash
cd demo
npm install
npm run dev      # http://localhost:5174
```

Le harnais contient **la page exacte du livrable**, avec l'adaptateur de
démonstration (données en mémoire). Il permet de faire valider le
comportement sans backend : les cinq onglets, le bannissement temporaire, le
dossier d'un compte, l'escalade, la levée d'un bannissement.

---

## 7. Limites connues

- **Le code Laravel n'a pas pu être exécuté** dans l'environnement de
  préparation (PHP absent) : les tests `ModeratorQueueTest` sont écrits mais
  **doivent être lancés** par l'intégrateur (`php artisan test`).
- Le harnais de démonstration utilise un jeu de données fictif ; aucun compte
  réel n'est concerné.
- Les notifications sont envoyées par courriel (`mail`). Le canal « base » ou
  l'application mobile restent à brancher.
- Le suivi d'activité des comptes (`lastActivityAt`) s'appuie sur
  `users.last_login_at` ; un journal d'activité plus fin reste à définir.
