/**
 * Client HTTP vers l'API Laravel `/api/v1`.
 *
 * En mode démo (`VITE_USE_MOCK=true`, défaut) les appels sont servis par
 * `services/mock/server.ts` avec la même signature de payload.
 */
import { mockApi } from './mock/server'

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL as string | undefined)?.replace(/\/$/, '') ?? '/api/v1'

/** `true` tant que le backend Laravel n'est pas branché. */
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly errors?: Record<string, string[]>,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...init?.headers,
    },
    credentials: 'include',
  })

  if (!response.ok) {
    const payload = await response.json().catch(() => null)
    throw new ApiError(
      payload?.message ?? `Erreur ${response.status} — ${response.statusText}`,
      response.status,
      payload?.errors,
    )
  }

  if (response.status === 204) return undefined as T
  return (await response.json()) as T
}

export const http = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PATCH', body: body === undefined ? undefined : JSON.stringify(body) }),
  put: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PUT', body: body === undefined ? undefined : JSON.stringify(body) }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
}

/* ------------------------------------------------------------------ facade */

/**
 * Point d'entrée unique pour l'application. Les composants n'appellent jamais
 * `http` ni `mockApi` directement : ils utilisent `api.*`.
 */
export const api = {
  // apprenant
  me: () => (USE_MOCK ? mockApi.getMe() : http.get<import('@/types').UserProfile>('/me')),
  dashboard: () => (USE_MOCK ? mockApi.getDashboard() : http.get<import('@/types').DashboardData>('/dashboard')),
  updateProfile: (patch: Parameters<typeof mockApi.updateProfile>[0]) =>
    USE_MOCK ? mockApi.updateProfile(patch) : http.patch<import('@/types').UserProfile>('/me', patch),

  // quêtes
  quests: (params?: Record<string, string | undefined>) =>
    USE_MOCK
      ? mockApi.getQuests(params)
      : http.get<import('@/types').Quest[]>(`/quests${qs(params)}`),
  quest: (id: number) => (USE_MOCK ? mockApi.getQuest(id) : http.get<import('@/types').Quest>(`/quests/${id}`)),
  enrollQuest: (id: number) => (USE_MOCK ? mockApi.enrollQuest(id) : http.post<import('@/types').Quest>(`/quests/${id}/enroll`)),
  submitStep: (questId: number, stepId: number, content: string) =>
    USE_MOCK
      ? mockApi.submitStep(questId, stepId, content)
      : http.post<{ status: string; xpAwarded: number }>(`/quests/${questId}/steps/${stepId}/submit`, { content }),

  // progression
  ledger: () => (USE_MOCK ? mockApi.getLedger() : http.get<import('@/types').LedgerEntry[]>('/ledger')),
  leaderboard: (period: string) =>
    USE_MOCK ? mockApi.getLeaderboard(period) : http.get<import('@/types').LeaderboardEntry[]>(`/leaderboards?period=${period}`),
  levels: () => (USE_MOCK ? mockApi.getLevels() : http.get<import('@/types').LevelConfig[]>('/levels')),
  tracks: () => (USE_MOCK ? mockApi.getTracks() : http.get<import('@/types').Track[]>('/tracks')),
  badges: () => (USE_MOCK ? mockApi.getBadges() : http.get<import('@/types').Badge[]>('/badges')),
  paths: () => (USE_MOCK ? mockApi.getPaths() : http.get<import('@/types').LearningPath[]>('/paths')),
  missions: () => (USE_MOCK ? mockApi.getMissions() : http.get<import('@/types').Mission[]>('/missions')),
  claimMission: (id: number) => (USE_MOCK ? mockApi.claimMission(id) : http.post<import('@/types').Mission>(`/missions/${id}/claim`)),
  certifications: () => (USE_MOCK ? mockApi.getCertifications() : http.get<import('@/types').Certification[]>('/certifications')),

  // compétitions
  challenges: () => (USE_MOCK ? mockApi.getChallenges() : http.get<import('@/types').Challenge[]>('/challenges')),
  joinChallenge: (id: number) => (USE_MOCK ? mockApi.joinChallenge(id) : http.post<import('@/types').Challenge>(`/challenges/${id}/join`)),

  // boutique
  rewards: () => (USE_MOCK ? mockApi.getRewards() : http.get<import('@/types').Reward[]>('/rewards')),
  purchaseReward: (id: number) =>
    USE_MOCK ? mockApi.purchaseReward(id) : http.post<{ order: import('@/types').RewardOrder; balance: number }>(`/rewards/${id}/purchase`),

  // La Forge
  forgeCategories: () => (USE_MOCK ? mockApi.getForgeCategories() : http.get<import('@/types').ForgeCategory[]>('/forge/categories')),
  forgeThreads: (category?: string) =>
    USE_MOCK ? mockApi.getForgeThreads(category) : http.get<import('@/types').ForgeThread[]>(`/forge/threads${category ? `?category=${category}` : ''}`),
  forgeThread: (id: number) =>
    USE_MOCK
      ? mockApi.getForgeThread(id)
      : http.get<{ thread: import('@/types').ForgeThread; solutions: import('@/types').ForgeSolution[] }>(`/forge/threads/${id}`),
  createThread: (payload: { category: string; title: string; body: string; tags: string[] }) =>
    USE_MOCK ? mockApi.createThread(payload) : http.post<import('@/types').ForgeThread>('/forge/threads', payload),
  replyToThread: (threadId: number, body: string) =>
    USE_MOCK ? mockApi.replyToThread(threadId, body) : http.post<import('@/types').ForgeSolution>(`/forge/threads/${threadId}/replies`, { body }),
  acceptSolution: (threadId: number, solutionId: number) =>
    USE_MOCK ? mockApi.acceptSolution(threadId, solutionId) : http.post<import('@/types').ForgeSolution>(`/forge/solutions/${solutionId}/accept`),
  toggleLikeThread: (id: number) =>
    USE_MOCK ? mockApi.toggleLikeThread(id) : http.post<{ likes: number; liked: boolean }>(`/forge/threads/${id}/like`),
  reportThread: (threadId: number, reason: string) =>
    USE_MOCK ? mockApi.reportThread(threadId, reason) : http.post(`/forge/threads/${threadId}/report`, { reason }),

  // administration
  adminOverview: () => (USE_MOCK ? mockApi.getAdminOverview() : http.get<import('@/types').AdminOverview>('/admin/analytics')),
  adminSubmissions: () => (USE_MOCK ? mockApi.getAdminSubmissions() : http.get<import('@/types').Submission[]>('/admin/submissions')),
  reviewSubmission: (id: number, decision: 'validee' | 'rejetee', feedback: string) =>
    USE_MOCK
      ? mockApi.reviewSubmission(id, decision, feedback)
      : http.post<import('@/types').Submission>(`/admin/submissions/${id}/review`, { decision, feedback }),
  adminRules: () => (USE_MOCK ? mockApi.getAdminRules() : http.get<import('@/types').XpRule[]>('/admin/rules/xp')),
  updateRule: (id: number, patch: Partial<import('@/types').XpRule>) =>
    USE_MOCK ? mockApi.updateRule(id, patch) : http.patch<import('@/types').XpRule>(`/admin/rules/xp/${id}`, patch),
  adminOrders: () => (USE_MOCK ? mockApi.getAdminOrders() : http.get<import('@/types').RewardOrder[]>('/admin/orders')),
  updateOrder: (id: number, status: import('@/types').RewardOrder['status']) =>
    USE_MOCK ? mockApi.updateOrder(id, status) : http.patch<import('@/types').RewardOrder>(`/admin/orders/${id}`, { status }),
  adminStudents: () =>
    USE_MOCK ? mockApi.getAdminStudents() : http.get<Awaited<ReturnType<typeof mockApi.getAdminStudents>>>('/admin/students'),

  /* ------------------------------------------- gestion des rôles & accès */
  adminRoles: () =>
    USE_MOCK ? mockApi.getAdminRoles() : http.get<import('@/types').Role[]>('/admin/roles'),
  createRole: (payload: { name: string; description: string; color: string; permissions: string[] }) =>
    USE_MOCK
      ? mockApi.createRole(payload)
      : http.post<import('@/types').Role>('/admin/roles', payload),
  updateRole: (
    id: number,
    patch: { name?: string; description?: string; color?: string; permissions?: string[] },
  ) =>
    USE_MOCK
      ? mockApi.updateRole(id, patch)
      : http.patch<import('@/types').Role>(`/admin/roles/${id}`, patch),
  duplicateRole: (id: number) =>
    USE_MOCK ? mockApi.duplicateRole(id) : http.post<import('@/types').Role>(`/admin/roles/${id}/duplicate`),
  revokeRole: (id: number) =>
    USE_MOCK ? mockApi.revokeRole(id) : http.post<import('@/types').Role>(`/admin/roles/${id}/revoke`),
  deleteRole: (id: number) =>
    USE_MOCK ? mockApi.deleteRole(id) : http.delete<void>(`/admin/roles/${id}`),
  adminRoleAssignments: () =>
    USE_MOCK ? mockApi.getAdminRoleAssignments() : http.get<import('@/types').RoleAssignment[]>('/admin/role-assignments'),
  assignRole: (payload: { email: string; roleCode: string; reason: string; expiresAt?: string | null }) =>
    USE_MOCK
      ? mockApi.assignRole(payload)
      : http.post<import('@/types').RoleAssignment>('/admin/role-assignments', payload),
  unassignRole: (id: number) =>
    USE_MOCK ? mockApi.unassignRole(id) : http.delete<void>(`/admin/role-assignments/${id}`),
  adminModerators: () =>
    USE_MOCK ? mockApi.getAdminModerators() : http.get<import('@/types').ModeratorAssignment[]>('/admin/moderators'),
  assignModerator: (payload: { email: string; sections: string[]; note: string; expiresAt?: string | null }) =>
    USE_MOCK
      ? mockApi.assignModerator(payload)
      : http.post<import('@/types').ModeratorAssignment>('/admin/moderators', payload),
  revokeModerator: (id: number) =>
    USE_MOCK ? mockApi.revokeModerator(id) : http.delete<void>(`/admin/moderators/${id}`),
  adminManagedUsers: () =>
    USE_MOCK ? mockApi.getAdminManagedUsers() : http.get<import('@/types').ManagedUser[]>('/admin/users'),
  updateManagedUserStatus: (id: number, status: import('@/types').ManagedUserStatus) =>
    USE_MOCK
      ? mockApi.updateManagedUserStatus(id, status)
      : http.patch<import('@/types').ManagedUser>(`/admin/users/${id}/status`, { status }),
  roleAudit: () =>
    USE_MOCK ? mockApi.getRoleAudit() : http.get<import('@/types').RoleAuditEvent[]>('/admin/role-audit'),

  /* -------------------------------------------- espace workspaces moderation */
  moderationOverview: () =>
    USE_MOCK
      ? mockApi.getModerationOverview()
      : http.get<import('@/types').ModerationOverview>('/moderator/queue'),
  resolveModerationReport: (
    id: number,
    payload: { decision: string; note: string; durationDays?: number; section?: string },
  ) =>
    USE_MOCK
      ? mockApi.resolveModerationReport(id, payload)
      : http.post<import('@/types').ModerationReport>(`/moderator/queue/reports/${id}/resolve`, payload),
  escalateBan: (payload: {
    userId: number
    section: string
    reason: string
    evidence: string
    reportIds: number[]
    priority: 'normale' | 'haute'
  }) =>
    USE_MOCK
      ? mockApi.escalateToDirection(payload)
      : http.post<import('@/types').BanEscalation>('/moderator/queue/escalations', payload),
  revokeModerationBan: (id: number, note: string) =>
    USE_MOCK
      ? mockApi.revokeModerationBan(id, note)
      : http.delete<import('@/types').ModerationBan>(`/moderator/queue/bans/${id}`),
}

function qs(params?: Record<string, string | undefined>) {
  if (!params) return ''
  const search = new URLSearchParams()
  Object.entries(params).forEach(([key, value]) => {
    if (value && value !== 'all') search.set(key, value)
  })
  const str = search.toString()
  return str ? `?${str}` : ''
}
