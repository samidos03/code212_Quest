import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  Activity,
  ArrowUpRight,
  Ban,
  Clock,
  FileClock,
  Flag,
  Gavel,
  Inbox,
  ShieldAlert,
  ShieldCheck,
  Users,
} from 'lucide-react'
import { PageHeader, SectionHeading } from '@/components/shared/page-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { useToast } from '@/components/ui/toast'
import { ReportCard } from '@/components/moderator/report-card'
import {
  ModerationStatusBadge,
  RiskBadge,
  UserDossierDialog,
} from '@/components/moderator/risk-badge'
import {
  EscalationDialog,
  TemporaryBanDialog,
  type BanSubject,
} from '@/components/moderator/sanction-dialog'
import { useModerationOverview, useRevokeModerationBan } from '@/hooks/use-api'
import { DECISION_LABEL, MOTIF_LABEL } from '@/lib/moderation'
import { FORGE_SECTION_LABEL } from '@/lib/permissions'
import { cn, formatDate, formatRelative, initials } from '@/lib/utils'
import type { ModerationBan, ModerationReport, ReportedUser } from '@/types'

/**
 * Espace modérateur — file de modération.
 *
 * Périmètre : le modérateur traite les signalements des rubriques qui lui sont
 * confiées. Il peut appliquer un bannissement temporaire (1 à 7 jours) ; le
 * bannissement définitif reste une décision de la Direction, atteinte par
 * escalade. Chaque décision est journalisée, notifiée, et la voie de recours
 * est communiquée à la personne concernée.
 */
export function ModeratorQueuePage() {
  const { data, isLoading } = useModerationOverview()
  const { toast } = useToast()
  const revoke = useRevokeModerationBan()

  const [searchParams, setSearchParams] = useSearchParams()
  const tab = searchParams.get('tab') ?? 'file'
  const setTab = (next: string) => {
    const params = new URLSearchParams(searchParams)
    params.set('tab', next)
    setSearchParams(params, { replace: true })
  }
  const [scope, setScope] = useState<'mine' | 'all'>('mine')
  const [statusFilter, setStatusFilter] = useState('all')
  const [severityFilter, setSeverityFilter] = useState('all')
  const [search, setSearch] = useState('')

  const [banSubject, setBanSubject] = useState<BanSubject | null>(null)
  const [escalation, setEscalation] = useState<{
    user: ReportedUser
    section: string
    reportIds: number[]
  } | null>(null)
  const [dossier, setDossier] = useState<ReportedUser | null>(null)

  const reports = data?.reports ?? []
  const users = data?.users ?? []
  const bans = data?.bans ?? []
  const escalations = data?.escalations ?? []
  const actions = data?.actions ?? []
  const sections = data?.sections ?? []
  const stats = data?.stats

  const mySections = sections.filter((s) => s.mine)

  const subjectOf = (report: ModerationReport): BanSubject => ({
    userId: report.authorId,
    userName: report.authorName,
    userPseudonym: report.authorPseudonym,
    section: report.section,
    reportId: report.id,
  })

  /* ------------------------------------------------------------- filtres */

  const filteredReports = useMemo(() => {
    const q = search.trim().toLowerCase()
    return reports.filter((report) => {
      const inScope = scope === 'all' || mySections.some((s) => s.slug === report.section)
      const inStatus =
        statusFilter === 'all' ||
        (statusFilter === 'en_cours'
          ? report.status === 'ouverte' || report.status === 'en_traitement'
          : report.status === statusFilter)
      const inSeverity = severityFilter === 'all' || report.severity === severityFilter
      const inSearch =
        !q ||
        `${report.title} ${report.excerpt} ${report.authorName} ${report.reporterName} ${MOTIF_LABEL[report.motif]}`
          .toLowerCase()
          .includes(q)
      return inScope && inStatus && inSeverity && inSearch
    })
  }, [reports, scope, statusFilter, severityFilter, search, mySections])

  const filteredUsers = useMemo(() => {
    const q = search.trim().toLowerCase()
    return users.filter(
      (user) =>
        !q ||
        `${user.fullName} ${user.pseudonym} ${user.program} ${user.school} ${user.email}`
          .toLowerCase()
          .includes(q),
    )
  }, [users, search])

  const activeBans = bans.filter(
    (b) => b.revokedAt === null && (b.expiresAt === null || new Date(b.expiresAt) > new Date()),
  )
  const pastBans = bans.filter((b) => !activeBans.includes(b))

  const handleRevoke = async (ban: ModerationBan) => {
    try {
      await revoke.mutateAsync({ id: ban.id, note: 'Bannissement levé sur recours.' })
      toast('Bannissement levé', {
        description: 'La personne concernée a été informée et la décision est journalisée.',
        kind: 'success',
      })
    } catch (error) {
      toast('Levée impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-32" />
        ))}
      </div>
    )
  }

  return (
    <div>
      <PageHeader
        kicker="Espace modérateur · La Forge"
        title="File de modération"
        description="Vous traiter les signalements des rubriques qui vous sont confiées. Le bannissement temporaire vous revient ; le bannissement définitif est décidé par la Direction."
        actions={
          <div className="flex flex-wrap gap-2">
            <Badge variant="danger">
              <Flag className="h-3 w-3" /> {stats?.pending ?? 0} en attente
            </Badge>
            {mySections.length > 0 && (
              <Badge variant="cyan">
                <ShieldCheck className="h-3 w-3" />
                {mySections.map((s) => s.label).join(' · ')}
              </Badge>
            )}
          </div>
        }
      />

      {/* ------------------------------------------------------ indicateurs */}
      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[
          {
            icon: <Inbox className="h-4 w-4" />,
            label: 'En attente',
            value: String(stats?.pending ?? 0),
            note:
              (stats?.urgent ?? 0) > 0
                ? `dont ${stats?.urgent} en retard de plus de 48 h`
                : 'dans le délai de traitement',
            tone: (stats?.urgent ?? 0) > 0 ? 'bg-warning-soft text-warning' : 'bg-surface-3 text-fg-muted',
          },
          {
            icon: <Activity className="h-4 w-4" />,
            label: 'Traités (7 j)',
            value: String(stats?.handled7d ?? 0),
            note: `≈ ${stats?.avgHandlingHours ?? 0} h de délai moyen`,
            tone: 'bg-primary-soft text-primary',
          },
          {
            icon: <Gavel className="h-4 w-4" />,
            label: 'Bannissements actifs',
            value: String(stats?.tempBansActive ?? 0),
            note: 'temporaires, 1 à 7 jours',
            tone: 'bg-danger-soft text-danger',
          },
          {
            icon: <ArrowUpRight className="h-4 w-4" />,
            label: 'Escalades en attente',
            value: String(stats?.escalationsPending ?? 0),
            note: 'dossiers transmis à la Direction',
            tone: 'bg-accent-soft text-accent',
          },
          {
            icon: <Users className="h-4 w-4" />,
            label: 'Comptes signalés',
            value: String(stats?.reportedUsers ?? 0),
            note: 'suivis par la modération',
            tone: 'bg-cyan-soft text-cyan-fg',
          },
        ].map((kpi) => (
          <div key={kpi.label} className="panel p-3.5">
            <span className={cn('grid h-8 w-8 place-items-center rounded-lg', kpi.tone)}>{kpi.icon}</span>
            <p className="mt-2.5 text-[10px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
              {kpi.label}
            </p>
            <p className="mt-0.5 font-display text-[23px] font-bold leading-none text-fg">{kpi.value}</p>
            <p className="mt-1 text-[11px] leading-snug text-fg-muted">{kpi.note}</p>
          </div>
        ))}
      </div>

      {/* --------------------------------------------------------- rubriques */}
      <section className="panel mb-5 p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="kicker">Rubriques de La Forge · charge de modération</p>
          <p className="text-[11.5px] text-fg-subtle">
            Les signalements des rubriques qui ne vous sont pas confiées sont visibles, mais leur
            traitement revient au modérateur désigné.
          </p>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-5">
          {sections.map((section) => (
            <div
              key={section.slug}
              className={cn(
                'rounded-xl border px-3 py-2.5',
                section.mine ? 'border-cyan/35 bg-cyan-soft/40' : 'border-border bg-surface-2',
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <p className="text-[12.5px] font-bold text-fg">{section.label}</p>
                {section.mine && <Badge variant="cyan">Vous</Badge>}
              </div>
              <p className="mt-1 text-[11px] text-fg-subtle">
                {section.pending} en attente · {section.totalReports} au total
              </p>
              <p className="mt-0.5 truncate text-[11px] text-fg-muted">
                {section.moderators.join(', ')}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------ onglets */}
      <div
        data-testid="moderator-tabs"
        className="no-scrollbar mb-5 flex items-center gap-1 overflow-x-auto rounded-xl border border-border bg-surface-2 p-1"
      >
        {[
          { key: 'file', label: 'File', icon: Flag, count: stats?.pending },
          { key: 'signales', label: 'Signalés', icon: Users, count: stats?.reportedUsers },
          { key: 'bannis', label: 'Bannis', icon: Ban, count: activeBans.length },
          { key: 'escalades', label: 'Escalades', icon: ArrowUpRight, count: stats?.escalationsPending },
          { key: 'suivi', label: 'Suivi & journal', icon: FileClock },
        ].map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={cn(
              'inline-flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-[13px] font-semibold transition-all',
              tab === item.key ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
            )}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
            {item.count !== undefined && item.count > 0 && (
              <span className="rounded-full bg-surface-3 px-1.5 text-[10.5px] tabular-nums text-fg-muted">
                {item.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ============================================================ FILE */}
      {tab === 'file' && (
        <div>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="relative min-w-[220px] flex-1">
              <SearchIcon />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Titre, auteur, motif…"
                className="pl-9"
              />
            </div>
            <div className="flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1">
              {(
                [
                  { key: 'mine', label: 'Mes rubriques' },
                  { key: 'all', label: 'Toutes' },
                ] as const
              ).map((item) => (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setScope(item.key)}
                  className={cn(
                    'rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
                    scope === item.key ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[165px]" aria-label="Filtrer par statut">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="en_cours">À traiter</SelectItem>
                <SelectItem value="resolue">Résolues</SelectItem>
                <SelectItem value="rejetee">Rejetées</SelectItem>
                <SelectItem value="escaladee">Escaladées</SelectItem>
              </SelectContent>
            </Select>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-[155px]" aria-label="Filtrer par gravité">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes gravités</SelectItem>
                <SelectItem value="critique">Critique</SelectItem>
                <SelectItem value="elevee">Élevée</SelectItem>
                <SelectItem value="moyenne">Moyenne</SelectItem>
                <SelectItem value="faible">Faible</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="primary">{filteredReports.length} signalements</Badge>
          </div>

          <div className="grid gap-3">
            {filteredReports.length === 0 && (
              <div className="panel px-6 py-14 text-center">
                <ShieldCheck className="mx-auto h-8 w-8 text-success" />
                <p className="mt-3 font-display text-[17px] font-bold text-fg">File vide</p>
                <p className="mt-1 text-[13px] text-fg-muted">
                  Aucun signalement ne correspond à ces filtres.
                </p>
              </div>
            )}
            {filteredReports.map((report) => (
              <ReportCard
                key={report.id}
                report={report}
                onBan={(r) => setBanSubject(subjectOf(r))}
                onEscalate={(r) => {
                  const user = users.find((u) => u.id === r.authorId)
                  if (user) setEscalation({ user, section: r.section, reportIds: [r.id] })
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* ======================================================= SIGNALÉS */}
      {tab === 'signales' && (
        <div>
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <div className="relative min-w-[240px] flex-1">
              <SearchIcon />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Nom, filière, établissement, email…"
                className="pl-9"
              />
            </div>
            <Badge variant="primary">{filteredUsers.length} comptes</Badge>
          </div>

          <div className="panel overflow-x-auto">
            <div className="min-w-[980px]">
              <div className="grid grid-cols-[1.6fr_1.2fr_1fr_0.9fr_1.1fr_1fr_auto] gap-4 border-b border-border px-5 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
                <span>Compte</span>
                <span>Filière</span>
                <span>Établissement</span>
                <span>Signalements</span>
                <span>Risque</span>
                <span>Statut</span>
                <span className="w-32 text-right">Dossier</span>
              </div>
              <div className="divide-y divide-border">
                {filteredUsers.map((user) => (
                  <div
                    key={user.id}
                    className="grid grid-cols-[1.6fr_1.2fr_1fr_0.9fr_1.1fr_1fr_auto] items-center gap-4 px-5 py-3"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-surface-3 text-[11px] font-bold text-fg-muted">
                        {initials(user.fullName)}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-[13px] font-semibold text-fg">{user.fullName}</p>
                        <p className="truncate text-[11px] text-fg-subtle">
                          {user.pseudonym} · {user.email}
                        </p>
                      </div>
                    </div>
                    <span className="truncate text-[12.5px] text-fg-muted">{user.program}</span>
                    <span className="truncate text-[12.5px] text-fg-muted">{user.school}</span>
                    <div className="min-w-0">
                      <p className="text-[13px] font-bold tabular-nums text-fg">{user.reportsReceived}</p>
                      <p className="text-[10.5px] text-fg-subtle">
                        {user.contentHidden} masqués · {user.warnings} avert.
                      </p>
                    </div>
                    <RiskBadge level={user.riskLevel} />
                    <ModerationStatusBadge status={user.status} />
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm" onClick={() => setDossier(user)}>
                        Ouvrir
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= BANNIS */}
      {tab === 'bannis' && (
        <div className="space-y-5">
          <section>
            <SectionHeading
              kicker="En vigueur"
              title="Bannissements actifs"
              action={<Badge variant="danger">{activeBans.length} actifs</Badge>}
            />
            <div className="grid gap-3 lg:grid-cols-2">
              {activeBans.length === 0 && (
                <div className="panel px-6 py-10 text-center text-[13px] text-fg-muted lg:col-span-2">
                  Aucun bannissement en vigueur.
                </div>
              )}
              {activeBans.map((ban) => (
                <BanCard key={ban.id} ban={ban} onRevoke={() => handleRevoke(ban)} />
              ))}
            </div>
          </section>

          <section>
            <SectionHeading kicker="Historique" title="Bannissements passés" />
            <div className="grid gap-3 lg:grid-cols-2">
              {pastBans.length === 0 && (
                <div className="panel px-6 py-10 text-center text-[13px] text-fg-muted lg:col-span-2">
                  Aucun bannissement passé.
                </div>
              )}
              {pastBans.map((ban) => (
                <BanCard key={ban.id} ban={ban} />
              ))}
            </div>
          </section>
        </div>
      )}

      {/* ======================================================= ESCALADES */}
      {tab === 'escalades' && (
        <div>
          <SectionHeading
            kicker="Dossiers transmis"
            title="Demandes de bannissement définitif"
            action={
              <Badge variant="accent">
                {escalations.filter((e) => e.status === 'en_attente').length} en attente de décision
              </Badge>
            }
          />
          <div className="grid gap-3">
            {escalations.length === 0 && (
              <div className="panel px-6 py-14 text-center">
                <ArrowUpRight className="mx-auto h-8 w-8 text-fg-subtle" />
                <p className="mt-3 font-display text-[17px] font-bold text-fg">Aucune escalade</p>
                <p className="mt-1 text-[13px] text-fg-muted">
                  Les demandes de bannissement définitif apparaîtront ici.
                </p>
              </div>
            )}
            {escalations.map((escalationItem) => (
              <article key={escalationItem.id} className="panel p-4 sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge
                        variant={
                          escalationItem.status === 'en_attente'
                            ? 'warning'
                            : escalationItem.status === 'acceptee'
                              ? 'danger'
                              : 'default'
                        }
                      >
                        {escalationItem.status === 'en_attente'
                          ? 'En attente de la Direction'
                          : escalationItem.status === 'acceptee'
                            ? 'Acceptée'
                            : 'Refusée'}
                      </Badge>
                      <Badge variant="outline">
                        {FORGE_SECTION_LABEL[escalationItem.section] ?? escalationItem.section}
                      </Badge>
                      <Badge variant={escalationItem.priority === 'haute' ? 'danger' : 'default'}>
                        Priorité {escalationItem.priority}
                      </Badge>
                    </div>
                    <h3 className="mt-2 font-display text-[16px] font-bold text-fg">
                      {escalationItem.userName} · {escalationItem.userPseudonym}
                    </h3>
                    <p className="mt-1 text-[12.5px] text-fg-muted">{escalationItem.reason}</p>
                    <p className="mt-2 rounded-lg bg-surface-2 px-3 py-2 text-[12px] leading-snug text-fg-muted">
                      {escalationItem.evidence}
                    </p>
                    <p className="mt-2 text-[11px] text-fg-subtle">
                      Demandé par {escalationItem.requestedBy} · {formatRelative(escalationItem.requestedAt)}
                      {escalationItem.reportIds.length > 0 &&
                        ` · ${escalationItem.reportIds.length} signalement(s) rattaché(s)`}
                    </p>
                    {escalationItem.decidedBy && (
                      <p className="mt-1 text-[11px] text-fg-subtle">
                        Décidé par {escalationItem.decidedBy} · {formatDate(escalationItem.decidedAt ?? '')}
                        {escalationItem.decisionNote ? ` — ${escalationItem.decisionNote}` : ''}
                      </p>
                    )}
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setDossier(users.find((u) => u.id === escalationItem.userId) ?? null)}>
                    Voir le dossier
                  </Button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================== SUIVI */}
      {tab === 'suivi' && (
        <div className="grid gap-5 lg:grid-cols-[1fr_1.2fr]">
          <section>
            <SectionHeading kicker="Comptes suivis" title="Niveau de risque" />
            <div className="panel divide-y divide-border">
              {users.map((user) => (
                <button
                  key={user.id}
                  type="button"
                  onClick={() => setDossier(user)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-surface-2"
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-surface-3 text-[11px] font-bold text-fg-muted">
                    {initials(user.fullName)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-semibold text-fg">{user.fullName}</span>
                    <span className="block truncate text-[11px] text-fg-subtle">
                      {user.reportsReceived} signalements · {user.contentHidden} masqués ·{' '}
                      {user.warnings} avertissements
                    </span>
                  </span>
                  <RiskBadge level={user.riskLevel} />
                </button>
              ))}
            </div>
          </section>

          <section>
            <SectionHeading
              kicker="Traçabilité"
              title="Journal des décisions de modération"
              action={<Badge variant="primary">{actions.length} décisions</Badge>}
            />
            <div className="panel max-h-[620px] overflow-y-auto">
              <ol className="relative space-y-4 p-5 pl-9">
                {actions.map((action) => (
                  <li key={action.id} className="relative">
                    <span
                      className={cn(
                        'absolute -left-[26px] top-1.5 h-2.5 w-2.5 rounded-full border-2 border-surface',
                        action.action === 'bannir_temporaire'
                          ? 'bg-danger'
                          : action.action === 'escalader'
                            ? 'bg-accent'
                            : action.action === 'delier'
                              ? 'bg-success'
                              : 'bg-primary',
                      )}
                    />
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge variant="outline">{DECISION_LABEL[action.action]}</Badge>
                      {action.userName && <span className="text-[12px] font-semibold text-fg">{action.userName}</span>}
                    </div>
                    <p className="mt-1 text-[12px] text-fg-muted">{action.note}</p>
                    <p className="mt-0.5 text-[10.5px] text-fg-subtle">
                      {action.actor} ({action.actorRole === 'direction' ? 'Direction' : 'Modération'}) ·{' '}
                      {formatDate(action.createdAt)}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </section>
        </div>
      )}

      {/* --------------------------------------------------------- dialogues */}
      <TemporaryBanDialog
        subject={banSubject}
        open={Boolean(banSubject)}
        onOpenChange={(open) => !open && setBanSubject(null)}
      />

      <EscalationDialog
        user={escalation?.user ?? null}
        section={escalation?.section ?? ''}
        reportIds={escalation?.reportIds ?? []}
        open={Boolean(escalation)}
        onOpenChange={(open) => !open && setEscalation(null)}
      />

      <UserDossierDialog
        user={dossier}
        bans={bans}
        actions={actions}
        open={Boolean(dossier)}
        onOpenChange={(open) => !open && setDossier(null)}
        onEscalate={(user) => {
          setDossier(null)
          setEscalation({ user, section: 'entraide', reportIds: [] })
        }}
        onBan={(user) => {
          setDossier(null)
          setBanSubject({
            userId: user.id,
            userName: user.fullName,
            userPseudonym: user.pseudonym,
            section: 'entraide',
          })
        }}
      />
    </div>
  )
}

/* ------------------------------------------------------------ fragments */

function SearchIcon() {
  return (
    <svg
      className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-subtle"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.2-3.2" />
    </svg>
  )
}

function BanCard({ ban, onRevoke }: { ban: ModerationBan; onRevoke?: () => void }) {
  const isPermanent = ban.type === 'definitif'
  const expired = ban.expiresAt ? new Date(ban.expiresAt) < new Date() : false
  const revoked = Boolean(ban.revokedAt)
  const daysLeft = ban.expiresAt
    ? Math.max(0, Math.ceil((new Date(ban.expiresAt).getTime() - Date.now()) / 86400000))
    : null

  return (
    <article className="panel p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <Badge variant={isPermanent ? 'danger' : 'warning'}>
              {isPermanent ? (
                <ShieldAlert className="h-3 w-3" />
              ) : (
                <Clock className="h-3 w-3" />
              )}
              {isPermanent ? 'Exclusion définitive' : `Temporaire · ${ban.durationDays} j`}
            </Badge>
            <Badge variant="outline">
              {ban.scope === 'plateforme' ? 'Toute la plateforme' : FORGE_SECTION_LABEL[ban.section] ?? ban.section}
            </Badge>
            {revoked && <Badge variant="success">Levée</Badge>}
            {!revoked && expired && <Badge variant="default">Expirée</Badge>}
            {!revoked && !expired && daysLeft !== null && (
              <Badge variant="danger"> encore {daysLeft} j</Badge>
            )}
          </div>
          <h4 className="mt-2 text-[14px] font-bold text-fg">
            {ban.userName} · {ban.userPseudonym}
          </h4>
          <p className="mt-1 text-[12.5px] leading-snug text-fg-muted">{ban.reason}</p>
          <p className="mt-1.5 text-[11px] text-fg-subtle">
            Imposé par {ban.imposedBy} ({ban.imposedByRole === 'direction' ? 'Direction' : 'Modération'}) ·{' '}
            {formatDate(ban.createdAt)}
            {ban.expiresAt ? ` → ${formatDate(ban.expiresAt)}` : ''}
            {ban.revokedAt ? ` · levé le ${formatDate(ban.revokedAt)}` : ''}
          </p>
          <p className="mt-1.5 text-[10.5px] text-fg-subtle">
            {ban.notifiedAt
              ? `Notifié à l’utilisateur le ${formatDate(ban.notifiedAt)} · voie de recours communiquée.`
              : 'Notification en attente.'}
          </p>
        </div>
        {onRevoke && !revoked && (
          <Button variant="outline" size="sm" onClick={onRevoke}>
            Lever le bannissement
          </Button>
        )}
      </div>
    </article>
  )
}
