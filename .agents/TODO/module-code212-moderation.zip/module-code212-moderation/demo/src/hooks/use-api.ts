import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '@/services/api'
import type { XpRule } from '@/types'

/* ------------------------------------------------------------- apprenant */

export const useMe = () => useQuery({ queryKey: ['me'], queryFn: api.me, staleTime: 60_000 })

export const useDashboard = () => useQuery({ queryKey: ['dashboard'], queryFn: api.dashboard })

export const useQuests = (params?: { track?: string; difficulty?: string; category?: string; search?: string }) =>
  useQuery({ queryKey: ['quests', params], queryFn: () => api.quests(params) })

export const useQuest = (id: number) => useQuery({ queryKey: ['quest', id], queryFn: () => api.quest(id) })

export function useEnrollQuest() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.enrollQuest(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['quest'] })
      qc.invalidateQueries({ queryKey: ['quests'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export function useSubmitStep(questId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (payload: { stepId: number; content: string }) => api.submitStep(questId, payload.stepId, payload.content),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['quest', questId] })
      qc.invalidateQueries({ queryKey: ['ledger'] })
      qc.invalidateQueries({ queryKey: ['me'] })
    },
  })
}

export const useLedger = () => useQuery({ queryKey: ['ledger'], queryFn: api.ledger })

export const useLeaderboard = (period: string) =>
  useQuery({ queryKey: ['leaderboard', period], queryFn: () => api.leaderboard(period) })

export const useLevels = () => useQuery({ queryKey: ['levels'], queryFn: api.levels })
export const useTracks = () => useQuery({ queryKey: ['tracks'], queryFn: api.tracks })
export const useBadges = () => useQuery({ queryKey: ['badges'], queryFn: api.badges })
export const usePaths = () => useQuery({ queryKey: ['paths'], queryFn: api.paths })
export const useMissions = () => useQuery({ queryKey: ['missions'], queryFn: api.missions })
export const useCertifications = () => useQuery({ queryKey: ['certifications'], queryFn: api.certifications })
export const useRewards = () => useQuery({ queryKey: ['rewards'], queryFn: api.rewards })
export const useChallenges = () => useQuery({ queryKey: ['challenges'], queryFn: api.challenges })
export const useForgeCategories = () => useQuery({ queryKey: ['forge', 'categories'], queryFn: api.forgeCategories })
export const useForgeThreads = (category?: string) =>
  useQuery({ queryKey: ['forge', 'threads', category ?? 'all'], queryFn: () => api.forgeThreads(category) })

export function useClaimMission() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.claimMission(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['missions'] })
      qc.invalidateQueries({ queryKey: ['me'] })
      qc.invalidateQueries({ queryKey: ['ledger'] })
    },
  })
}

export function useJoinChallenge() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.joinChallenge(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['challenges'] }),
  })
}

export function usePurchaseReward() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.purchaseReward(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rewards'] })
      qc.invalidateQueries({ queryKey: ['me'] })
    },
  })
}

/* ------------------------------------------------------------------ Forge */

export const useForgeThread = (id: number) =>
  useQuery({ queryKey: ['forge', 'thread', id], queryFn: () => api.forgeThread(id) })

export function useCreateThread() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.createThread,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['forge'] })
      qc.invalidateQueries({ queryKey: ['me'] })
    },
  })
}

export function useReplyToThread(threadId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: string) => api.replyToThread(threadId, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['forge'] }),
  })
}

export function useAcceptSolution(threadId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (solutionId: number) => api.acceptSolution(threadId, solutionId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['forge'] })
      qc.invalidateQueries({ queryKey: ['me'] })
    },
  })
}

export function useLikeThread() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.toggleLikeThread(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['forge'] })
      qc.invalidateQueries({ queryKey: ['me'] })
    },
  })
}

export function useReportThread() {
  return useMutation({ mutationFn: ({ id, reason }: { id: number; reason: string }) => api.reportThread(id, reason) })
}

/* ------------------------------------------------------------------ profil */

export function useUpdateProfile() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.updateProfile,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['me'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

/* ------------------------------------------------------------------- admin */

export const useAdminOverview = () => useQuery({ queryKey: ['admin', 'overview'], queryFn: api.adminOverview })
export const useAdminSubmissions = () => useQuery({ queryKey: ['admin', 'submissions'], queryFn: api.adminSubmissions })
export const useAdminRules = () => useQuery({ queryKey: ['admin', 'rules'], queryFn: api.adminRules })
export const useAdminOrders = () => useQuery({ queryKey: ['admin', 'orders'], queryFn: api.adminOrders })
export const useAdminStudents = () => useQuery({ queryKey: ['admin', 'students'], queryFn: api.adminStudents })

export function useReviewSubmission() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (payload: { id: number; decision: 'validee' | 'rejetee'; feedback: string }) =>
      api.reviewSubmission(payload.id, payload.decision, payload.feedback),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export function useUpdateRule() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (payload: { id: number; patch: Partial<XpRule> }) => api.updateRule(payload.id, payload.patch),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'rules'] }),
  })
}

export function useUpdateOrder() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (payload: { id: number; status: import('@/types').RewardOrder['status'] }) =>
      api.updateOrder(payload.id, payload.status),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin'] }),
  })
}

/* ------------------------------------------ gestion des rôles & des accès */

export const useAdminRoles = () => useQuery({ queryKey: ['admin', 'roles'], queryFn: api.adminRoles })
export const useAdminRoleAssignments = () =>
  useQuery({ queryKey: ['admin', 'role-assignments'], queryFn: api.adminRoleAssignments })
export const useAdminModerators = () =>
  useQuery({ queryKey: ['admin', 'moderators'], queryFn: api.adminModerators })
export const useAdminManagedUsers = () =>
  useQuery({ queryKey: ['admin', 'managed-users'], queryFn: api.adminManagedUsers })
export const useRoleAudit = () => useQuery({ queryKey: ['admin', 'role-audit'], queryFn: api.roleAudit })

/** Invalide l'ensemble des vues « rôles » après une mutation. */
function useRolesInvalidation() {
  const qc = useQueryClient()
  return () => {
    qc.invalidateQueries({ queryKey: ['admin'] })
  }
}

export function useCreateRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({
    mutationFn: api.createRole,
    onSuccess: () => invalidate(),
  })
}

export function useUpdateRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({
    mutationFn: (payload: { id: number; patch: { name?: string; description?: string; color?: string; permissions?: string[] } }) =>
      api.updateRole(payload.id, payload.patch),
    onSuccess: () => invalidate(),
  })
}

export function useDuplicateRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.duplicateRole, onSuccess: () => invalidate() })
}

export function useRevokeRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.revokeRole, onSuccess: () => invalidate() })
}

export function useDeleteRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.deleteRole, onSuccess: () => invalidate() })
}

export function useAssignRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.assignRole, onSuccess: () => invalidate() })
}

export function useUnassignRole() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.unassignRole, onSuccess: () => invalidate() })
}

export function useAssignModerator() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.assignModerator, onSuccess: () => invalidate() })
}

export function useRevokeModerator() {
  const invalidate = useRolesInvalidation()
  return useMutation({ mutationFn: api.revokeModerator, onSuccess: () => invalidate() })
}

export function useUpdateManagedUserStatus() {
  const invalidate = useRolesInvalidation()
  return useMutation({
    mutationFn: (payload: { id: number; status: import('@/types').ManagedUserStatus }) =>
      api.updateManagedUserStatus(payload.id, payload.status),
    onSuccess: () => invalidate(),
  })
}

/* ================================================ espace workspaces moderation */

export const useModerationOverview = () =>
  useQuery({ queryKey: ['moderator', 'queue'], queryFn: api.moderationOverview })

function useModerationInvalidation() {
  const qc = useQueryClient()
  return () => {
    qc.invalidateQueries({ queryKey: ['moderator'] })
  }
}

export function useResolveModerationReport() {
  const invalidate = useModerationInvalidation()
  return useMutation({
    mutationFn: (payload: {
      id: number
      decision: string
      note: string
      durationDays?: number
      section?: string
    }) => api.resolveModerationReport(payload.id, payload),
    onSuccess: () => invalidate(),
  })
}

export function useEscalateBan() {
  const invalidate = useModerationInvalidation()
  return useMutation({
    mutationFn: api.escalateBan,
    onSuccess: () => invalidate(),
  })
}

export function useRevokeModerationBan() {
  const invalidate = useModerationInvalidation()
  return useMutation({
    mutationFn: (payload: { id: number; note: string }) => api.revokeModerationBan(payload.id, payload.note),
    onSuccess: () => invalidate(),
  })
}
