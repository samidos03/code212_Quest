import { useMemo } from 'react'
import { Activity, Clock, FileWarning, Gavel, Scale, ShieldAlert } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { MOTIF_LABEL, RISK_LABEL, RISK_TONE, SEVERITY_LABEL, SEVERITY_TONE, USER_STATUS_LABEL } from '@/lib/moderation'
import { formatDate, formatRelative, initials } from '@/lib/utils'
import type { ModerationAction, ModerationBan, ModerationRiskLevel, ModerationStatus, ReportedUser } from '@/types'

/* ------------------------------------------------------------- badges */

export function RiskBadge({ level, className }: { level: ModerationRiskLevel; className?: string }) {
  return (
    <Badge variant={RISK_TONE[level]} className={className}>
      <ShieldAlert className="h-3 w-3" />
      {RISK_LABEL[level]}
    </Badge>
  )
}

export function ModerationStatusBadge({ status }: { status: ModerationStatus }) {
  const tone =
    status === 'banni_definitif'
      ? 'danger'
      : status === 'banni_temporaire'
        ? 'danger'
        : status === 'surveille'
          ? 'warning'
          : 'success'

  return (
    <Badge variant={tone as 'danger' | 'warning' | 'success'}>{USER_STATUS_LABEL[status]}</Badge>
  )
}

export function SeverityBadge({ severity }: { severity: keyof typeof SEVERITY_LABEL }) {
  return <Badge variant={SEVERITY_TONE[severity]}>{SEVERITY_LABEL[severity]}</Badge>
}

/* --------------------------------------------------------- dossier compte */

/**
 * Dossier de suivi d'un compte : identité, risque, motifs, historique des
 * décisions et actions possibles. C'est la pièce que le modérateur transmet
 * à la Direction quand il escalade.
 */
export function UserDossierDialog({
  user,
  bans,
  actions,
  open,
  onOpenChange,
  onEscalate,
  onBan,
}: {
  user: ReportedUser | null
  bans: ModerationBan[]
  actions: ModerationAction[]
  open: boolean
  onOpenChange: (open: boolean) => void
  onEscalate?: (user: ReportedUser) => void
  onBan?: (user: ReportedUser) => void
}) {
  const userBans = useMemo(
    () => (user ? bans.filter((b) => b.userId === user.id) : []),
    [bans, user],
  )
  const userActions = useMemo(
    () => (user ? actions.filter((a) => a.userId === user.id).slice(0, 12) : []),
    [actions, user],
  )

  if (!user) return null

  const activeBan = userBans.find(
    (b) => b.type === 'temporaire' && b.revokedAt === null && b.expiresAt && new Date(b.expiresAt) > new Date(),
  )
  const permanentBan = userBans.find((b) => b.type === 'definitif')

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-gradient text-[13px] font-bold text-white">
              {initials(user.fullName)}
            </span>
            <div className="min-w-0">
              <DialogTitle>{user.fullName}</DialogTitle>
              <p className="text-[12px] text-fg-subtle">
                {user.pseudonym} · {user.program} · {user.school} · {user.email}
              </p>
            </div>
          </div>
          <DialogDescription className="flex flex-wrap items-center gap-2">
            <RiskBadge level={user.riskLevel} />
            <ModerationStatusBadge status={user.status} />
            <span className="text-[12px] text-fg-muted">
              Première fois signalé le {formatDate(user.firstReportedAt ?? null)} · dernière
              activité {formatRelative(user.lastActivityAt ?? null)}
            </span>
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          {/* ------------------------------------------------ indicateurs */}
          <section className="rounded-xl border border-border p-3.5">
            <p className="kicker mb-2.5">Indicateurs</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: 'Signalements reçus', value: user.reportsReceived, icon: FileWarning },
                { label: 'Contenus masqués', value: user.contentHidden, icon: Activity },
                { label: 'Avertissements', value: user.warnings, icon: Clock },
                {
                  label: 'Bannissements',
                  value: user.temporaryBans + user.permanentBans,
                  icon: Gavel,
                },
              ].map((item) => (
                <div key={item.label} className="rounded-lg bg-surface-2 px-3 py-2">
                  <p className="flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-[0.1em] text-fg-subtle">
                    <item.icon className="h-3 w-3" />
                    {item.label}
                  </p>
                  <p className="mt-0.5 font-display text-[20px] font-bold leading-none text-fg">{item.value}</p>
                </div>
              ))}
            </div>

            {user.topMotifs.length > 0 && (
              <>
                <Separator className="my-3" />
                <p className="kicker mb-1.5">Motifs récurrents</p>
                <div className="flex flex-wrap gap-1.5">
                  {user.topMotifs.map((m) => (
                    <span key={motif.key(m)} className="chip">
                      {MOTIF_LABEL[m.motif]} · {m.count}
                    </span>
                  ))}
                </div>
              </>
            )}

            {user.notes && (
              <>
                <Separator className="my-3" />
                <p className="kicker mb-1">Note de suivi</p>
                <p className="text-[12.5px] leading-snug text-fg-muted">{user.notes}</p>
              </>
            )}
          </section>

          {/* ------------------------------------------------ historique */}
          <section className="rounded-xl border border-border p-3.5">
            <p className="kicker mb-2.5">Historique des décisions</p>

            {userActions.length === 0 ? (
              <p className="text-[12.5px] text-fg-subtle">Aucune décision de modération sur ce compte.</p>
            ) : (
              <ol className="relative space-y-3 border-l border-border pl-4">
                {userActions.map((action) => (
                  <li key={action.id} className="relative">
                    <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-surface bg-primary" />
                    <p className="text-[12.5px] font-semibold text-fg">{action.targetLabel}</p>
                    <p className="text-[11.5px] text-fg-muted">{action.note}</p>
                    <p className="text-[10.5px] text-fg-subtle">
                      {action.actor} ({action.actorRole === 'direction' ? 'Direction' : 'Modération'}) ·{' '}
                      {formatDate(action.createdAt)}
                    </p>
                  </li>
                ))}
              </ol>
            )}

            {userBans.length > 0 && (
              <>
                <Separator className="my-3" />
                <p className="kicker mb-1.5">Bannissements</p>
                <div className="space-y-1.5">
                  {userBans.map((ban) => (
                    <div key={ban.id} className="rounded-lg bg-surface-2 px-3 py-2">
                      <p className="text-[12px] font-semibold text-fg">
                        {ban.type === 'definitif' ? 'Exclusion définitive' : `Exclusion ${ban.durationDays} j`}
                        {ban.revokedAt && ' (levée)'}
                      </p>
                      <p className="text-[11.5px] text-fg-muted">{ban.reason}</p>
                      <p className="text-[10.5px] text-fg-subtle">
                        {ban.imposedBy} · {formatDate(ban.createdAt)}
                        {ban.expiresAt ? ` → ${formatDate(ban.expiresAt)}` : ''}
                      </p>
                    </div>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>

        <DialogFooter className="sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {onBan && !activeBan && !permanentBan && (
              <Button variant="outline" onClick={() => onBan(user)}>
                <Gavel className="h-4 w-4" /> Bannir temporairement
              </Button>
            )}
            {onEscalate && (
              <Button onClick={() => onEscalate(user)}>
                <Scale className="h-4 w-4" /> Escalader à la Direction
              </Button>
            )}
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** Utilitaire interne : clé stable d'un motif. */
const motif = {
  key: (m: { motif: string }) => m.motif,
}
