import { useState } from 'react'
import {
  ArrowUpRight,
  CheckCircle2,
  EyeOff,
  Flag,
  Gavel,
  Megaphone,
  MessageSquare,
  ShieldX,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Label, Textarea } from '@/components/ui/input'
import { useToast } from '@/components/ui/toast'
import { useResolveModerationReport } from '@/hooks/use-api'
import { MOTIF_LABEL, REPORT_STATUS_LABEL } from '@/lib/moderation'
import { FORGE_SECTION_LABEL } from '@/lib/permissions'
import { cn, formatRelative } from '@/lib/utils'
import { SeverityBadge } from '@/components/moderator/risk-badge'
import type { ModerationReport } from '@/types'

/**
 * Carte de signalement : contexte, actions de modération et journalisation.
 *
 * Les actions simples sont appliquées directement ; le bannissement temporaire
 * et l'escalade passent par des dialogues dédiés (voir sanction-dialog.tsx).
 */
export function ReportCard({
  report,
  onBan,
  onEscalate,
}: {
  report: ModerationReport
  onBan: (report: ModerationReport) => void
  onEscalate: (report: ModerationReport) => void
}) {
  const { toast } = useToast()
  const resolve = useResolveModerationReport()
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState<string | null>(null)

  const isOpen = report.status === 'ouverte' || report.status === 'en_traitement'
  const isMine = report.section === 'entraide' || report.section === 'cafe'

  const apply = async (decision: string, label: string, description: string) => {
    setBusy(decision)
    try {
      await resolve.mutateAsync({ id: report.id, decision, note })
      toast(label, { description, kind: 'success' })
      setNote('')
    } catch (error) {
      toast('Action impossible', { description: (error as Error).message, kind: 'error' })
    } finally {
      setBusy(null)
    }
  }

  return (
    <article
      className={cn(
        'panel overflow-hidden transition-shadow',
        report.severity === 'critique' && 'border-danger/35',
      )}
    >
      {/* barre de gravité */}
      <span
        className={cn(
          'block h-[3px]',
          report.severity === 'critique'
            ? 'bg-danger'
            : report.severity === 'elevee'
              ? 'bg-warning'
              : report.severity === 'moyenne'
                ? 'bg-cyan'
                : 'bg-border-strong',
        )}
      />

      <div className="p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge variant={isOpen ? 'danger' : 'default'}>
                <Flag className="h-3 w-3" /> {REPORT_STATUS_LABEL[report.status]}
              </Badge>
              <Badge variant="outline">
                {report.targetType === 'discussion' ? (
                  <MessageSquare className="h-3 w-3" />
                ) : (
                  <ShieldX className="h-3 w-3" />
                )}
                {report.targetType === 'discussion' ? 'Discussion' : 'Réponse'}
              </Badge>
              <Badge variant={isMine ? 'cyan' : 'default'}>
                {FORGE_SECTION_LABEL[report.section] ?? report.section}
              </Badge>
              <SeverityBadge severity={report.severity} />
              {report.reportCount > 1 && (
                <Badge variant="warning">{report.reportCount} signalements</Badge>
              )}
            </div>

            <h3 className="mt-2 font-display text-[16.5px] font-bold leading-tight text-fg">
              {report.title}
            </h3>
            <p className="mt-1 line-clamp-2 text-[12.5px] leading-snug text-fg-muted">
              « {report.excerpt} »
            </p>
            <p className="mt-1.5 text-[11.5px] text-fg-subtle">
              Motif : <span className="font-semibold text-fg-muted">{MOTIF_LABEL[report.motif]}</span> ·
              signalé par {report.reporterName} · {formatRelative(report.createdAt)}
            </p>
            <p className="text-[11.5px] text-fg-subtle">
              Auteur : <span className="font-semibold text-fg-muted">{report.authorName}</span> (
              {report.authorPseudonym})
            </p>
          </div>

          {!isMine && (
            <Badge variant="warning" className="shrink-0">
              Hors périmètre
            </Badge>
          )}
        </div>

        {report.status === 'escaladee' && (
          <div className="mt-3 rounded-lg border border-primary/25 bg-primary-soft/50 px-3 py-2">
            <p className="text-[11.5px] text-fg-muted">
              <strong className="text-fg">Dossier transmis à la Direction.</strong> Le compte reste actif
              tant que la décision n’est pas prise.
            </p>
            {report.handledBy && (
              <p className="mt-0.5 text-[10.5px] text-fg-subtle">
                par {report.handledBy} · {report.handledAt ? formatRelative(report.handledAt) : ''}
              </p>
            )}
          </div>
        )}

        {(report.status === 'resolue' || report.status === 'rejetee') && (
          <div className="mt-3 rounded-lg border border-border bg-surface-2 px-3 py-2">
            <p className="text-[11.5px] text-fg-muted">
              <strong className="text-fg">Décision :</strong> {report.resolutionNote || '—'}
            </p>
            <p className="mt-0.5 text-[10.5px] text-fg-subtle">
              traitée par {report.handledBy} · {report.handledAt ? formatRelative(report.handledAt) : ''}
            </p>
          </div>
        )}

        {isOpen && (
          <>
            <div className="mt-4 space-y-1.5">
              <Label htmlFor={`note-${report.id}`}>Note de modération</Label>
              <Textarea
                id={`note-${report.id}`}
                rows={2}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Constats, éléments de contexte, décision motivée…"
              />
            </div>

            <div className="mt-3.5 flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={busy !== null || !isMine}
                onClick={() =>
                  apply(
                    'classer_sans_suite',
                    'Signalement classé sans suite',
                    'L’auteur a reçu un accusé de réception. La décision est journalisée.',
                  )
                }
              >
                <CheckCircle2 className="h-3.5 w-3.5" /> Classer sans suite
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={busy !== null || !isMine}
                onClick={() =>
                  apply(
                    'masquer_contenu',
                    'Contenu masqué',
                    'Le contenu est retiré de la rubrique et l’auteur est informé.',
                  )
                }
              >
                <EyeOff className="h-3.5 w-3.5" /> Masquer
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={busy !== null || !isMine}
                onClick={() =>
                  apply(
                    'avertir_auteur',
                    'Avertissement envoyé',
                    'Avertissement écrit envoyé à l’auteur, sans sanction.',
                  )
                }
              >
                <Megaphone className="h-3.5 w-3.5" /> Avertir
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={busy !== null || !isMine}
                onClick={() => onBan(report)}
              >
                <Gavel className="h-3.5 w-3.5" /> Bannir (1–7 j)
              </Button>
              <Button
                size="sm"
                variant="accent"
                disabled={busy !== null || !isMine}
                onClick={() => onEscalate(report)}
              >
                <ArrowUpRight className="h-3.5 w-3.5" /> Escalader
              </Button>
            </div>

            {!isMine && (
              <p className="mt-2 text-[11px] text-fg-subtle">
                Ce signalement relève d’une rubrique qui ne vous est pas confiée : il est visible, mais
                la décision revient au modérateur de la rubrique.
              </p>
            )}
          </>
        )}
      </div>
    </article>
  )
}
