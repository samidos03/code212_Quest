import { useEffect, useState } from 'react'
import { AlertTriangle, ArrowUpRight, Gavel, Scale } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Label, Textarea } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useToast } from '@/components/ui/toast'
import { useEscalateBan, useResolveModerationReport } from '@/hooks/use-api'
import { APPEAL_PATH, TEMPORARY_BAN_MAX_DAYS, TEMPORARY_BAN_MIN_DAYS } from '@/lib/moderation'
import { FORGE_SECTION_LABEL } from '@/lib/permissions'
import { cn } from '@/lib/utils'
import type { ReportedUser } from '@/types'

/** Personne.make de l'objet sanctionné : un signalement ou un compte suivi. */
export interface BanSubject {
  userId: number
  userName: string
  userPseudonym: string
  section: string
  reportId?: number
}

/* ============================================ bannissement temporaire (1-7 j) */

export function TemporaryBanDialog({
  subject,
  open,
  onOpenChange,
}: {
  subject: BanSubject | null
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const { toast } = useToast()
  const resolve = useResolveModerationReport()
  const [days, setDays] = useState(TEMPORARY_BAN_MIN_DAYS)
  const [reason, setReason] = useState('')

  useEffect(() => {
    if (open) {
      setDays(TEMPORARY_BAN_MIN_DAYS)
      setReason('')
    }
  }, [open])

  if (!subject) return null

  const expiresAt = new Date(Date.now() + days * 86400000)

  const submit = async () => {
    try {
      if (!subject.reportId) {
        toast('Signalement de référence requis', {
          description: 'Le bannissement doit être rattaché à un signalement traité.',
          kind: 'error',
        })
        return
      }

      await resolve.mutateAsync({
        id: subject.reportId,
        decision: 'bannir_temporaire',
        note: reason,
        durationDays: days,
        section: subject.section,
      })
      toast(`Bannissement de ${days} jour${days > 1 ? 's' : ''} appliqué`, {
        description:
          'Bannissement consigné et notifié. La voie de recours a été communiquée à l’utilisateur.',
        kind: 'success',
      })
      onOpenChange(false)
    } catch (error) {
      toast('Bannissement impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Bannissement temporaire</DialogTitle>
          <DialogDescription>
            Exclusion de {subject.userName} ({subject.userPseudonym}) de la rubrique{' '}
            <strong>{FORGE_SECTION_LABEL[subject.section] ?? subject.section}</strong>. La durée est
            limitée à {TEMPORARY_BAN_MAX_DAYS} jours : le bannissement définitif n’est pas une
            décision de modération.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Durée de l’exclusion</Label>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {Array.from({ length: TEMPORARY_BAN_MAX_DAYS }, (_, i) => i + TEMPORARY_BAN_MIN_DAYS).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDays(d)}
                  className={cn(
                    'h-10 w-10 rounded-xl border text-[13px] font-bold transition-colors',
                    days === d
                      ? 'border-danger bg-danger text-white'
                      : 'border-border bg-surface-2 text-fg-muted hover:border-border-strong hover:text-fg',
                  )}
                >
                  {d}j
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11.5px] text-fg-subtle">
              Fin de l’exclusion :{' '}
              <span className="font-semibold text-fg">
                {expiresAt.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}
              </span>
            </p>
          </div>

          <div>
            <Label htmlFor="ban-reason">Motif de la sanction</Label>
            <Textarea
              id="ban-reason"
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Constats, éléments de contexte, règle enfreinte…"
            />
          </div>

          <div className="rounded-xl border border-cyan/30 bg-cyan-soft/50 px-3.5 py-3">
            <p className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-cyan-fg">
              <Scale className="h-3.5 w-3.5" /> Voie de recours communiquée
            </p>
            <p className="text-[12px] leading-snug text-fg-muted">{APPEAL_PATH}</p>
          </div>

          <div className="flex items-start gap-2 rounded-lg border border-warning/30 bg-warning-soft/60 px-3 py-2">
            <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />
            <p className="text-[11.5px] leading-snug text-fg-muted">
              Le bannissement est <strong>temporaire</strong> et limité à la rubrique confiée. Pour une
              exclusion définitive, utilisez « Escalader à la Direction » : la décision appartient à la
              Direction du Centre.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button variant="danger" onClick={submit} disabled={resolve.isPending}>
            <Gavel className="h-4 w-4" />
            {resolve.isPending ? 'Application…' : `Bannir ${days} jour${days > 1 ? 's' : ''}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ================================================= escalade vers la Direction */

export function EscalationDialog({
  user,
  section,
  reportIds,
  open,
  onOpenChange,
}: {
  user: ReportedUser | null
  section: string
  reportIds: number[]
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const { toast } = useToast()
  const escalate = useEscalateBan()
  const [reason, setReason] = useState('')
  const [evidence, setEvidence] = useState('')
  const [priority, setPriority] = useState<'normale' | 'haute'>('normale')

  useEffect(() => {
    if (open) {
      setReason('')
      setEvidence('')
      setPriority('normale')
    }
  }, [open])

  if (!user) return null

  const submit = async () => {
    try {
      await escalate.mutateAsync({
        userId: user.id,
        section,
        reason,
        evidence,
        reportIds,
        priority,
      })
      toast('Demande transmise à la Direction', {
        description:
          'Le dossier est en attente de décision. Seul un administrateur peut prononcer un bannissement définitif.',
        kind: 'success',
      })
      onOpenChange(false)
    } catch (error) {
      toast('Escalade impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Escalader à la Direction</DialogTitle>
          <DialogDescription>
            Demande de bannissement définitif pour {user.fullName} ({user.pseudonym}). Le dossier est
            transmis aux administrateurs et au Directeur, seuls habilités à décider d’une exclusion
            définitive.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-border bg-surface-2 px-3 py-2.5">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-fg-subtle">Signalements</p>
              <p className="mt-0.5 font-display text-[19px] font-bold text-fg">{user.reportsReceived}</p>
            </div>
            <div className="rounded-xl border border-border bg-surface-2 px-3 py-2.5">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-fg-subtle">Contenus masqués</p>
              <p className="mt-0.5 font-display text-[19px] font-bold text-fg">{user.contentHidden}</p>
            </div>
            <div className="rounded-xl border border-border bg-surface-2 px-3 py-2.5">
              <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-fg-subtle">Bannissements</p>
              <p className="mt-0.5 font-display text-[19px] font-bold text-fg">
                {user.temporaryBans + user.permanentBans}
              </p>
            </div>
          </div>

          <div>
            <Label htmlFor="esc-reason">Motif de la demande</Label>
            <Textarea
              id="esc-reason"
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ex. : récidive après un bannissement temporaire déjà servi"
            />
          </div>

          <div>
            <Label htmlFor="esc-evidence">Éléments du dossier</Label>
            <Textarea
              id="esc-evidence"
              rows={4}
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
              placeholder="Chronologie, signalements retenus, avertissements, éléments vérifiés…"
            />
            <p className="mt-1.5 text-[11px] text-fg-subtle">
              {reportIds.length > 0
                ? `${reportIds.length} signalement(s) rattaché(s) automatiquement au dossier.`
                : 'Aucun signalement rattaché : précisez le contexte dans le dossier.'}
            </p>
          </div>

          <div>
            <Label>Priorité</Label>
            <Select value={priority} onValueChange={(v) => setPriority(v as 'normale' | 'haute')}>
              <SelectTrigger className="w-[220px]" aria-label="Priorité de la demande">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="normale">Normale — 7 jours</SelectItem>
                <SelectItem value="haute">Haute — 48 heures</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-start gap-2 rounded-lg border border-primary/25 bg-primary-soft/50 px-3 py-2">
            <ArrowUpRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
            <p className="text-[11.5px] leading-snug text-fg-muted">
              Une escalade n’est jamais une sanction : elle est la <strong>demande</strong> de sanction
              définitive. Le compte reste actif tant que la Direction n’a pas décidé.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuler
          </Button>
          <Button onClick={submit} disabled={escalate.isPending || reason.trim().length < 5}>
            <ArrowUpRight className="h-4 w-4" />
            {escalate.isPending ? 'Transmission…' : 'Transmettre à la Direction'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
