# Harnais de démonstration — module « Espace workspaces modérateur »

Mini-application contenant **uniquement** le module, pour le tester sans
l'application complète. Aucune installation de l'application n'est nécessaire.

---

## 1. Lancer

```bash
cd demo
npm install       # ou : ln -s ../../code212-quest/apps/web/node_modules node_modules
npm run dev
```

Ouvrez **http://localhost:5174**.

| Commande | Effet |
|---|---|
| `npm run dev` | Serveur de développement (port 5174) |
| `npm run build` | Build de production (typecheck + Vite) |
| `npm run preview` | Sert le build sur le port 5174 |
| `npm run typecheck` | TypeScript strict, sans émission |

> Si l'application est déjà installée sur la machine, l'installation des dépendances est inutile :
> `ln -s ../chemin/vers/apps/web/node_modules node_modules` (les versions sont identiques).

---

## 2. Ce que contient ce harnais

| Élément | Rôle |
|---|---|
| `src/pages/moderator/moderator-queue-page.tsx` | **Le module**, fichier identique à celui livré dans `new-files/` |
| `src/components/moderator/report-card.tsx` | Carte de signalement et barre d'actions, identique au livrable |
| `src/components/moderator/risk-badge.tsx` | Badges de risque et dossier d'un compte, identique au livrable |
| `src/components/moderator/sanction-dialog.tsx` | Dialogues bannissement / escalade, identiques au livrable |
| `src/lib/moderation.ts` | Référentiel motifs, décisions, recours, identique au livrable |
| `src/lib/permissions.ts` · `src/lib/schools.ts` | Catalogue de permissions et rubriques de la Forge |
| `src/components/ui/*` | Composants partagés (bouton, dialogue, champ, select, badge, toast) |
| `src/components/shared/page-header.tsx` | En-tête de page |
| `src/services/api.ts` · `src/hooks/use-api.ts` | Façade API et hooks — identiques au livrable |
| `src/services/mock/*` | Adaptateur de démonstration : **données en mémoire** |
| `src/types/index.ts` | Types métier |
| `src/index.css` · `tailwind.config.ts` · `public/fonts` | Design system Code212 (identique à l'application) |

**La page et les trois composants du module sont les fichiers exacts du
livrable** : ce que vous voyez ici est ce que le stagiaire obtiendra après
intégration.

---

## 3. Ce qui fonctionne

- Les 5 onglets : **File**, **Signalés**, **Bannis**, **Escalades**, **Suivi & journal**.
- Les 5 indicateurs (en attente, traités sur 7 j, bannissements actifs, escalades,
  comptes signalés) et le panneau de charge par rubrique.
- Les filtres de la File : périmètre (mes rubriques / toutes), statut, gravité, recherche.
- Le traitement d'un signalement : classer sans suite, masquer, avertir.
- Le **bannissement temporaire** : durée au choix parmi 1 à 7 jours, date de fin
  calculée, voie de recours rappelée dans le dialogue.
- L'**escalade** : motif, pièces, priorité, transmission affichée dans l'onglet
  « Escalades ».
- Le **dossier complet d'un compte** : identité, niveau de risque, compteurs,
  motifs récurrents, historique des décisions, bannissements.
- La levée d'un bannissement temporaire.
- Le journal des décisions, mis à jour après chaque action.

## 4. Ce qui est simulé

- **Les données sont en mémoire** : un rechargement de la page remet tout à l'état initial
  (bouton « Réinitialiser » en haut).
- **L'API Laravel n'est pas sollicitée.** L'adaptateur `src/services/mock` reproduit les mêmes
  règles que le backend : périmètre par rubrique, bannissement borné à 1–7 jours,
  escalade vers la Direction, journalisation et notification à chaque décision.
- Pour tester contre la vraie API : `VITE_USE_MOCK=false` et `VITE_API_BASE_URL=…`, puis
  `npm run dev`. Le proxy `/api` de `vite.config.ts` pointe par défaut sur
  `http://localhost:8000` (variable `VITE_API_PROXY` pour changer).

---

## 5. Vérifications passées

- `tsc -b` : aucune erreur (mode strict, `noUnusedLocals`).
- `vite build` : vert.
- Parcours navigateur automatisé : ouverture, 5 onglets, bannissement temporaire de
  2 jours (notification comprise), ouverture d'un dossier → **0 erreur console**.
