<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Demandes de bannissement definitif (escalades).
 *
 * Separation des pouvoirs : le moderateur ne prononce pas d'exclusion
 * definitive, il transmet un dossier. Le compte reste actif tant que la
 * Direction n'a pas statue.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ban_requests', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('section', 40);
            $table->foreignId('requested_by')->constrained('users')->cascadeOnDelete();
            $table->text('reason');
            $table->text('evidence')->nullable();
            $table->jsonb('report_ids')->default(DB::raw("'[]'::jsonb"));
            $table->string('status', 24)->default('en_attente');
            $table->string('priority', 16)->default('normale');
            $table->foreignId('decided_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('decided_at')->nullable();
            $table->text('decision_note')->nullable();
            $table->timestamps();

            $table->index(['status', 'created_at'], 'ban_requests_status_created_index');
            $table->index(['user_id', 'created_at'], 'ban_requests_user_created_index');
        });

        DB::statement(
            "ALTER TABLE ban_requests ADD CONSTRAINT ban_requests_status_check "
            ."CHECK (status IN ('en_attente','acceptee','refusee'))"
        );
        DB::statement(
            "ALTER TABLE ban_requests ADD CONSTRAINT ban_requests_priority_check "
            ."CHECK (priority IN ('normale','haute'))"
        );
    }

    public function down(): void
    {
        Schema::dropIfExists('ban_requests');
    }
};
