<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Journal des decisions de moderation.
 *
 * Une ligne par decision : qui (actor_id), quoi (action), sur qui (user_id),
 * dans quelle rubrique (section) et pourquoi (note). Ce journal est la
 * source de verite du bandeau « Suivi & journal » de l'espace moderateur.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('moderation_actions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('actor_id')->constrained('users')->cascadeOnDelete();
            $table->string('actor_role', 24)->default('moderateur');
            $table->string('action', 32);
            $table->string('target_type', 24);
            $table->unsignedBigInteger('target_id')->nullable();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('section', 40)->nullable();
            $table->text('note');
            $table->jsonb('metadata')->default(DB::raw("'{}'::jsonb"));
            $table->timestamps();

            $table->index(['actor_id', 'created_at'], 'moderation_actions_actor_created_index');
            $table->index(['user_id', 'created_at'], 'moderation_actions_user_created_index');
        });

        DB::statement(
            "ALTER TABLE moderation_actions ADD CONSTRAINT moderation_actions_action_check "
            ."CHECK (action IN ('classer_sans_suite','masquer_contenu','avertir_auteur','bannir_temporaire','escalader','delier'))"
        );
        DB::statement(
            "ALTER TABLE moderation_actions ADD CONSTRAINT moderation_actions_actor_role_check "
            ."CHECK (actor_role IN ('moderateur','direction'))"
        );
    }

    public function down(): void
    {
        Schema::dropIfExists('moderation_actions');
    }
};
