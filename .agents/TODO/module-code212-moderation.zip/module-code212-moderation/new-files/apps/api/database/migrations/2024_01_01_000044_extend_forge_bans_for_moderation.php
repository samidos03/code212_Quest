<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Extension de `forge_bans` pour l'espace moderation.
 *
 * Ajout de la nature (temporaire / definitif), du perimetre (rubrique /
 * plateforme), de la duree en jours, de la voie de recours communiquee et de
 * l'horodatage de notification.
 *
 * `category_id` devient nullable : une sanction de l'espace moderation porte
 * sa rubrique dans `section_slug` (rubriques de la Forge : entraide, projets,
 * coding-league, annonces, cafe). La contrainte de cle etrangere est
 * recreee en nullable.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('forge_bans', function (Blueprint $table): void {
            // La rubrique est desormais portee par `section_slug` : la
            // categorie Forge devient facultative.
            $table->dropForeign(['category_id']);

            $table->string('type', 16)->default('temporaire')->after('reason');
            $table->string('scope', 16)->default('rubrique')->after('type');
            $table->string('section_slug', 40)->nullable()->after('scope');
            $table->unsignedSmallInteger('duration_days')->nullable()->after('section_slug');
            $table->text('appeal_path')->nullable()->after('duration_days');
            $table->timestamp('notified_at')->nullable()->after('appeal_path');
            $table->string('source', 24)->default('moderation')->after('notified_at');

            $table->index(['type', 'expires_at'], 'forge_bans_type_expires_index');
            $table->index('section_slug', 'forge_bans_section_index');
        });

        DB::statement('ALTER TABLE forge_bans ALTER COLUMN category_id DROP NOT NULL');
        DB::statement(
            'ALTER TABLE forge_bans ADD CONSTRAINT forge_bans_category_id_foreign '
            .'FOREIGN KEY (category_id) REFERENCES forge_categories(id) ON DELETE CASCADE'
        );

        DB::statement(
            "ALTER TABLE forge_bans ADD CONSTRAINT forge_bans_type_check "
            ."CHECK (type IN ('temporaire','definitif'))"
        );
        DB::statement(
            "ALTER TABLE forge_bans ADD CONSTRAINT forge_bans_scope_check "
            ."CHECK (scope IN ('rubrique','plateforme'))"
        );
    }

    public function down(): void
    {
        Schema::table('forge_bans', function (Blueprint $table): void {
            $table->dropIndex('forge_bans_type_expires_index');
            $table->dropIndex('forge_bans_section_index');
            $table->dropColumn(['type', 'scope', 'section_slug', 'duration_days', 'appeal_path', 'notified_at', 'source']);
        });

        // Les sanctions de la section moderation sont rattachees a une rubrique
        // et non a une categorie : la colonne redevient obligatoire apres
        // reaffectation manuelle des lignes concernees.
        DB::statement(
            'ALTER TABLE forge_bans DROP CONSTRAINT IF EXISTS forge_bans_category_id_foreign'
        );
        DB::statement('ALTER TABLE forge_bans ALTER COLUMN category_id SET NOT NULL');
        DB::statement(
            'ALTER TABLE forge_bans ADD CONSTRAINT forge_bans_category_id_foreign '
            .'FOREIGN KEY (category_id) REFERENCES forge_categories(id) ON DELETE CASCADE'
        );
    }
};
