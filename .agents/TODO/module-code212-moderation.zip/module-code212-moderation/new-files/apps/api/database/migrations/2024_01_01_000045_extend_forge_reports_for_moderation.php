<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Extension de `forge_reports` pour l'espace moderation.
 *
 * Les signalements portent desormais un motif, une gravite, la rubrique
 * concernee et la decision qui les a clotures. `section_slug` permet de
 * filtrer la file par perimetre de moderation.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('forge_reports', function (Blueprint $table): void {
            $table->string('motif', 32)->default('autre')->after('reason');
            $table->string('severity', 16)->default('moyenne')->after('motif');
            $table->string('section_slug', 40)->nullable()->after('severity');
            $table->string('resolution_decision', 32)->nullable()->after('resolution_note');
            $table->foreignId('handled_by')->nullable()->constrained('users')->nullOnDelete()->after('resolved_at');
            $table->timestamp('handled_at')->nullable()->after('handled_by');

            $table->index(['section_slug', 'status'], 'forge_reports_section_status_index');
        });

        // La contrainte de statut d'origine n'autorisait que trois valeurs :
        // l'espace moderation ajoute « en traitement » et « escaladée ».
        DB::statement('ALTER TABLE forge_reports DROP CONSTRAINT IF EXISTS forge_reports_status_check');
        DB::statement(
            "ALTER TABLE forge_reports ADD CONSTRAINT forge_reports_status_check "
            ."CHECK (status IN ('ouverte','en_traitement','escaladee','resolue','rejetee'))"
        );

        DB::statement(
            "ALTER TABLE forge_reports ADD CONSTRAINT forge_reports_severity_check "
            ."CHECK (severity IN ('faible','moyenne','elevee','critique'))"
        );
        DB::statement(
            "ALTER TABLE forge_reports ADD CONSTRAINT forge_reports_motif_check "
            ."CHECK (motif IN ('harcelement','haine','contenu_inapproprie','spam','fraude','hors_sujet','autre'))"
        );
    }

    public function down(): void
    {
        Schema::table('forge_reports', function (Blueprint $table): void {
            $table->dropIndex('forge_reports_section_status_index');
            $table->dropForeign(['handled_by']);
            $table->dropColumn(['motif', 'severity', 'section_slug', 'resolution_decision', 'handled_by', 'handled_at']);
        });
    }
};
