<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ForgeReport;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Signalement tel que presente dans la file de moderation.
 *
 * Format camelCase, aligne sur `apps/web/src/types/index.ts`.
 *
 * @mixin ForgeReport
 */
class ModerationReportResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $author = $this->resource->author();
        $target = $this->resource->thread ?? $this->resource->solution;

        return [
            'id' => $this->id,
            'targetType' => $this->thread_id !== null ? 'discussion' : 'solution',
            'targetId' => $this->thread_id ?? $this->solution_id,
            'title' => str($this->resource->reason)->limit(90),
            'excerpt' => str($target?->body ?? $this->resource->reason)->limit(160),
            'section' => $this->section_slug ?? 'entraide',
            'reason' => $this->reason,
            'motif' => $this->motif->value,
            'motifLabel' => $this->motif->label(),
            'severity' => $this->severity->value,
            'severityLabel' => $this->severity->label(),
            'status' => $this->status->value,
            'statusLabel' => $this->status->label(),
            'reportCount' => $this->resource->reporter_id !== null
                ? ForgeReport::query()
                    ->where('thread_id', $this->thread_id)
                    ->where('solution_id', $this->solution_id)
                    ->count()
                : 1,
            'reporterName' => $this->resource->reporter?->leaderboardAlias() ?? 'Anonyme',
            'reporterId' => $this->reporter_id,
            'authorId' => $author?->getKey(),
            'authorName' => $author?->name ?? 'Compte supprimé',
            'authorPseudonym' => $author?->pseudonym ?? '—',
            'createdAt' => $this->created_at?->toIso8601String(),
            'handledBy' => $this->resource->handler?->name,
            'handledAt' => $this->handled_at?->toIso8601String(),
            'resolutionDecision' => $this->resolution_decision,
            'resolutionNote' => $this->resolution_note,
        ];
    }
}
