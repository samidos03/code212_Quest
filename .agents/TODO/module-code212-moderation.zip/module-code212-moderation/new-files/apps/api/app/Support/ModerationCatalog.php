<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Referentiel de moderation — Code212 Quest.
 *
 * Source de verite unique cote API : motifs, decisions, voie de recours et
 * limites de sanction. Les libelles sont alignes sur
 * `apps/web/src/lib/moderation.ts`.
 */
final class ModerationCatalog
{
    /** Duree minimale d'un bannissement temporaire, en jours. */
    public const TEMPORARY_BAN_MIN_DAYS = 1;

    /** Duree maximale d'un bannissement temporaire, en jours. */
    public const TEMPORARY_BAN_MAX_DAYS = 7;

    /** Delai de traitement cible d'un signalement, en heures. */
    public const REPORT_SLA_HOURS = 48;

    /**
     * Voie de recours communiquee a toute personne sanctionnee.
     */
    public const APPEAL_PATH = 'Toute décision de modération peut être contestée sous 7 jours '
        .'auprès de l\'espace « Mes signalements » (rubrique « Recours »), ou par courriel à '
        .'moderation@code212.ma. Le dossier est examiné par un administrateur différent de celui '
        .'qui a pris la décision.';

    /**
     * Motifs de signalement.
     *
     * @return array<string, array{label: string, description: string}>
     */
    public static function motifs(): array
    {
        return [
            'harcelement' => [
                'label' => 'Harcèlement',
                'description' => 'Atteinte personnelle répétée, intimidation ou mise en demeure.',
            ],
            'haine' => [
                'label' => 'Haine ou discrimination',
                'description' => 'Propos haineux fondés sur une caractéristique protégée.',
            ],
            'contenu_inapproprie' => [
                'label' => 'Contenu inapproprié',
                'description' => 'Contenu choquant ou contraire aux règles de la communauté.',
            ],
            'spam' => [
                'label' => 'Spam et publicité',
                'description' => 'Messages promotionnels répétés ou hors sujet.',
            ],
            'fraude' => [
                'label' => 'Fraude ou triche',
                'description' => 'Copie de travaux, usurpation d\'identité ou manipulation des résultats.',
            ],
            'hors_sujet' => [
                'label' => 'Hors sujet',
                'description' => 'Contenu sans lien avec la Forge ou ses rubriques.',
            ],
            'autre' => [
                'label' => 'Autre motif',
                'description' => 'Motif non listé, à qualifier dans la note de modération.',
            ],
        ];
    }

    /**
     * Libelle d'un motif.
     */
    public static function motifLabel(string $motif): string
    {
        return self::motifs()[$motif]['label'] ?? 'Autre motif';
    }

    /**
     * Decisions de moderation et autorite de decision.
     *
     * @return array<string, array{label: string, authority: string, description: string}>
     */
    public static function decisions(): array
    {
        return [
            'classer_sans_suite' => [
                'label' => 'Classer sans suite',
                'authority' => 'moderateur',
                'description' => 'Le signalement est clos sans sanction : l\'auteur reçoit un accusé de réception.',
            ],
            'masquer_contenu' => [
                'label' => 'Masquer le contenu',
                'authority' => 'moderateur',
                'description' => 'Le fil ou la réponse est retiré de la rubrique et l\'auteur est informé.',
            ],
            'avertir_auteur' => [
                'label' => 'Avertir l\'auteur',
                'authority' => 'moderateur',
                'description' => 'Avertissement écrit, sans sanction, avec la voie de recours.',
            ],
            'bannir_temporaire' => [
                'label' => 'Bannissement temporaire',
                'authority' => 'moderateur',
                'description' => 'Exclusion de 1 à 7 jours de la rubrique concernée.',
            ],
            'escalader' => [
                'label' => 'Escalade à la Direction',
                'authority' => 'direction',
                'description' => 'Demande de bannissement définitif : la décision appartient à la Direction.',
            ],
        ];
    }

    /**
     * Libelle d'une decision.
     */
    public static function decisionLabel(string $decision): string
    {
        return self::decisions()[$decision]['label'] ?? 'Décision de modération';
    }

    /**
     * La decision releve-t-elle de la Direction ?
     */
    public static function requiresDirection(string $decision): bool
    {
        return (self::decisions()[$decision]['authority'] ?? 'moderateur') === 'direction';
    }
}
