<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Vue d'ensemble de l'espace moderation.
 *
 * @mixin \App\Services\ModerationService
 */
class ModeratorQueueResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $payload = $this->resource;

        return [
            'sections' => $payload['sections'],
            'stats' => $payload['stats'],
            'reports' => ModerationReportResource::collection($payload['reports']),
            'users' => $payload['users'],
            'bans' => ModerationBanResource::collection($payload['bans']),
            'escalations' => BanEscalationResource::collection($payload['escalations']),
            'actions' => ModerationActionResource::collection($payload['actions']),
        ];
    }
}
