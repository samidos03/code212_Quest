<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Statut d'un compte au regard de la moderation.
 */
enum ModerationStatus: string
{
    case Active = 'actif';
    case UnderSurveillance = 'surveille';
    case BannedTemporarily = 'banni_temporaire';
    case BannedPermanently = 'banni_definitif';

    public function label(): string
    {
        return match ($this) {
            self::Active => 'Actif',
            self::UnderSurveillance => 'Sous surveillance',
            self::BannedTemporarily => 'Banni temporairement',
            self::BannedPermanently => 'Banni définitivement',
        };
    }
}
