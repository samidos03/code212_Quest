<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Moderator;

use App\Enums\EscalationPriority;
use App\Enums\ModerationDecision;
use App\Http\Controllers\Controller;
use App\Http\Requests\DecideBanEscalationRequest;
use App\Http\Requests\EscalateBanRequest;
use App\Http\Requests\ResolveModerationReportRequest;
use App\Http\Resources\BanEscalationResource;
use App\Http\Resources\ModerationBanResource;
use App\Http\Resources\ModerationReportResource;
use App\Http\Resources\ModeratorQueueResource;
use App\Models\BanRequest;
use App\Models\ForgeBan;
use App\Models\ForgeReport;
use App\Models\User;
use App\Services\ModerationService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Espace « workspaces moderateur » : file de moderation.
 *
 * Regle de gouvernance appliquee par le service :
 *  - le modérateur traite les signalements de SES rubriques ;
 *  - il peut appliquer un bannissement TEMPORAIRE de 1 a 7 jours ;
 *  - il ne peut pas prononcer d'exclusion definitive : il escalade le dossier
 *    a la Direction, seule habilitee a statuer.
 */
class ModeratorQueueController extends Controller
{
    public function __construct(private readonly ModerationService $moderation)
    {
    }

    /**
     * Vue d'ensemble de l'espace moderation, filtree sur le perimetre.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', $request->user());

        return ApiResponse::resource(new ModeratorQueueResource($this->moderation->queue($request->user())));
    }

    /**
     * Traiter un signalement.
     */
    public function resolve(
        Request $request,
        ForgeReport $report,
        ResolveModerationReportRequest $formRequest,
    ): JsonResponse {
        $this->authorize('resolve', $request->user(), $report);

        /** @var array{decision: string, note?: string|null, durationDays?: int|null, section?: string|null} $validated */
        $validated = $formRequest->validated();

        $decision = ModerationDecision::from($validated['decision']);

        $updated = $this->moderation->resolve(
            $report,
            $request->user(),
            $decision,
            $validated['note'] ?? null,
            $validated['durationDays'] ?? null,
        );

        return ApiResponse::resource(new ModerationReportResource($updated));
    }

    /**
     * Escalader un dossier a la Direction (demande d'exclusion definitive).
     */
    public function escalate(Request $request, EscalateBanRequest $formRequest): JsonResponse
    {
        $this->authorize('escalate', $request->user());

        /** @var array{userId: int, section: string, reason: string, evidence: string, reportIds?: list<int>, priority: string} $validated */
        $validated = $formRequest->validated();

        $target = User::query()->findOrFail($validated['userId']);

        $request_ = $this->moderation->escalate(
            $target,
            $validated['section'],
            $validated['reason'],
            $validated['evidence'],
            $validated['reportIds'] ?? [],
            EscalationPriority::from($validated['priority']),
            $request->user(),
        );

        return ApiResponse::resource(new BanEscalationResource($request_), 201);
    }

    /**
     * Lever un bannissement (recours accorde, ou erreur de l'agent).
     */
    public function revoke(Request $request, ForgeBan $ban): JsonResponse
    {
        $this->authorize('revoke', $request->user(), $ban);

        $note = (string) $request->input('note', '');

        if (trim($note) === '') {
            return ApiResponse::error('Motivez la levée du bannissement.', 422, [
                'note' => ['Indiquez le motif de la levée.'],
            ]);
        }

        $updated = $this->moderation->revokeBan($ban, $request->user(), $note);

        return ApiResponse::resource(new ModerationBanResource($updated));
    }

    /**
     * La Direction statue sur une demande d'exclusion definitive.
     */
    public function decide(
        Request $request,
        BanRequest $banRequest,
        DecideBanEscalationRequest $formRequest,
    ): JsonResponse {
        $this->authorize('decide', $request->user(), $banRequest);

        /** @var array{decision: string, note?: string|null} $validated */
        $validated = $formRequest->validated();

        $updated = $this->moderation->decideEscalation(
            $banRequest,
            $request->user(),
            $validated['decision'],
            $validated['note'] ?? null,
        );

        return ApiResponse::resource(new BanEscalationResource($updated));
    }
}
