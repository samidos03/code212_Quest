<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Enums\ModerationDecision;
use App\Models\ForgeReport;
use App\Support\ModerationCatalog;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/**
 * Notification d'une decision de moderation.
 *
 * La notification porte systematiquement la voie de recours : toute sanction
 * est contestable, et l'interlocuteur doit le savoir.
 */
class ModerationDecisionNotification extends Notification
{
    use Queueable;

    public function __construct(
        private readonly ?ForgeReport $report = null,
        private readonly ModerationDecision $decision = ModerationDecision::Dismiss,
        private readonly ?string $note = null,
        private readonly ?int $durationDays = null,
    ) {
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $message = (new MailMessage)
            ->subject('Code212 Quest — '.$this->decision->label())
            ->greeting('Bonjour '.$notifiable->name.',')
            ->line('Une décision de modération a été prise à votre sujet sur La Forge.');

        if ($this->report !== null) {
            $message->line('Contenu concerné : « '.str($this->report->reason)->limit(180).' ».');
        }

        if ($this->note !== null && $this->note !== '') {
            $message->line('Motif communiqué : '.$this->note);
        }

        if ($this->durationDays !== null) {
            $endsAt = now()->addDays($this->durationDays);
            $message->line(sprintf(
                'Exclusion temporaire de %d jour%s, jusqu’au %s inclus.',
                $this->durationDays,
                $this->durationDays > 1 ? 's' : '',
                $endsAt->format('d/m/Y'),
            ));
        }

        $message->line('La décision et son horodatage sont consignés dans le journal de modération.');

        return $message
            ->line('Voie de recours : '.ModerationCatalog::APPEAL_PATH)
            ->salutation('L’équipe de modération — Centre CODE212');
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'decision' => $this->decision->value,
            'note' => $this->note,
            'duration_days' => $this->durationDays,
            'appeal_path' => ModerationCatalog::APPEAL_PATH,
        ];
    }
}
