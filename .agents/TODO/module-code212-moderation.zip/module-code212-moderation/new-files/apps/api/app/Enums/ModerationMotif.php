<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Motifs de signalement (alignes sur `apps/web/src/lib/moderation.ts`).
 */
enum ModerationMotif: string
{
    case Harassment = 'harcelement';
    case Hate = 'haine';
    case Inappropriate = 'contenu_inapproprie';
    case Spam = 'spam';
    case Fraud = 'fraude';
    case OffTopic = 'hors_sujet';
    case Other = 'autre';

    public function label(): string
    {
        return match ($this) {
            self::Harassment => 'Harcèlement',
            self::Hate => 'Haine ou discrimination',
            self::Inappropriate => 'Contenu inapproprié',
            self::Spam => 'Spam et publicité',
            self::Fraud => 'Fraude ou triche',
            self::OffTopic => 'Hors sujet',
            self::Other => 'Autre motif',
        };
    }

    /**
     * Gravite par defaut, utilisee pour trier la file quand le signalement
     * n'en precise pas.
     */
    public function defaultSeverity(): ModerationSeverity
    {
        return match ($this) {
            self::Hate => ModerationSeverity::Critical,
            self::Harassment, self::Fraud => ModerationSeverity::High,
            self::Inappropriate, self::Other => ModerationSeverity::Medium,
            self::Spam, self::OffTopic => ModerationSeverity::Low,
        };
    }
}
