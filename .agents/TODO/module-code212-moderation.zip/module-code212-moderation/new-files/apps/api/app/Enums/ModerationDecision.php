<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Decisions qu'un moderateur peut prendre sur un signalement.
 *
 * `authority` indique qui decide : le moderateur agit directement, ou il
 * transmet le dossier a la Direction (escalade).
 */
enum ModerationDecision: string
{
    case Dismiss = 'classer_sans_suite';
    case HideContent = 'masquer_contenu';
    case WarnAuthor = 'avertir_auteur';
    case TemporaryBan = 'bannir_temporaire';
    case Escalate = 'escalader';

    public function label(): string
    {
        return match ($this) {
            self::Dismiss => 'Classer sans suite',
            self::HideContent => 'Masquer le contenu',
            self::WarnAuthor => 'Avertir l’auteur',
            self::TemporaryBan => 'Bannissement temporaire',
            self::Escalate => 'Escalade à la Direction',
        };
    }

    /**
     * Autorite de decision : « moderateur » ou « direction ».
     */
    public function authority(): string
    {
        return match ($this) {
            self::Escalate => 'direction',
            default => 'moderateur',
        };
    }

    /**
     * La decision entraine-t-elle une exclusion du compte ?
     */
    public function isSanction(): bool
    {
        return $this === self::TemporaryBan;
    }
}
