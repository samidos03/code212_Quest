<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\EscalationPriority;
use App\Enums\EscalationStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Demande de bannissement definitif transmise par un moderateur a la Direction.
 *
 * Ce n'est PAS une sanction : le compte reste actif tant que la Direction
 * n'a pas statue. La table porte la decision, son auteur et son motif.
 *
 * @property int $id
 * @property int $user_id
 * @property string $section
 * @property int $requested_by
 * @property string $reason
 * @property string $evidence
 * @property list<int> $report_ids
 * @property string $status
 * @property string $priority
 * @property int|null $decided_by
 * @property \Illuminate\Support\Carbon|null $decided_at
 * @property string|null $decision_note
 */
class BanRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'section',
        'requested_by',
        'reason',
        'evidence',
        'report_ids',
        'status',
        'priority',
        'decided_by',
        'decided_at',
        'decision_note',
    ];

    protected function casts(): array
    {
        return [
            'status' => EscalationStatus::class,
            'priority' => EscalationPriority::class,
            'report_ids' => 'array',
            'decided_at' => 'datetime',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
        ];
    }

    /**
     * Le compte concerne par la demande.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Le moderateur qui a transmis le dossier.
     */
    public function requester(): BelongsTo
    {
        return $this->belongsTo(User::class, 'requested_by');
    }

    /**
     * L'admin ou le Directeur qui a statue.
     */
    public function decider(): BelongsTo
    {
        return $this->belongsTo(User::class, 'decided_by');
    }

    /**
     * La demande est-elle encore en attente de decision ?
     */
    public function isPending(): bool
    {
        return $this->status === EscalationStatus::Pending;
    }
}
