<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\BanRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Demande d'exclusion definitive transmise a la Direction.
 *
 * @mixin BanRequest
 */
class BanEscalationResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $user = $this->resource->user;

        return [
            'id' => $this->id,
            'userId' => $this->user_id,
            'userName' => $user?->name ?? 'Compte supprimé',
            'userPseudonym' => $user?->pseudonym ?? '—',
            'section' => $this->section,
            'requestedBy' => $this->resource->requester?->name ?? '—',
            'requestedAt' => $this->created_at?->toIso8601String(),
            'reason' => $this->reason,
            'evidence' => $this->evidence,
            'reportIds' => $this->report_ids ?? [],
            'status' => $this->status->value,
            'statusLabel' => $this->status->label(),
            'priority' => $this->priority->value,
            'priorityLabel' => $this->priority->label(),
            'decidedBy' => $this->resource->decider?->name,
            'decidedAt' => $this->decided_at?->toIso8601String(),
            'decisionNote' => $this->decision_note,
        ];
    }
}
