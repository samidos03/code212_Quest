<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Etat d'une demande de bannissement definitif transmise a la Direction.
 */
enum EscalationStatus: string
{
    case Pending = 'en_attente';
    case Accepted = 'acceptee';
    case Rejected = 'refusee';

    public function label(): string
    {
        return match ($this) {
            self::Pending => 'En attente de la Direction',
            self::Accepted => 'Acceptée',
            self::Rejected => 'Refusée',
        };
    }
}
