<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\BanType;
use App\Enums\EscalationPriority;
use App\Enums\EscalationStatus;
use App\Enums\ForgeReportStatus;
use App\Enums\ModerationDecision;
use App\Enums\ModerationMotif;
use App\Enums\ModerationRiskLevel;
use App\Enums\ModerationStatus;
use App\Enums\ModerationSeverity;
use App\Exceptions\BusinessRuleException;
use App\Models\BanRequest;
use App\Models\ForgeBan;
use App\Models\ForgeReport;
use App\Models\ModerationAction;
use App\Models\ModeratorScope;
use App\Models\User;
use App\Notifications\BanEscalationNotification;
use App\Notifications\ModerationDecisionNotification;
use App\Support\ModerationCatalog;
use App\Support\PermissionCatalog;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Espace de moderation : file, decisions, sanctions temporaires et escalades.
 *
 * Regle de gouvernance centrale : le moderateur applique des sanctions
 * temporaires (1 a 7 jours) et jamais de sanction definitive. L'exclusion
 * definitive est demandee a la Direction, qui seule decide. Chaque decision
 * est journalisee, notifiee a la personne concernee, et accompagnee de la
 * voie de recours.
 */
final class ModerationService
{
    public function __construct(
        private readonly AuditLogger $audit,
    ) {
    }

    /* ------------------------------------------------------------ perimetre */

    /**
     * Rubriques de la Forge confiées au moderateur.
     *
     * Un administrateur dispose d'un acces global : toutes les rubriques.
     *
     * @return list<string>
     */
    public function sectionsFor(User $moderator): array
    {
        if ($moderator->isAdmin()) {
            return array_column(PermissionCatalog::forgeSections(), 'slug');
        }

        $scope = ModeratorScope::query()
            ->where('user_id', $moderator->getKey())
            ->whereNull('revoked_at')
            ->first();

        if ($scope === null || ! $scope->isActive()) {
            return [];
        }

        return $scope->sections ?? [];
    }

    /**
     * Le moderateur peut-il agir sur cette rubrique ?
     */
    public function assertScope(User $moderator, string $section): void
    {
        if ($moderator->isAdmin()) {
            return;
        }

        $sections = $this->sectionsFor($moderator);

        if ($sections === []) {
            throw BusinessRuleException::make(
                'Aucune rubrique ne vous est confiée : demandez un périmètre de modération.',
                [],
                403,
            );
        }

        if (! in_array($section, $sections, true)) {
            throw BusinessRuleException::make(
                sprintf('La rubrique « %s » n’est pas dans votre périmètre de modération.', $section),
                [],
                403,
            );
        }
    }

    /* --------------------------------------------------------------- file */

    /**
     * Vue d'ensemble de l'espace moderation, filtree sur le perimetre.
     *
     * @return array<string, mixed>
     */
    public function queue(User $moderator): array
    {
        $sections = $this->sectionsFor($moderator);
        $isGlobal = $moderator->isAdmin();

        $reports = ForgeReport::query()
            ->with(['thread', 'solution', 'reporter', 'handler'])
            ->when(! $isGlobal, static fn ($query) => $query->whereIn('section_slug', $sections))
            ->latest('created_at')
            ->get();

        $bans = ForgeBan::query()
            ->with(['user'])
            ->when(! $isGlobal, static fn ($query) => $query->whereIn('section_slug', $sections))
            ->latest('created_at')
            ->get();

        $escalations = BanRequest::query()
            ->with(['user', 'requester', 'decider'])
            ->when(! $isGlobal, static fn ($query) => $query->whereIn('section', $sections))
            ->latest('created_at')
            ->get();

        $actions = ModerationAction::query()
            ->with(['actor', 'subject'])
            ->when(! $isGlobal, static fn ($query) => $query->whereIn('section', $sections))
            ->latest('created_at')
            ->limit(60)
            ->get();

        $users = $this->reportedUsers($reports, $bans, $actions);

        return [
            'sections' => $this->sectionSummaries($isGlobal ? [] : $sections, $reports),
            'reports' => $reports,
            'users' => $users,
            'bans' => $bans,
            'escalations' => $escalations,
            'actions' => $actions,
            'stats' => $this->stats($reports, $bans, $escalations, $actions, $users),
        ];
    }

    /**
     * Synthese par rubrique : charge de moderation et modérateurs désignés.
     *
     * @param list<string> $sections
     *
     * @return list<array<string, mixed>>
     */
    private function sectionSummaries(array $sections, Collection $reports): array
    {
        $catalog = PermissionCatalog::forgeSections();

        return array_map(static function (array $section) use ($sections, $reports): array {
            $pending = $reports
                ->filter(static fn (ForgeReport $report): bool => $report->section_slug === $section['slug'])
                ->filter(static fn (ForgeReport $report): bool => $report->status->isPending())
                ->count();

            $total = $reports
                ->filter(static fn (ForgeReport $report): bool => $report->section_slug === $section['slug'])
                ->count();

            $moderators = User::query()
                ->where('roles', '?', json_encode(['moderator']))
                ->pluck('name')
                ->take(3)
                ->all();

            return [
                'slug' => $section['slug'],
                'label' => $section['label'],
                'mine' => in_array($section['slug'], $sections, true),
                'pending' => $pending,
                'totalReports' => $total,
                'moderators' => $moderators,
            ];
        }, $catalog);
    }

    /**
     * Comptes concernes par la moderation, avec leur niveau de risque.
     *
     * @param Collection<int, ForgeReport> $reports
     * @param Collection<int, ForgeBan> $bans
     * @param Collection<int, ModerationAction> $actions
     *
     * @return list<array<string, mixed>>
     */
    private function reportedUsers(Collection $reports, Collection $bans, Collection $actions): array
    {
        $users = User::query()->whereIn('id', $this->subjectIds($reports, $bans, $actions))->get();
        $out = [];

        foreach ($users as $user) {
            $userReports = $reports->filter(static fn (ForgeReport $r): bool => $r->author()?->getKey() === $user->getKey());
            $userBans = $bans->filter(static fn (ForgeBan $b): bool => $b->user_id === $user->getKey());
            $userActions = $actions->filter(static fn (ModerationAction $a): bool => $a->user_id === $user->getKey());

            $hidden = $userActions->filter(static fn (ModerationAction $a): bool => $a->action === ModerationDecision::HideContent)->count();
            $warnings = $userActions->filter(static fn (ModerationAction $a): bool => $a->action === ModerationDecision::WarnAuthor)->count();
            $temporaryBans = $userBans->filter(static fn (ForgeBan $b): bool => $b->type === BanType::Temporary)->count();
            $permanentBans = $userBans->filter(static fn (ForgeBan $b): bool => $b->type === BanType::Permanent)->count();

            $risk = ModerationRiskLevel::fromCounters(
                $userReports->count(),
                $hidden,
                $warnings,
                $temporaryBans + $permanentBans,
            );

            $out[] = [
                'id' => $user->getKey(),
                'fullName' => $user->name,
                'pseudonym' => $user->pseudonym ?? ('Apprenant '.$user->getKey()),
                'email' => $user->email,
                'program' => $user->filiere ?? '—',
                'school' => $user->etablissement ?? '—',
                'status' => $this->userStatus($user, $userBans)->value,
                'riskLevel' => $risk->value,
                'reportsReceived' => $userReports->count(),
                'contentHidden' => $hidden,
                'warnings' => $warnings,
                'temporaryBans' => $temporaryBans,
                'permanentBans' => $permanentBans,
                'firstReportedAt' => $userReports->min('created_at')?->toIso8601String(),
                'lastActivityAt' => $user->last_login_at?->toIso8601String(),
                'topMotifs' => $this->topMotifs($userReports),
                'notes' => $userActions->first()?->note,
            ];
        }

        return $out;
    }

    /**
     * Statut courant d'un compte au regard des exclusions en vigueur.
     *
     * @param Collection<int, ForgeBan> $bans
     */
    private function userStatus(User $user, Collection $bans): ModerationStatus
    {
        $active = $bans->filter(static fn (ForgeBan $ban): bool => $ban->isActive());

        if ($active->contains(static fn (ForgeBan $ban): bool => $ban->type === BanType::Permanent)) {
            return ModerationStatus::BannedPermanently;
        }

        if ($active->contains(static fn (ForgeBan $ban): bool => $ban->type === BanType::Temporary)) {
            return ModerationStatus::BannedTemporarily;
        }

        $warned = (int) ($user->preferences['moderation_warnings'] ?? 0);

        return $warned > 0
            ? ModerationStatus::UnderSurveillance
            : ModerationStatus::Active;
    }

    /**
     * Motifs les plus frequents sur un compte.
     *
     * @param Collection<int, ForgeReport> $reports
     *
     * @return list<array{motif: string, count: int}>
     */
    private function topMotifs(Collection $reports): array
    {
        return $reports
            ->groupBy(static fn (ForgeReport $report): string => $report->motif->value)
            ->map(static fn (Collection $group, string $motif): array => [
                'motif' => $motif,
                'count' => $group->count(),
            ])
            ->sortByDesc(static fn (array $item): int => $item['count'])
            ->values()
            ->take(3)
            ->all();
    }

    /**
     * @param Collection<int, ForgeReport> $reports
     * @param Collection<int, ForgeBan> $bans
     * @param Collection<int, ModerationAction> $actions
     *
     * @return list<int>
     */
    private function subjectIds(Collection $reports, Collection $bans, Collection $actions): array
    {
        $ids = $actions->pluck('user_id')->filter()->map(static fn ($id): int => (int) $id)->all();
        $ids = array_merge($ids, $bans->pluck('user_id')->map(static fn ($id): int => (int) $id)->all());

        foreach ($reports as $report) {
            $authorId = $report->author()?->getKey();

            if ($authorId !== null) {
                $ids[] = $authorId;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Indicateurs de l'espace moderation.
     *
     * @param Collection<int, ForgeReport> $reports
     * @param Collection<int, ForgeBan> $bans
     * @param Collection<int, BanRequest> $escalations
     * @param Collection<int, ModerationAction> $actions
     * @param list<array<string, mixed>> $users
     *
     * @return array<string, int>
     */
    private function stats(
        Collection $reports,
        Collection $bans,
        Collection $escalations,
        Collection $actions,
        array $users,
    ): array {
        $pending = $reports->filter(static fn (ForgeReport $r): bool => $r->status->isPending());
        $sla = Carbon::now()->subHours(ModerationCatalog::REPORT_SLA_HOURS);

        $urgent = $pending->filter(static fn (ForgeReport $r): bool => $r->created_at !== null && $r->created_at->lt($sla))->count();

        $week = Carbon::now()->subDays(7);
        $handled = $actions->filter(static fn (ModerationAction $a): bool => $a->created_at !== null && $a->created_at->gte($week));
        $handledReal = $handled->reject(static fn (ModerationAction $a): bool => $a->action === ModerationDecision::Escalate);

        $avg = $handledReal->isEmpty()
            ? 0
            : (int) round($handledReal->avg(static fn (ModerationAction $a): float => $a->created_at?->diffInHours(now()) ?? 0));

        return [
            'pending' => $pending->count(),
            'urgent' => $urgent,
            'handled7d' => $handled->count(),
            'avgHandlingHours' => $avg,
            'tempBansActive' => $bans->filter(static fn (ForgeBan $b): bool => $b->type === BanType::Temporary && $b->isActive())->count(),
            'permanentBans' => $bans->filter(static fn (ForgeBan $b): bool => $b->type === BanType::Permanent && $b->isActive())->count(),
            'escalationsPending' => $escalations->filter(static fn (BanRequest $e): bool => $e->status === EscalationStatus::Pending)->count(),
            'reportedUsers' => count($users),
        ];
    }

    /* ---------------------------------------------------------- decisions */

    /**
     * Traiter un signalement.
     *
     * Le bannissement temporaire passe par `applyTemporaryBan` : il doit etre
     * rattache a un signalement et dure de 1 a 7 jours.
     */
    public function resolve(
        ForgeReport $report,
        User $actor,
        ModerationDecision $decision,
        ?string $note,
        ?int $durationDays = null,
    ): ForgeReport {
        $section = $report->section_slug ?? 'entraide';

        $this->assertScope($actor, $section);

        if ($decision === ModerationDecision::Escalate) {
            throw BusinessRuleException::make(
                'Utilisez l’escalade pour transmettre un dossier à la Direction.',
            );
        }

        if ($decision === ModerationDecision::TemporaryBan) {
            $author = $report->author();

            if ($author === null) {
                throw BusinessRuleException::make('L’auteur du contenu signalé est introuvable.');
            }

            $this->applyTemporaryBan(
                $author,
                $section,
                $durationDays ?? ModerationCatalog::TEMPORARY_BAN_MIN_DAYS,
                $note ?? 'Manquement aux règles de la communauté.',
                $actor,
                $report,
            );
        }

        $status = match ($decision) {
            ModerationDecision::Dismiss => ForgeReportStatus::Dismissed,
            ModerationDecision::TemporaryBan, ModerationDecision::HideContent, ModerationDecision::WarnAuthor => ForgeReportStatus::Resolved,
            default => ForgeReportStatus::Resolved,
        };

        $report->forceFill([
            'status' => $status->value,
            'resolution_decision' => $decision->value,
            'resolution_note' => $note,
            'resolved_by' => $actor->getKey(),
            'resolved_at' => now(),
            'handled_by' => $actor->getKey(),
            'handled_at' => now(),
        ])->save();

        $this->logAction(
            $actor,
            $decision,
            'report',
            $report->getKey(),
            $report->author()?->getKey(),
            $section,
            $note ?? ModerationCatalog::decisionLabel($decision->value),
        );

        $author = $report->author();

        if ($author !== null) {
            $author->notify(new ModerationDecisionNotification($report, $decision, $note));
        }

        $this->audit->log(
            $actor,
            'moderator.report_resolved',
            'forge_report',
            $report->getKey(),
            $note,
            ['decision' => $decision->value, 'section' => $section],
        );

        return $report->refresh();
    }

    /**
     * Appliquer un bannissement temporaire (1 a 7 jours).
     *
     * Le sanctionne conserve un droit de recours : la voie de recours est
     * enregistree sur la sanction et notifiee.
     */
    public function applyTemporaryBan(
        User $target,
        string $section,
        int $days,
        string $reason,
        User $actor,
        ?ForgeReport $sourceReport = null,
    ): ForgeBan {
        if ($days < ModerationCatalog::TEMPORARY_BAN_MIN_DAYS || $days > ModerationCatalog::TEMPORARY_BAN_MAX_DAYS) {
            throw BusinessRuleException::make(sprintf(
                'Un bannissement temporaire dure de %d à %d jours.',
                ModerationCatalog::TEMPORARY_BAN_MIN_DAYS,
                ModerationCatalog::TEMPORARY_BAN_MAX_DAYS,
            ));
        }

        $this->assertScope($actor, $section);

        if ($actor->getKey() === $target->getKey()) {
            throw BusinessRuleException::make('Vous ne pouvez pas sanctionner votre propre compte.');
        }

        $ban = DB::transaction(function () use ($target, $section, $days, $reason, $actor): ForgeBan {
            return ForgeBan::query()->create([
                'category_id' => null,
                'user_id' => $target->getKey(),
                'reason' => $reason,
                'imposed_by' => $actor->getKey(),
                'expires_at' => now()->addDays($days),
                'type' => BanType::Temporary->value,
                'scope' => 'rubrique',
                'section_slug' => $section,
                'duration_days' => $days,
                'appeal_path' => ModerationCatalog::APPEAL_PATH,
                'notified_at' => null,
                'source' => 'moderation',
            ]);
        });

        $ban->forceFill(['notified_at' => now()])->save();

        $this->logAction(
            $actor,
            ModerationDecision::TemporaryBan,
            'ban',
            $ban->getKey(),
            $target->getKey(),
            $section,
            $reason,
            ['days' => $days, 'sourceReportId' => $sourceReport?->getKey()],
        );

        $target->notify(new ModerationDecisionNotification(
            $sourceReport,
            ModerationDecision::TemporaryBan,
            $reason,
            $days,
        ));

        $this->audit->log(
            $actor,
            'moderator.temporary_ban_applied',
            'forge_ban',
            $ban->getKey(),
            $reason,
            ['user_id' => $target->getKey(), 'days' => $days, 'section' => $section],
        );

        return $ban->refresh();
    }

    /**
     * Escalader un dossier a la Direction.
     *
     * Ce n'est PAS une sanction : la demande est examinee par la Direction,
     * seule habilitee a prononcer une exclusion definitive.
     */
    public function escalate(
        User $target,
        string $section,
        string $reason,
        string $evidence,
        array $reportIds,
        EscalationPriority $priority,
        User $actor,
    ): BanRequest {
        $this->assertScope($actor, $section);

        if ($actor->getKey() === $target->getKey()) {
            throw BusinessRuleException::make('Vous ne pouvez pas demander l’exclusion de votre propre compte.');
        }

        $request = BanRequest::query()->create([
            'user_id' => $target->getKey(),
            'section' => $section,
            'requested_by' => $actor->getKey(),
            'reason' => $reason,
            'evidence' => $evidence,
            'report_ids' => array_values(array_map('intval', $reportIds)),
            'status' => EscalationStatus::Pending->value,
            'priority' => $priority->value,
        ]);

        $this->logAction(
            $actor,
            ModerationDecision::Escalate,
            'escalation',
            $request->getKey(),
            $target->getKey(),
            $section,
            $reason,
            ['priority' => $priority->value, 'reportIds' => $request->report_ids],
        );

        $this->notifyDirection($request);

        $this->audit->log(
            $actor,
            'moderator.ban_escalated',
            'ban_request',
            $request->getKey(),
            $reason,
            ['user_id' => $target->getKey(), 'section' => $section],
        );

        return $request->refresh();
    }

    /**
     * Lever un bannissement (recours accorde, ou erreur de l'agent).
     */
    public function revokeBan(ForgeBan $ban, User $actor, string $note): ForgeBan
    {
        if ($ban->revoked_at !== null) {
            throw BusinessRuleException::make('Ce bannissement est déjà levé.');
        }

        if (! $actor->isAdmin()) {
            // Symetrie des pouvoirs : le moderateur leve les sanctions
            // temporaires de son perimetre ; l'exclusion definitive releve
            // de la Direction.
            if ($ban->type !== BanType::Temporary) {
                throw BusinessRuleException::make(
                    'Seul un administrateur peut lever une exclusion définitive.',
                    [],
                    403,
                );
            }

            $this->assertScope($actor, $this->sectionOfBan($ban));
        }

        $ban->forceFill([
            'revoked_at' => now(),
            'revoked_by' => $actor->getKey(),
        ])->save();

        $this->logAction(
            $actor,
            ModerationDecision::Dismiss,
            'ban',
            $ban->getKey(),
            $ban->user_id,
            $this->sectionOfBan($ban),
            $note !== '' ? $note : 'Bannissement levé.',
            ['revoked' => true],
        );

        $target = $ban->user;

        if ($target !== null) {
            $target->notify(new ModerationDecisionNotification(null, ModerationDecision::Dismiss, $note));
        }

        $this->audit->log(
            $actor,
            'moderator.ban_revoked',
            'forge_ban',
            $ban->getKey(),
            $note,
            ['user_id' => $ban->user_id],
        );

        return $ban->refresh();
    }

    /**
     * La Direction statue sur une demande d'exclusion definitive.
     *
     * Reserve aux administrateurs : c'est la contrepartie de l'escalade.
     */
    public function decideEscalation(
        BanRequest $request,
        User $actor,
        string $decision,
        ?string $note = null,
    ): BanRequest {
        if (! $actor->isAdmin()) {
            throw BusinessRuleException::make(
                'Seul un administrateur peut statuer sur une exclusion définitive.',
                [],
                403,
            );
        }

        if (! $request->isPending()) {
            throw BusinessRuleException::make('Cette demande a déjà été tranchée.');
        }

        $accepted = $decision === 'acceptee';

        $request->forceFill([
            'status' => $accepted ? EscalationStatus::Accepted->value : EscalationStatus::Rejected->value,
            'decided_by' => $actor->getKey(),
            'decided_at' => now(),
            'decision_note' => $note,
        ])->save();

        if ($accepted) {
            $target = $request->user;

            if ($target !== null) {
                $ban = ForgeBan::query()->create([
                    'category_id' => null,
                    'user_id' => $target->getKey(),
                    'reason' => $request->reason,
                    'imposed_by' => $actor->getKey(),
                    'expires_at' => null,
                    'type' => BanType::Permanent->value,
                    'scope' => 'plateforme',
                    'section_slug' => $request->section,
                    'duration_days' => null,
                    'appeal_path' => ModerationCatalog::APPEAL_PATH,
                    'notified_at' => now(),
                    'source' => 'direction',
                ]);

                $this->logAction(
                    $actor,
                    ModerationDecision::TemporaryBan,
                    'ban',
                    $ban->getKey(),
                    $target->getKey(),
                    $request->section,
                    $note ?? 'Exclusion définitive prononcée par la Direction.',
                    ['permanent' => true, 'banRequestId' => $request->getKey()],
                );

                $target->notify(new ModerationDecisionNotification(
                    null,
                    ModerationDecision::TemporaryBan,
                    $note ?? 'Exclusion définitive prononcée par la Direction.',
                ));
            }
        }

        $this->logAction(
            $actor,
            ModerationDecision::Dismiss,
            'escalation',
            $request->getKey(),
            $request->user_id,
            $request->section,
            $note ?? ($accepted ? 'Demande acceptée par la Direction.' : 'Demande refusée par la Direction.'),
            ['decision' => $decision],
        );

        $this->audit->log(
            $actor,
            'director.ban_escalation_decided',
            'ban_request',
            $request->getKey(),
            $note,
            ['decision' => $decision, 'user_id' => $request->user_id],
        );

        return $request->refresh();
    }

    /* ------------------------------------------------------------ helpers */

    /**
     * Enregistrer une decision dans le journal de moderation.
     *
     * @param array<string, mixed> $metadata
     */
    private function logAction(
        User $actor,
        ModerationDecision $decision,
        string $targetType,
        int $targetId,
        ?int $userId,
        ?string $section,
        string $note,
        array $metadata = [],
    ): ModerationAction {
        return ModerationAction::query()->create([
            'actor_id' => $actor->getKey(),
            'actor_role' => $actor->isAdmin() ? 'direction' : 'moderateur',
            'action' => $decision->value,
            'target_type' => $targetType,
            'target_id' => $targetId,
            'user_id' => $userId,
            'section' => $section,
            'note' => $note,
            'metadata' => $metadata,
        ]);
    }

    /**
     * Notifier la Direction d'une demande d'exclusion definitive.
     */
    private function notifyDirection(BanRequest $request): void
    {
        $recipients = User::query()
            ->where('roles', '?', json_encode(['admin']))
            ->get();

        foreach ($recipients as $recipient) {
            $recipient->notify(new BanEscalationNotification($request));
        }
    }

    /**
     * Rubrique rattachee a un bannissement.
     */
    private function sectionOfBan(ForgeBan $ban): string
    {
        return $ban->section_slug ?? 'entraide';
    }

    /**
     * Severite par defaut d'un motif.
     */
    public function defaultSeverity(string $motif): ModerationSeverity
    {
        return ModerationMotif::from($motif)->defaultSeverity();
    }
}
