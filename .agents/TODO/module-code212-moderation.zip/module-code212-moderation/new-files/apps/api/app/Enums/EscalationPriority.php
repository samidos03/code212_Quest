<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Priorite d'un dossier escalade.
 */
enum EscalationPriority: string
{
    case Normal = 'normale';
    case High = 'haute';

    public function label(): string
    {
        return match ($this) {
            self::Normal => 'Normale — 7 jours',
            self::High => 'Haute — 48 heures',
        };
    }

    /**
     * Delai de traitement cible, en heures.
     */
    public function slaHours(): int
    {
        return match ($this) {
            self::Normal => 168,
            self::High => 48,
        };
    }
}
