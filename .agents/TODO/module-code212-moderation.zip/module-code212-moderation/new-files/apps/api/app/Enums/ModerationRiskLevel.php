<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Niveau de risque calcule sur un compte signale.
 */
enum ModerationRiskLevel: string
{
    case Low = 'faible';
    case Medium = 'moyen';
    case High = 'eleve';
    case Critical = 'critique';

    public function label(): string
    {
        return match ($this) {
            self::Low => 'Risque faible',
            self::Medium => 'Risque moyen',
            self::High => 'Risque élevé',
            self::Critical => 'Risque critique',
        };
    }

    /**
     * Calcul du niveau de risque a partir des compteurs de signalements.
     *
     * Le score croise le nombre de signalements, les contenus masques, les
     * avertissements et les bannissements deja prononces.
     */
    public static function fromCounters(int $reports, int $hidden, int $warnings, int $bans): self
    {
        $score = ($reports * 2) + ($hidden * 2) + ($warnings * 3) + ($bans * 6);

        return match (true) {
            $score >= 24 => self::Critical,
            $score >= 14 => self::High,
            $score >= 6 => self::Medium,
            default => self::Low,
        };
    }
}
