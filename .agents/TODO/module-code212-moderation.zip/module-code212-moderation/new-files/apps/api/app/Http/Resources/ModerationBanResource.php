<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ForgeBan;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Bannissement tel que presente dans l'espace moderation.
 *
 * @mixin ForgeBan
 */
class ModerationBanResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $user = $this->resource->user;

        return [
            'id' => $this->id,
            'userId' => $this->user_id,
            'userName' => $user?->name ?? 'Compte supprimé',
            'userPseudonym' => $user?->pseudonym ?? '—',
            'section' => $this->section_slug ?? 'entraide',
            'scope' => $this->scope,
            'type' => $this->type->value,
            'durationDays' => $this->duration_days,
            'reason' => $this->reason,
            'imposedBy' => $this->resource->imposedBy?->name ?? 'Système',
            'imposedByRole' => $this->source === 'direction' ? 'direction' : 'moderateur',
            'createdAt' => $this->created_at?->toIso8601String(),
            'expiresAt' => $this->expires_at?->toIso8601String(),
            'revokedAt' => $this->revoked_at?->toIso8601String(),
            'revokedBy' => $this->resource->revokedBy?->name,
            'appealPath' => $this->appeal_path,
            'notifiedAt' => $this->notified_at?->toIso8601String(),
            'sourceReportId' => null,
        ];
    }
}
