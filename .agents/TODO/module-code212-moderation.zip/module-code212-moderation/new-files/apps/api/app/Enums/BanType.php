<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Nature d'une exclusion.
 *
 * Seule une exclusion temporaire peut etre prononcee par un moderateur ;
 * l'exclusion definitive est decidee par la Direction.
 */
enum BanType: string
{
    case Temporary = 'temporaire';
    case Permanent = 'definitif';

    public function label(): string
    {
        return match ($this) {
            self::Temporary => 'Temporaire',
            self::Permanent => 'Définitif',
        };
    }
}
