<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Decision de la Direction sur une demande d'exclusion definitive.
 */
class DecideBanEscalationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() === true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'decision' => ['required', Rule::in(['acceptee', 'refusee'])],
            'note' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
