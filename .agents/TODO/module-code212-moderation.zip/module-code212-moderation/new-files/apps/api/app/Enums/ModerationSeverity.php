<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Gravite d'un signalement.
 */
enum ModerationSeverity: string
{
    case Low = 'faible';
    case Medium = 'moyenne';
    case High = 'elevee';
    case Critical = 'critique';

    public function label(): string
    {
        return match ($this) {
            self::Low => 'Faible',
            self::Medium => 'Moyenne',
            self::High => 'Élevée',
            self::Critical => 'Critique',
        };
    }

    /**
     * Ordre de triage : plus la valeur est haute, plus le signalement est
     * prioritaire dans la file.
     */
    public function weight(): int
    {
        return match ($this) {
            self::Low => 1,
            self::Medium => 2,
            self::High => 3,
            self::Critical => 4,
        };
    }
}
