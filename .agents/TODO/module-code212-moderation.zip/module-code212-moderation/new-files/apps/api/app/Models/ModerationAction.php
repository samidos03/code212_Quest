<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\ModerationDecision;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Journal des decisions de moderation.
 *
 * Chaque ligne est une decision : qui, quoi, sur qui, dans quelle rubrique et
 * pour quel motif. C'est la source de verite du journal affiche dans
 * l'espace modérateur.
 *
 * @property int $id
 * @property int $actor_id
 * @property string $actor_role
 * @property string $action
 * @property string $target_type
 * @property int|null $target_id
 * @property int|null $user_id
 * @property string|null $section
 * @property string $note
 * @property array<string, mixed> $metadata
 */
class ModerationAction extends Model
{
    use HasFactory;

    protected $fillable = [
        'actor_id',
        'actor_role',
        'action',
        'target_type',
        'target_id',
        'user_id',
        'section',
        'note',
        'metadata',
    ];

    protected function casts(): array
    {
        return [
            'action' => ModerationDecision::class,
            'metadata' => 'array',
            'created_at' => 'datetime',
            'updated_at' => 'datetime',
        ];
    }

    public function actor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'actor_id');
    }

    /**
     * La personne concernee par la decision.
     */
    public function subject(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
