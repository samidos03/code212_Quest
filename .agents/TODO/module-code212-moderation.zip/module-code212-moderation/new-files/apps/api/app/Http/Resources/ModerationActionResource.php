<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ModerationAction;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Decision de moderation journalisee.
 *
 * @mixin ModerationAction
 */
class ModerationActionResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $target = $this->resource->subject;

        return [
            'id' => $this->id,
            'action' => $this->action->value,
            'actionLabel' => $this->action->label(),
            'targetType' => $this->target_type,
            'targetId' => $this->target_id,
            'targetLabel' => $target?->name ?? (string) $this->target_id,
            'userId' => $this->user_id,
            'userName' => $target?->name,
            'actor' => $this->resource->actor?->name ?? 'Système',
            'actorRole' => $this->actor_role,
            'note' => $this->note,
            'section' => $this->section,
            'createdAt' => $this->created_at?->toIso8601String(),
            'metadata' => $this->metadata,
        ];
    }
}
