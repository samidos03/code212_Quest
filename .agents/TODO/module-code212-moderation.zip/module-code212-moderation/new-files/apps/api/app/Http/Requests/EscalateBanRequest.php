<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Enums\EscalationPriority;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Demande d'exclusion definitive transmise a la Direction.
 */
class EscalateBanRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'userId' => ['required', 'integer', 'exists:users,id'],
            'section' => ['required', 'string', 'max:40'],
            'reason' => ['required', 'string', 'min:5', 'max:2000'],
            'evidence' => ['required', 'string', 'min:5', 'max:4000'],
            'reportIds' => ['nullable', 'array', 'max:50'],
            'reportIds.*' => ['integer'],
            'priority' => ['required', Rule::in([
                EscalationPriority::Normal->value,
                EscalationPriority::High->value,
            ])],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'reason.min' => 'Indiquez le motif de la demande (5 caractères minimum).',
            'evidence.min' => 'Joignez les éléments du dossier (5 caractères minimum).',
        ];
    }
}
