<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Models\BanRequest;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/**
 * Notification adressee a la Direction lorsqu'un moderateur escalade un
 * dossier d'exclusion definitive.
 *
 * Rappel de gouvernance : l'escalade n'est pas une sanction. Le compte reste
 * actif tant que la Direction n'a pas statue.
 */
class BanEscalationNotification extends Notification
{
    use Queueable;

    public function __construct(private readonly BanRequest $request)
    {
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $target = $this->request->user;

        return (new MailMessage)
            ->subject('Code212 Quest — demande d’exclusion définitive à statuer')
            ->greeting('Bonjour '.$notifiable->name.',')
            ->line('Un modérateur a transmis un dossier d’exclusion définitive pour le compte suivant :')
            ->line('Compte : '.($target?->name ?? 'inconnu').' ('.($target?->email ?? '—').')')
            ->line('Rubrique : '.$this->request->section)
            ->line('Motif : '.$this->request->reason)
            ->line('Priorité : '.$this->request->priority->label())
            ->line('Éléments du dossier :'.PHP_EOL.$this->request->evidence)
            ->line('Le compte reste actif tant que la Direction n’a pas statué.')
            ->salutation('Centre CODE212 — Direction');
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'ban_request_id' => $this->request->getKey(),
            'user_id' => $this->request->user_id,
            'section' => $this->request->section,
            'priority' => $this->request->priority->value,
            'status' => $this->request->status->value,
        ];
    }
}
