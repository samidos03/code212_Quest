<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Enums\ModerationDecision;
use App\Support\ModerationCatalog;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Decision de moderation sur un signalement.
 *
 * Le bannissement temporaire est borne a 1..7 jours : c'est une regle
 * serveur, pas seulement une contrainte d'interface.
 */
class ResolveModerationReportRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'decision' => ['required', Rule::in([
                ModerationDecision::Dismiss->value,
                ModerationDecision::HideContent->value,
                ModerationDecision::WarnAuthor->value,
                ModerationDecision::TemporaryBan->value,
            ])],
            'note' => ['nullable', 'string', 'max:2000'],
            'durationDays' => [
                'nullable',
                'integer',
                'min:'.ModerationCatalog::TEMPORARY_BAN_MIN_DAYS,
                'max:'.ModerationCatalog::TEMPORARY_BAN_MAX_DAYS,
                'required_if:decision,'.ModerationDecision::TemporaryBan->value,
            ],
            'section' => ['nullable', 'string', 'max:40'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'durationDays.min' => 'Un bannissement temporaire dure au moins 1 jour.',
            'durationDays.max' => 'Un bannissement temporaire dure au plus 7 jours.',
            'durationDays.required_if' => 'Indiquez la durée du bannissement temporaire.',
        ];
    }
}
