<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\BanRequest;
use App\Models\ForgeBan;
use App\Models\ForgeReport;
use App\Models\User;

/**
 * Autorisations de l'espace moderation (espace « workspaces moderateur »).
 *
 * L'acces au perimetre lui-meme est verifie par le service
 * (`ModerationService::assertScope`) : la policy verifie le role, le service
 * verifie la rubrique.
 */
class ModeratorQueuePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasRole('moderator') || $user->isAdmin();
    }

    /**
     * Traiter un signalement.
     */
    public function resolve(User $user, ForgeReport $report): bool
    {
        return $user->hasRole('moderator') || $user->isAdmin();
    }

    /**
     * Transmettre un dossier a la Direction.
     */
    public function escalate(User $user): bool
    {
        return $user->hasRole('moderator') || $user->isAdmin();
    }

    /**
     * Lever une sanction.
     *
     * Un modérateur peut lever une sanction temporaire qui releve de son
     * perimetre ; une exclusion definitive ne peut etre levee que par la
     * Direction.
     */
    public function revoke(User $user, ForgeBan $ban): bool
    {
        if ($user->isAdmin()) {
            return true;
        }

        return $user->hasRole('moderator') && $ban->type->value === 'temporaire';
    }

    /**
     * Statuer sur une demande d'exclusion definitive : reserve a la Direction.
     */
    public function decide(User $user, BanRequest $request): bool
    {
        return $user->isAdmin();
    }
}
