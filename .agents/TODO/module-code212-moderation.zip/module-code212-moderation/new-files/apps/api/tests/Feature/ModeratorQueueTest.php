<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\BanRequest;
use App\Models\ForgeBan;
use App\Models\ForgeCategory;
use App\Models\ForgeReport;
use App\Models\ForgeThread;
use App\Models\ModerationAction;
use App\Models\ModeratorScope;
use App\Models\User;
use App\Notifications\BanEscalationNotification;
use App\Notifications\ModerationDecisionNotification;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Notification;
use Laravel\Sanctum\Sanctum;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * Espace moderation : perimetre, sanctions temporaires, escalades.
 *
 * Invariants verifies ici :
 *  - le modérateur ne voit et ne traite que SES rubriques ;
 *  - le bannissement temporaire est borne a 1..7 jours ;
 *  - l'exclusion definitive n'est pas prononcee par le moderateur ;
 *  - chaque decision est journalisee et notifiee, voie de recours incluse.
 */
class ModeratorQueueTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\PermissionSeeder::class);
        $this->seed(\Database\Seeders\SystemRoleSeeder::class);
    }

    /* ---------------------------------------------------------- helpers */

    private function makeModerator(array $sections = ['entraide']): User
    {
        $moderator = $this->makeUser([
            'name' => 'Ghita Amrani',
            'email' => 'mod@uca.ac.ma',
            'roles' => ['moderator'],
        ]);

        ModeratorScope::query()->create([
            'user_id' => $moderator->getKey(),
            'sections' => $sections,
            'scope_note' => 'Relais entraide.',
        ]);

        return $moderator;
    }

    private function makeThread(User $author, string $section): ForgeThread
    {
        $category = ForgeCategory::query()->firstOrCreate(
            ['code' => 'forge-'.$section],
            ['name' => $section, 'position' => 1],
        );

        return ForgeThread::query()->create([
            'category_id' => $category->getKey(),
            'author_id' => $author->getKey(),
            'title' => 'Question sur '.($section === 'entraide' ? 'les pointeurs' : 'le projet'),
            'body' => 'Je bloque sur cette erreur, quelqu’un peut aider ?',
            'status' => 'ouverte',
            'tags' => [],
        ]);
    }

    private function makeReport(User $author, string $section): ForgeReport
    {
        $thread = $this->makeThread($author, $section);

        return ForgeReport::query()->create([
            'thread_id' => $thread->getKey(),
            'reporter_id' => $this->makeUser(['roles' => ['student']])->getKey(),
            'reason' => 'Propos insultants répétés dans la discussion.',
            'status' => 'ouverte',
            'motif' => 'harcelement',
            'severity' => 'elevee',
            'section_slug' => $section,
        ]);
    }

    /* ----------------------------------------------------------- tests */

    #[Test]
    public function un_apprenant_ne_peut_pas_acceder_a_l_espace_moderation(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['student']]), ['read', 'write']);

        $this->getJson('/api/v1/moderator/queue')->assertForbidden();
    }

    #[Test]
    public function un_moderateur_sans_perimetre_ne_peut_pas_acceder_a_la_file(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['moderator']]), ['read', 'write']);

        $this->getJson('/api/v1/moderator/queue')->assertForbidden();
    }

    #[Test]
    public function la_file_est_limitee_aux_rubriques_confiees(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);

        $this->makeReport($auteur, 'entraide');
        $this->makeReport($auteur, 'projets');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $response = $this->getJson('/api/v1/moderator/queue')->assertOk();

        $sections = $response->json('data.reports.*.section');

        $this->assertSame(['entraide'], array_values(array_unique($sections)));
        $this->assertSame(1, $response->json('data.stats.pending'));
    }

    #[Test]
    public function la_vue_ensemble_expose_les_indicateurs_du_perimetre(): void
    {
        $moderator = $this->makeModerator(['entraide', 'cafe']);
        $auteur = $this->makeUser(['roles' => ['student']]);

        $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $response = $this->getJson('/api/v1/moderator/queue')->assertOk();

        $this->assertSame(1, $response->json('data.stats.pending'));
        $this->assertSame(0, $response->json('data.stats.escalationsPending'));
        $this->assertCount(5, $response->json('data.sections'));
        $this->assertTrue($response->json('data.sections.0.mine'));
    }

    #[Test]
    public function traiter_un_signalement_est_journalise_et_notifie(): void
    {
        Notification::fake();

        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'classer_sans_suite',
            'note' => 'Signalement hors du champ, accused de réception envoyé.',
        ])->assertOk();

        $this->assertSame('rejetee', $report->refresh()->status->value);
        $this->assertSame('classer_sans_suite', $report->resolution_decision);

        $action = ModerationAction::query()->firstOrFail();
        $this->assertSame('classer_sans_suite', $action->action->value);
        $this->assertSame($moderator->getKey(), $action->actor_id);

        Notification::assertSentTo($auteur, ModerationDecisionNotification::class);
    }

    #[Test]
    public function un_bannissement_temporaire_est_consigne_avec_la_voie_de_recours(): void
    {
        Notification::fake();

        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'bannir_temporaire',
            'durationDays' => 3,
            'note' => 'Récidive après un avertissement.',
        ])->assertOk();

        $ban = ForgeBan::query()->firstOrFail();

        $this->assertSame('temporaire', $ban->type->value);
        $this->assertSame(3, $ban->duration_days);
        $this->assertSame('entraide', $ban->section_slug);
        $this->assertNotNull($ban->appeal_path);
        $this->assertNotNull($ban->notified_at);
        $this->assertTrue($ban->isActive());

        Notification::assertSentTo($auteur, ModerationDecisionNotification::class);
    }

    #[Test]
    public function un_bannissement_de_plus_de_sept_jours_est_refuse(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'bannir_temporaire',
            'durationDays' => 8,
            'note' => 'Trop long.',
        ])->assertStatus(422);

        $this->assertSame(0, ForgeBan::query()->count());
    }

    #[Test]
    public function un_bannissement_hors_perimetre_est_refuse(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'projets');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'bannir_temporaire',
            'durationDays' => 2,
            'note' => 'Hors perimetre.',
        ])->assertForbidden();

        $this->assertSame(0, ForgeBan::query()->count());
    }

    #[Test]
    public function une_escalade_est_transmise_a_la_direction_et_notifiee(): void
    {
        Notification::fake();

        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $admin = $this->makeUser(['roles' => ['admin']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson('/api/v1/moderator/queue/escalations', [
            'userId' => $auteur->getKey(),
            'section' => 'entraide',
            'reason' => 'Récidive après un bannissement temporaire déjà servi.',
            'evidence' => 'Deux signalements retenus, un avertissement enregistré.',
            'reportIds' => [$report->getKey()],
            'priority' => 'haute',
        ])->assertCreated();

        $escalation = BanRequest::query()->firstOrFail();

        $this->assertSame('en_attente', $escalation->status->value);
        $this->assertSame('haute', $escalation->priority->value);
        $this->assertSame([$report->getKey()], $escalation->report_ids);

        Notification::assertSentTo($admin, BanEscalationNotification::class);
    }

    #[Test]
    public function un_moderateur_ne_peut_pas_statuer_sur_une_escalade(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $escalation = $this->postJson('/api/v1/moderator/queue/escalations', [
            'userId' => $auteur->getKey(),
            'section' => 'entraide',
            'reason' => 'Récidive après bannissement temporaire.',
            'evidence' => 'Deux signalements retenus au total.',
            'reportIds' => [$report->getKey()],
            'priority' => 'normale',
        ])->json('data.id');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/admin/moderation/escalations/{$escalation}/decide", [
            'decision' => 'acceptee',
            'note' => 'Je tranche moi-meme.',
        ])->assertForbidden();
    }

    #[Test]
    public function la_direction_accepte_une_escalade_et_prononce_l_exclusion(): void
    {
        Notification::fake();

        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $admin = $this->makeUser(['roles' => ['admin']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $escalation = $this->postJson('/api/v1/moderator/queue/escalations', [
            'userId' => $auteur->getKey(),
            'section' => 'entraide',
            'reason' => 'Récidive après bannissement temporaire.',
            'evidence' => 'Deux signalements retenus au total.',
            'reportIds' => [$report->getKey()],
            'priority' => 'haute',
        ])->json('data.id');

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson("/api/v1/admin/moderation/escalations/{$escalation}/decide", [
            'decision' => 'acceptee',
            'note' => 'Exclusion définitive prononcée par la Direction.',
        ])->assertOk();

        $this->assertSame('acceptee', BanRequest::query()->firstOrFail()->status->value);

        $ban = ForgeBan::query()->firstOrFail();
        $this->assertSame('definitif', $ban->type->value);
        $this->assertSame('plateforme', $ban->scope);
        $this->assertSame('direction', $ban->source);
    }

    #[Test]
    public function un_moderateur_peut_lever_un_bannissement_temporaire_de_son_perimetre(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'bannir_temporaire',
            'durationDays' => 2,
            'note' => 'Premier manquement.',
        ])->assertOk();

        $ban = ForgeBan::query()->firstOrFail();

        $this->deleteJson("/api/v1/moderator/queue/bans/{$ban->getKey()}", [
            'note' => 'Recours accepte : un avertissement suffit.',
        ])->assertOk();

        $this->assertNotNull($ban->refresh()->revoked_at);
    }

    #[Test]
    public function lever_un_bannissement_exige_un_motif(): void
    {
        $moderator = $this->makeModerator(['entraide']);
        $auteur = $this->makeUser(['roles' => ['student']]);
        $report = $this->makeReport($auteur, 'entraide');

        Sanctum::actingAs($moderator, ['read', 'write']);

        $this->postJson("/api/v1/moderator/queue/reports/{$report->getKey()}/resolve", [
            'decision' => 'bannir_temporaire',
            'durationDays' => 2,
            'note' => 'Premier manquement.',
        ])->assertOk();

        $ban = ForgeBan::query()->firstOrFail();

        $this->deleteJson("/api/v1/moderator/queue/bans/{$ban->getKey()}")
            ->assertStatus(422);
    }
}
