# Harnais de démonstration — module « Rôles & accès »

Mini-application contenant **uniquement** le module, pour le tester sans l'application
complète. Aucune installation de l'application n'est nécessaire.

---

## 1. Lancer

```bash
cd demo
npm install       # ou : ln -s ../../code212-quest/apps/web/node_modules node_modules
npm run dev
```

Ouvrez **http://localhost:5174**.

| Commande | Effet |
|---|---|
| `npm run dev` | Serveur de développement (port 5174) |
| `npm run build` | Build de production (typecheck + Vite) |
| `npm run preview` | Sert le build sur le port 5174 |
| `npm run typecheck` | TypeScript strict, sans émission |

> Si l'application est déjà installée sur la machine, l'installation des dépendances est inutile :
> `ln -s ../chemin/vers/apps/web/node_modules node_modules` (les versions sont identiques).

---

## 2. Ce que contient ce harnais

| Élément | Rôle |
|---|---|
| `src/pages/admin/admin-roles-page.tsx` | **Le module**, fichier identique à celui livré dans `new-files/` |
| `src/components/shared/permission-matrix.tsx` | Matrice de permissions, identique au livrable |
| `src/lib/permissions.ts` · `src/lib/schools.ts` | Catalogue et référentiels, identiques au livrable |
| `src/components/ui/*` | Composants partagés (bouton, dialogue, champ, select, badge, toast) |
| `src/components/shared/page-header.tsx` | En-tête de page |
| `src/services/api.ts` · `src/hooks/use-api.ts` | Facade API et hooks — identiques au livrable |
| `src/services/mock/*` | Adaptateur de démonstration : **données en mémoire** |
| `src/types/index.ts` | Types métier |
| `src/index.css` · `tailwind.config.ts` · `public/fonts` | Design system Code212 (identique à l'application) |

La **page du module et la matrice de permissions sont les fichiers exacts du livrable** :
ce que vous voyez ici est ce que le stagiaire obtiendra après intégration.

---

## 3. Ce qui fonctionne

- Les 5 onglets et la vue matrice.
- La création d'un rôle personnalisé (avec la matrice de permissions).
- La nomination d'un membre par email, avec recherche instantanée et détection de conflit.
- La nomination d'un modérateur (rubriques de La Forge, mandat, note de cadrage).
- La révocation d'une nomination, la suspension d'un compte, l'export CSV.
- Le journal des accès, mis à jour après chaque action.
- Les notifications (toasts) et les refus métier : doublon de rôle, conflit d'intérêts,
  administrateur déjà en accès global.

## 4. Ce qui est simulé

- **Les données sont en mémoire** : un rechargement de la page remet tout à l'état initial
  (bouton « Réinitialiser » en haut).
- **L'API Laravel n'est pas sollicitée.** L'adaptateur `src/services/mock` reproduit les mêmes
  règles que le backend (catalogue de permissions validé, conflits refusés, mandat daté,
  administrateur sans périmètre de modération).
- Pour tester contre la vraie API : `VITE_USE_MOCK=false` et `VITE_API_BASE_URL=…`, puis
  `npm run dev`. Le proxy `/api` de `vite.config.ts` pointe par défaut sur
  `http://localhost:8000` (variable `VITE_API_PROXY` pour changer).

---

## 5. Vérifications passées

- `tsc -b` : aucune erreur (mode strict, `noUnusedLocals`).
- `vite build` : vert.
- Parcours navigateur automatisé : ouverture, onglets, recherche d'un utilisateur par email,
  création d'un rôle → **0 erreur console**.
