import { FlaskConical, RotateCcw } from 'lucide-react'
import { AdminRolesPage } from '@/pages/admin/admin-roles-page'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

/**
 * Harnais de demonstration : le module « Roles & acces » est affiche seul,
 * dans son contexte Direction, sur une couche de fond legere.
 *
 * Les donnees proviennent de l'adaptateur de demonstration (src/services/mock) :
 * elles sont en memoire et reviennent a leur etat initial au rechargement.
 */
export default function App() {
  return (
    <div className="min-h-screen bg-bg">
      <header className="border-b border-border bg-surface/80 backdrop-blur">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-gradient text-[11px] font-bold text-white">
            212
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[14px] font-bold leading-tight text-fg">
              Harnais de démonstration · module « Rôles & accès »
            </p>
            <p className="truncate text-[11.5px] text-fg-subtle">
              Module isolé de l'application Code212 Quest — données de démonstration en mémoire.
            </p>
          </div>
          <Badge variant="warning" className="shrink-0">
            <FlaskConical className="h-3 w-3" /> Mode démo
          </Badge>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0"
            onClick={() => window.location.reload()}
          >
            <RotateCcw className="h-3.5 w-3.5" /> Réinitialiser
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
        <AdminRolesPage />
      </main>

      <footer className="mx-auto max-w-[1600px] px-4 pb-8 text-[11.5px] text-fg-subtle sm:px-6">
        Rappel : les changements faits ici sont en mémoire. Pour des données persistantes, basculez
        <code className="mx-1 rounded bg-surface-2 px-1 py-0.5 font-mono text-[10.5px]">VITE_USE_MOCK=false</code>
        et renseignez <code className="rounded bg-surface-2 px-1 py-0.5 font-mono text-[10.5px]">VITE_API_BASE_URL</code>.
      </footer>
    </div>
  )
}
