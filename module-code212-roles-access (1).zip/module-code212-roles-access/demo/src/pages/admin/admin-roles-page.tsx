import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  BadgeCheck,
  Ban,
  Check,
  ChevronRight,
  CircleSlash,
  Copy,
  Download,
  FileClock,
  Filter,
  KeyRound,
  LayoutGrid,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Table2,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react'
import { PageHeader, SectionHeading } from '@/components/shared/page-header'
import { PermissionMatrix, moduleIcon } from '@/components/shared/permission-matrix'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input, Label, Textarea } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Skeleton } from '@/components/ui/skeleton'
import { useToast } from '@/components/ui/toast'
import {
  useAdminManagedUsers,
  useAdminModerators,
  useAdminRoleAssignments,
  useAdminRoles,
  useAssignModerator,
  useAssignRole,
  useCreateRole,
  useDeleteRole,
  useDuplicateRole,
  useRevokeModerator,
  useRevokeRole,
  useRoleAudit,
  useUnassignRole,
  useUpdateManagedUserStatus,
  useUpdateRole,
} from '@/hooks/use-api'
import {
  CONFLICTING_ROLE_PAIRS,
  FORGE_SECTIONS,
  FORGE_SECTION_LABEL,
  PERMISSION_MODULES,
} from '@/lib/permissions'
import { SCHOOLS } from '@/lib/schools'
import { cn, formatDate, formatDateTime, formatRelative, initials } from '@/lib/utils'
import type { ManagedUser, Role } from '@/types'

/* --------------------------------------------------------------- utilitaires */

const ROLE_TONES: Record<string, 'default' | 'primary' | 'accent' | 'cyan' | 'success' | 'warning' | 'danger' | 'outline'> = {
  admin: 'primary',
  quest_creator: 'accent',
  evaluator: 'cyan',
  coding_league: 'warning',
  question_bank: 'success',
  mentor: 'primary',
  moderator: 'outline',
}

const STATUS_TONES: Record<ManagedUser['status'], 'success' | 'warning' | 'default' | 'danger'> = {
  Actif: 'success',
  'En attente': 'warning',
  Inactif: 'default',
  Suspendu: 'danger',
}

const AUDIT_LABELS: Record<string, { label: string; tone: 'primary' | 'accent' | 'cyan' | 'warning' | 'danger' | 'success' }> = {
  role_created: { label: 'Rôle créé', tone: 'primary' },
  role_updated: { label: 'Rôle modifié', tone: 'cyan' },
  role_revoked: { label: 'Rôle révoqué', tone: 'danger' },
  role_deleted: { label: 'Rôle supprimé', tone: 'danger' },
  role_assigned: { label: 'Rôle attribué', tone: 'success' },
  role_unassigned: { label: 'Rôle retiré', tone: 'warning' },
  moderator_assigned: { label: 'Modérateur nommé', tone: 'success' },
  moderator_revoked: { label: 'Modérateur révoqué', tone: 'warning' },
}

const ROLE_COLORS = ['#6701e6', '#c5027f', '#00b8d4', '#f59e0b', '#10b981', '#8b5cf6', '#ef4444', '#64748b']

/** Regroupe des clés de permissions par module, pour l'affichage. */
function groupPermissions(keys: string[]) {
  return PERMISSION_MODULES.map((module) => ({
    module,
    granted: module.permissions.filter((p) => keys.includes(p.key)),
  })).filter((group) => group.granted.length > 0)
}

/* ------------------------------------------------------------------ page */

export function AdminRolesPage() {
  const { toast } = useToast()
  const roles = useAdminRoles()
  const assignments = useAdminRoleAssignments()
  const moderators = useAdminModerators()
  const users = useAdminManagedUsers()
  const audit = useRoleAudit()

  const [tab, setTab] = useState('roles')
  const [roleDialog, setRoleDialog] = useState<{ open: boolean; role: Role | null }>({ open: false, role: null })
  const [detailRole, setDetailRole] = useState<Role | null>(null)
  const [moderatorDialog, setModeratorDialog] = useState<{ open: boolean; user: ManagedUser | null }>({
    open: false,
    user: null,
  })

  const revoke = useRevokeRole()
  const remove = useDeleteRole()
  const duplicate = useDuplicateRole()
  const unassign = useUnassignRole()
  const revokeModerator = useRevokeModerator()

  const roleList = roles.data ?? []
  const userList = users.data ?? []
  const assignmentList = assignments.data ?? []
  const moderatorList = moderators.data ?? []

  /** Conflits d’intérêts détectés (admin + évaluateur, par exemple). */
  const conflicts = useMemo(() => {
    const found: Array<{ user: ManagedUser; roles: string[] }> = []
    userList.forEach((user) => {
      const hit = CONFLICTING_ROLE_PAIRS.filter(([a, b]) => user.roleCodes.includes(a) && user.roleCodes.includes(b))
      if (hit.length) found.push({ user, roles: [...new Set(hit.flat())] })
    })
    return found
  }, [userList])

  const stats = useMemo(() => {
    const activeRoles = roleList.filter((r) => !r.revokedAt).length
    const named = assignmentList.length
    const activeModerators = moderatorList.filter(
      (m) => !m.revokedAt && (!m.expiresAt || new Date(m.expiresAt).getTime() > Date.now()),
    ).length
    const withoutRole = userList.filter((u) => u.roleCodes.length === 0 && !u.isModerator).length
    return { activeRoles, named, activeModerators, withoutRole }
  }, [roleList, assignmentList, moderatorList, userList])

  const handleRevoke = async (role: Role) => {
    try {
      await revoke.mutateAsync(role.id)
      toast(`Rôle « ${role.name} » révoqué`, {
        description: 'Les membres rattachés ont perdu l’accès correspondant.',
        kind: 'success',
      })
    } catch (error) {
      toast('Révocation impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const handleDuplicate = async (role: Role) => {
    try {
      const copy = await duplicate.mutateAsync(role.id)
      toast(`Copie « ${copy.name} » créée`, { kind: 'success' })
    } catch (error) {
      toast('Duplication impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const handleDelete = async (role: Role) => {
    try {
      await remove.mutateAsync(role.id)
      toast(`Rôle « ${role.name} » supprimé`, { kind: 'success' })
    } catch (error) {
      toast('Suppression impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const handleUnassign = async (id: number, name: string) => {
    try {
      await unassign.mutateAsync(id)
      toast(`Rôle retiré de ${name}`, { kind: 'success' })
    } catch (error) {
      toast('Retrait impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const handleRevokeModerator = async (id: number, name: string) => {
    try {
      await revokeModerator.mutateAsync(id)
      toast(`Périmètre de ${name} révoqué`, { kind: 'success' })
    } catch (error) {
      toast('Révocation impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const isLoading = roles.isLoading || users.isLoading

  return (
    <div>
      <PageHeader
        kicker="Direction · Accès & gouvernance"
        title="Rôles & accès"
        description="Composez l’équipe du centre : créez les rôles, définissez leurs droits, nommez les administrateurs et les modérateurs, et gardez la main sur l’ensemble des comptes."
        actions={
          <>
            <Button variant="outline" onClick={() => setTab('audit')}>
              <FileClock className="h-4 w-4" /> Journal
            </Button>
            <Button onClick={() => setRoleDialog({ open: true, role: null })}>
              <Plus className="h-4 w-4" /> Nouveau rôle
            </Button>
          </>
        }
      />

      {/* ---------------------------------------------------------- indicateurs */}
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          {
            icon: <KeyRound className="h-4 w-4" />,
            label: 'Rôles actifs',
            value: String(stats.activeRoles),
            note: `${roleList.filter((r) => !r.isSystem).length} personnalisés`,
            tone: 'bg-primary-soft text-primary',
          },
          {
            icon: <UserCheck className="h-4 w-4" />,
            label: 'Membres nommés',
            value: String(stats.named),
            note: 'Répartis sur les rôles système',
            tone: 'bg-accent-soft text-accent',
          },
          {
            icon: <ShieldCheck className="h-4 w-4" />,
            label: 'Modérateurs actifs',
            value: String(stats.activeModerators),
            note: 'Périmètre La Forge',
            tone: 'bg-cyan-soft text-cyan-fg',
          },
          {
            icon: <AlertTriangle className="h-4 w-4" />,
            label: 'Conflits d’intérêts',
            value: String(conflicts.length),
            note: conflicts.length ? 'Séparation des pouvoirs à traiter' : 'Aucun cumul détecté',
            tone: conflicts.length ? 'bg-warning-soft text-warning' : 'bg-success-soft text-success',
          },
        ].map((kpi) => (
          <div key={kpi.label} className="panel p-4">
            <div className="flex items-start justify-between gap-3">
              <span className={cn('grid h-9 w-9 place-items-center rounded-xl', kpi.tone)}>{kpi.icon}</span>
            </div>
            <p className="mt-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">{kpi.label}</p>
            <p className="mt-0.5 font-display text-[26px] font-bold leading-none tracking-tight text-fg">{kpi.value}</p>
            <p className="mt-1.5 text-[11.5px] leading-snug text-fg-muted">{kpi.note}</p>
          </div>
        ))}
      </div>

      {conflicts.length > 0 && (
        <div className="mb-5 flex flex-wrap items-center gap-3 rounded-xl border border-warning/30 bg-warning-soft/60 px-4 py-3">
          <AlertTriangle className="h-4 w-4 shrink-0 text-warning" />
          <p className="min-w-0 flex-1 text-[12.5px] text-fg-muted">
            <span className="font-semibold text-fg">
              {conflicts.map((c) => c.user.fullName).join(', ')}
            </span>{' '}
            cumule des rôles qui devraient rester séparés ({conflicts[0].roles.join(' + ')}). Retirez une
            affectation pour rétablir le contrôle par les pairs.
          </p>
        </div>
      )}

      {/* ------------------------------------------------------------- onglets */}
      <div
        data-testid="roles-tabs"
        className="no-scrollbar mb-5 flex items-center gap-1 overflow-x-auto rounded-xl border border-border bg-surface-2 p-1"
      >
        {[
          { key: 'roles', label: 'Rôles & permissions', icon: KeyRound },
          { key: 'assignments', label: 'Affectations', icon: UserPlus },
          { key: 'moderators', label: 'Modérateurs', icon: ShieldCheck },
          { key: 'users', label: 'Comptes utilisateurs', icon: Users },
          { key: 'audit', label: 'Journal', icon: FileClock },
        ].map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setTab(item.key)}
            className={cn(
              'inline-flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-[13px] font-semibold transition-all',
              tab === item.key ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
            )}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
            {item.key === 'moderators' && (
              <span className="rounded-full bg-surface-3 px-1.5 text-[10.5px] tabular-nums text-fg-muted">
                {stats.activeModerators}
              </span>
            )}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      ) : (
        <>
          {tab === 'roles' && (
            <RolesTab
              roles={roleList}
              assignments={assignmentList}
              onCreate={() => setRoleDialog({ open: true, role: null })}
              onEdit={(role) => setRoleDialog({ open: true, role })}
              onDetail={setDetailRole}
              onDuplicate={handleDuplicate}
              onRevoke={handleRevoke}
              onDelete={handleDelete}
            />
          )}

          {tab === 'assignments' && (
            <AssignmentsTab
              roles={roleList}
              assignments={assignmentList}
              users={userList}
              onUnassign={handleUnassign}
            />
          )}

          {tab === 'moderators' && (
            <ModeratorsTab
              users={userList}
              moderators={moderatorList}
              onAssign={(user) => setModeratorDialog({ open: true, user })}
              onRevoke={handleRevokeModerator}
            />
          )}

          {tab === 'users' && <UsersTab users={userList} roles={roleList} />}

          {tab === 'audit' && <AuditTab events={audit.data ?? []} />}
        </>
      )}

      <RoleEditorDialog
        open={roleDialog.open}
        role={roleDialog.role}
        onClose={() => setRoleDialog({ open: false, role: null })}
      />

      <RoleDetailDialog role={detailRole} assignments={assignmentList} onClose={() => setDetailRole(null)} />

      <ModeratorDialog
        open={moderatorDialog.open}
        user={moderatorDialog.user}
        onClose={() => setModeratorDialog({ open: false, user: null })}
      />
    </div>
  )
}

/* ============================================================ onglet RÔLES */

function RolesTab({
  roles,
  assignments,
  onCreate,
  onEdit,
  onDetail,
  onDuplicate,
  onRevoke,
  onDelete,
}: {
  roles: Role[]
  assignments: Array<{ roleCode: string; userName: string; userId: number }>
  onCreate: () => void
  onEdit: (role: Role) => void
  onDetail: (role: Role) => void
  onDuplicate: (role: Role) => void
  onRevoke: (role: Role) => void
  onDelete: (role: Role) => void
}) {
  const [view, setView] = useState<'cards' | 'matrix'>('cards')
  const [filter, setFilter] = useState<'all' | 'system' | 'custom'>('all')
  const [search, setSearch] = useState('')

  const list = roles.filter(
    (role) =>
      (filter === 'all' || (filter === 'system' ? role.isSystem : !role.isSystem)) &&
      `${role.name} ${role.description}`.toLowerCase().includes(search.toLowerCase()),
  )

  const membersOf = (role: Role) => assignments.filter((a) => a.roleCode === role.code)

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-subtle" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un rôle…"
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1">
          {(
            [
              { key: 'all', label: 'Tous' },
              { key: 'system', label: 'Système' },
              { key: 'custom', label: 'Personnalisés' },
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setFilter(item.key)}
              className={cn(
                'rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
                filter === item.key ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1">
          <button
            type="button"
            onClick={() => setView('cards')}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
              view === 'cards' ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
            )}
          >
            <LayoutGrid className="h-3.5 w-3.5" /> Cartes
          </button>
          <button
            type="button"
            onClick={() => setView('matrix')}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
              view === 'matrix' ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
            )}
          >
            <Table2 className="h-3.5 w-3.5" /> Matrice
          </button>
        </div>
        <Button onClick={onCreate} size="sm">
          <Plus className="h-4 w-4" /> Créer un rôle
        </Button>
      </div>

      {view === 'cards' ? (
        <div className="grid gap-3 lg:grid-cols-2 2xl:grid-cols-3">
          {list.map((role) => {
            const members = membersOf(role)
            const groups = groupPermissions(role.permissions)
            const Icon = role.scope === 'forge' ? ShieldCheck : KeyRound
            return (
              <article key={role.id} className="panel relative overflow-hidden">
                <span
                  className="absolute inset-x-0 top-0 h-[3px]"
                  style={{ background: `linear-gradient(90deg, ${role.color}, transparent)` }}
                />
                <div className="p-4">
                  <div className="flex items-start gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white"
                      style={{ background: role.color }}
                    >
                      <Icon className="h-4.5 w-4.5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-[14.5px] font-bold leading-tight text-fg">{role.name}</h3>
                        {role.isSystem ? (
                          <Badge variant="outline">
                            <BadgeCheck className="h-3 w-3" /> Système
                          </Badge>
                        ) : (
                          <Badge variant="accent">Personnalisé</Badge>
                        )}
                        {role.revokedAt && <Badge variant="danger">Révoqué</Badge>}
                        {role.scope === 'forge' && <Badge variant="cyan">Périmètre Forge</Badge>}
                      </div>
                      <p className="mt-1 text-[12.5px] leading-snug text-fg-muted">{role.description}</p>
                    </div>
                  </div>

                  <div className="mt-3.5 flex flex-wrap items-center gap-1.5">
                    {role.scope === 'forge' ? (
                      <span className="chip">
                        <Users className="h-3 w-3" /> {role.memberCount} modérateur(s)
                      </span>
                    ) : (
                      <>
                        <span className="chip">
                          <KeyRound className="h-3 w-3" /> {role.permissions.length} permissions
                        </span>
                        <span className="chip">{groups.length} modules</span>
                      </>
                    )}
                    <span className="chip">
                      <Users className="h-3 w-3" /> {role.memberCount} membre(s)
                    </span>
                  </div>

                  {role.scope !== 'forge' && (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {groups.length === 0 && (
                        <span className="text-[11.5px] italic text-fg-subtle">Aucune permission accordée.</span>
                      )}
                      {groups.map((group) => {
                        const GroupIcon = moduleIcon(group.module.code)
                        const total = group.module.permissions.length
                        return (
                          <span
                            key={group.module.code}
                            title={group.granted.map((p) => p.label).join(' · ')}
                            className="inline-flex items-center gap-1 rounded-md border border-border bg-surface-2 px-1.5 py-0.5 text-[10.5px] font-semibold text-fg-muted"
                          >
                            <GroupIcon className="h-3 w-3" />
                            {group.module.label}
                            <span className="tabular-nums text-fg-subtle">
                              {group.granted.length}/{total}
                            </span>
                          </span>
                        )
                      })}
                    </div>
                  )}

                  {members.length > 0 && (
                    <div className="mt-3.5 border-t border-border pt-3">
                      <p className="mb-2 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
                        Membres
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {members.slice(0, 6).map((member) => (
                          <span
                            key={member.userId}
                            className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface-2 py-0.5 pl-0.5 pr-2 text-[11px] font-medium text-fg-muted"
                          >
                            <span
                              className="grid h-5 w-5 place-items-center rounded-full text-[9px] font-bold text-white"
                              style={{ background: role.color }}
                            >
                              {initials(member.userName)}
                            </span>
                            {member.userName}
                          </span>
                        ))}
                        {members.length > 6 && (
                          <span className="chip">+{members.length - 6}</span>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="mt-4 flex flex-wrap items-center gap-1.5 border-t border-border pt-3">
                    <Button variant="ghost" size="sm" onClick={() => onDetail(role)}>
                      Détail <ChevronRight className="h-3.5 w-3.5" />
                    </Button>
                    {!role.isSystem && (
                      <>
                        <Button variant="ghost" size="sm" onClick={() => onEdit(role)}>
                          <Pencil className="h-3.5 w-3.5" /> Modifier
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => onDuplicate(role)}>
                          <Copy className="h-3.5 w-3.5" /> Dupliquer
                        </Button>
                      </>
                    )}
                    {!role.isSystem && !role.revokedAt && (
                      <Button variant="ghost" size="sm" onClick={() => onRevoke(role)}>
                        <Ban className="h-3.5 w-3.5" /> Révoquer
                      </Button>
                    )}
                    {!role.isSystem && role.memberCount === 0 && (
                      <Button variant="ghost" size="sm" onClick={() => onDelete(role)} className="text-danger">
                        <Trash2 className="h-3.5 w-3.5" /> Supprimer
                      </Button>
                    )}
                  </div>
                </div>
              </article>
            )
          })}
        </div>
      ) : (
        <MatrixView roles={list} />
      )}
    </div>
  )
}

/** Vue matricielle : rôles en lignes, modules en colonnes. */
function MatrixView({ roles }: { roles: Role[] }) {
  return (
    <div className="panel overflow-x-auto">
      <table className="w-full min-w-[980px] border-collapse text-left">
        <thead>
          <tr className="border-b border-border">
            <th className="sticky left-0 z-10 bg-surface px-4 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
              Rôle
            </th>
            {PERMISSION_MODULES.map((module) => {
              const Icon = moduleIcon(module.code)
              return (
                <th key={module.code} className="px-2 py-3 text-center align-bottom">
                  <span className="flex flex-col items-center gap-1">
                    <Icon className="h-3.5 w-3.5 text-fg-subtle" />
                    <span className="max-w-[86px] text-[10.5px] font-bold uppercase leading-tight tracking-[0.08em] text-fg-subtle">
                      {module.label}
                    </span>
                  </span>
                </th>
              )
            })}
            <th className="px-4 py-3 text-right text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
              Total
            </th>
          </tr>
        </thead>
        <tbody>
          {roles.map((role) => (
            <tr key={role.id} className="border-b border-border last:border-0 hover:bg-surface-2/60">
              <td className="sticky left-0 z-10 bg-surface px-4 py-3">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: role.color }} />
                  <span className="text-[12.5px] font-semibold text-fg">{role.name}</span>
                </span>
              </td>
              {PERMISSION_MODULES.map((module) => {
                const total = module.permissions.length
                const granted = module.permissions.filter((p) => role.permissions.includes(p.key)).length
                const complete = granted === total && total > 0
                const partial = granted > 0 && !complete
                return (
                  <td key={module.code} className="px-2 py-3 text-center">
                    {complete ? (
                      <span className="inline-grid h-6 w-6 place-items-center rounded-full bg-success-soft text-success">
                        <Check className="h-3.5 w-3.5" strokeWidth={3} />
                      </span>
                    ) : partial ? (
                      <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-full bg-primary-soft px-1.5 text-[10.5px] font-bold tabular-nums text-primary">
                        {granted}/{total}
                      </span>
                    ) : (
                      <span className="inline-grid h-6 w-6 place-items-center rounded-full bg-surface-3 text-fg-subtle">
                        <CircleSlash className="h-3 w-3" />
                      </span>
                    )}
                  </td>
                )
              })}
              <td className="px-4 py-3 text-right text-[12.5px] font-bold tabular-nums text-fg">
                {role.scope === 'forge' ? '—' : role.permissions.length}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

/* ======================================================== onglet AFFECTATIONS */

function AssignmentsTab({
  roles,
  assignments,
  users,
  onUnassign,
}: {
  roles: Role[]
  assignments: import('@/types').RoleAssignment[]
  users: ManagedUser[]
  onUnassign: (id: number, name: string) => void
}) {
  const { toast } = useToast()
  const assign = useAssignRole()
  const [email, setEmail] = useState('')
  const [roleCode, setRoleCode] = useState('quest_creator')
  const [reason, setReason] = useState('')
  const [expiresAt, setExpiresAt] = useState('')

  const assignableRoles = roles.filter((r) => !r.revokedAt && r.scope !== 'forge')

  /** Fiche de la personne saisie — permet de nommer sans ambiguïté. */
  const match = useMemo(() => {
    const q = email.trim().toLowerCase()
    if (!q) return null
    return (
      users.find((u) => u.academicEmail.toLowerCase() === q) ??
      users.find((u) => u.email.toLowerCase() === q) ??
      users.find(
        (u) =>
          u.academicEmail.toLowerCase().startsWith(q) ||
          u.fullName.toLowerCase().includes(q),
      ) ??
      null
    )
  }, [email, users])

  const suggestions = useMemo(() => {
    const q = email.trim().toLowerCase()
    if (!q) return []
    return users
      .filter(
        (u) =>
          u.academicEmail.toLowerCase().includes(q) || u.fullName.toLowerCase().includes(q),
      )
      .slice(0, 5)
  }, [email, users])

  const selectedRole = assignableRoles.find((r) => r.code === roleCode)

  const conflict = useMemo(() => {
    if (!match || !selectedRole) return null
    const hit = CONFLICTING_ROLE_PAIRS.find(
      ([a, b]) =>
        (a === selectedRole.code && match.roleCodes.includes(b)) ||
        (b === selectedRole.code && match.roleCodes.includes(a)),
    )
    return hit ? hit : null
  }, [match, selectedRole])

  const submit = async () => {
    if (!match) {
      toast('Compte introuvable', {
        description: 'Vérifiez l’adresse électronique saisie.',
        kind: 'error',
      })
      return
    }
    try {
      await assign.mutateAsync({
        email: match.academicEmail,
        roleCode,
        reason,
        expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
      })
      toast(`${match.fullName} est désormais « ${selectedRole?.name} »`, {
        description: 'L’affectation est tracée dans le journal d’accès.',
        kind: 'success',
      })
      setEmail('')
      setReason('')
      setExpiresAt('')
    } catch (error) {
      toast('Affectation impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  return (
    <div className="grid gap-5 xl:grid-cols-[380px_1fr]">
      {/* ------------------------------------------------------ formulaire */}
      <div className="space-y-3">
        <SectionHeading kicker="Nomination" title="Attribuer un rôle" />
        <div className="panel p-4">
          <div className="space-y-3.5">
            <div>
              <Label htmlFor="assign-email">Email de l’utilisateur</Label>
              <div className="relative">
                <Input
                  id="assign-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="prenom.nom@uca.ac.ma"
                  autoComplete="off"
                />
                {suggestions.length > 0 && email !== match?.academicEmail && (
                  <div className="absolute z-20 mt-1 w-full overflow-hidden rounded-xl border border-border bg-surface shadow-[var(--shadow-lift)]">
                    {suggestions.map((u) => (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => setEmail(u.academicEmail)}
                        className="flex w-full items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-2"
                      >
                        <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-surface-3 text-[10px] font-bold text-fg-muted">
                          {initials(u.fullName)}
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-[12.5px] font-semibold text-fg">{u.fullName}</span>
                          <span className="block truncate text-[11px] text-fg-subtle">{u.academicEmail}</span>
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {match && (
              <div className="rounded-xl border border-border bg-surface-2 p-3">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-brand-gradient text-[11px] font-bold text-white">
                    {initials(match.fullName)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold text-fg">{match.fullName}</p>
                    <p className="truncate text-[11.5px] text-fg-subtle">
                      {match.program} · {SCHOOLS[match.school]?.split(' — ')[0] ?? match.school} · Niv.{match.level}
                    </p>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {match.roleCodes.length === 0 ? (
                    <span className="chip">Aucun rôle</span>
                  ) : (
                    match.roleNames.map((name) => (
                      <Badge key={name} variant="primary">
                        {name}
                      </Badge>
                    ))
                  )}
                  {match.isModerator && <Badge variant="cyan">Modérateur</Badge>}
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="assign-role">Rôle attribué</Label>
              <Select value={roleCode} onValueChange={setRoleCode}>
                <SelectTrigger id="assign-role">
                  <SelectValue placeholder="Choisir un rôle" />
                </SelectTrigger>
                <SelectContent>
                  {assignableRoles.map((role) => (
                    <SelectItem key={role.code} value={role.code}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedRole && (
                <p className="mt-1.5 text-[11.5px] leading-snug text-fg-subtle">{selectedRole.description}</p>
              )}
            </div>

            <div>
              <Label htmlFor="assign-reason">Justification (journal d’accès)</Label>
              <Textarea
                id="assign-reason"
                rows={2}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Ex. : pilote la Coding League pour le semestre"
              />
            </div>

            <div>
              <Label htmlFor="assign-expiry">Échéance (facultatif)</Label>
              <Input
                id="assign-expiry"
                type="date"
                value={expiresAt}
                onChange={(e) => setExpiresAt(e.target.value)}
              />
              <p className="mt-1 text-[11px] text-fg-subtle">
                Laissez vide pour une mission permanente. Une mission temporaire expire automatiquement.
              </p>
            </div>

            {conflict && (
              <div className="flex items-start gap-2 rounded-lg border border-warning/30 bg-warning-soft/60 px-3 py-2">
                <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />
                <p className="text-[11.5px] leading-snug text-fg-muted">
                  Conflit d’intérêts : {match?.fullName} cumule déjà un rôle incompatible. La plateforme refusera
                  l’affectation.
                </p>
              </div>
            )}

            <Button className="w-full" onClick={submit} disabled={!match || assign.isPending}>
              <UserPlus className="h-4 w-4" />
              {assign.isPending ? 'Attribution…' : 'Attribuer le rôle'}
            </Button>
          </div>
        </div>
      </div>

      {/* --------------------------------------------------------- liste */}
      <div>
        <SectionHeading
          kicker="Registre"
          title="Affectations en cours"
          action={<Badge variant="primary">{assignments.length} affectations</Badge>}
        />
        <div className="panel overflow-hidden">
          <div className="hidden grid-cols-[1.7fr_1.15fr_1.5fr_1fr_auto] gap-4 border-b border-border px-5 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle lg:grid">
            <span>Membre</span>
            <span>Rôle</span>
            <span>Justification</span>
            <span>Attribué le</span>
            <span className="w-24" />
          </div>
          <div className="divide-y divide-border">
            {assignments.length === 0 && (
              <p className="px-5 py-10 text-center text-[13px] text-fg-subtle">Aucune affectation pour le moment.</p>
            )}
            {assignments.map((assignment) => (
              <div
                key={assignment.id}
                className="grid grid-cols-1 gap-2 px-5 py-3.5 lg:grid-cols-[1.7fr_1.15fr_1.5fr_1fr_auto] lg:items-center lg:gap-4"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-[11px] font-bold text-white"
                    style={{ background: assignment.roleColor }}
                  >
                    {initials(assignment.userName)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-fg">{assignment.userName}</p>
                    <p className="truncate text-[11.5px] text-fg-subtle">{assignment.userEmail}</p>
                  </div>
                </div>
                <div className="min-w-0">
                  <Badge variant={ROLE_TONES[assignment.roleCode] ?? 'default'}>{assignment.roleName}</Badge>
                  {assignment.expiresAt && (
                    <p className="mt-1 text-[11px] text-fg-subtle">Jusqu’au {formatDate(assignment.expiresAt)}</p>
                  )}
                </div>
                <p className="line-clamp-2 text-[12px] leading-snug text-fg-muted">{assignment.reason}</p>
                <div className="min-w-0">
                  <p className="text-[12px] text-fg-muted">{formatDate(assignment.grantedAt)}</p>
                  <p className="truncate text-[11px] text-fg-subtle">par {assignment.grantedBy}</p>
                </div>
                <div className="flex justify-start gap-1 lg:justify-end">
                  <Button variant="ghost" size="sm" onClick={() => onUnassign(assignment.id, assignment.userName)}>
                    <CircleSlash className="h-3.5 w-3.5" /> Retirer
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ======================================================== onglet MODÉRATEURS */

function ModeratorsTab({
  users,
  moderators,
  onAssign,
  onRevoke,
}: {
  users: ManagedUser[]
  moderators: import('@/types').ModeratorAssignment[]
  onAssign: (user: ManagedUser) => void
  onRevoke: (id: number, name: string) => void
}) {
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'moderators' | 'others'>('all')
  const [sectionFilter, setSectionFilter] = useState('all')

  const list = users.filter((u) => {
    const q = search.trim().toLowerCase()
    const matchesSearch =
      !q ||
      `${u.fullName} ${u.academicEmail} ${u.program} ${u.school}`.toLowerCase().includes(q)
    const matchesRole =
      filter === 'all' ||
      (filter === 'moderators' ? u.isModerator : !u.isModerator)
    const matchesSection =
      sectionFilter === 'all' || u.moderatedSections.includes(sectionFilter)
    return matchesSearch && matchesRole && matchesSection
  })

  const expiredIds = new Set(
    moderators
      .filter((m) => m.expiresAt && new Date(m.expiresAt).getTime() < Date.now())
      .map((m) => m.userId),
  )

  /** Mandat en cours le plus long d'un compte (le cas échéant). */
  const mandatOf = (userId: number) => {
    const entries = moderators.filter((m) => m.userId === userId)
    if (entries.length === 0) return null
    const dated = entries
      .filter((m) => m.expiresAt)
      .sort((a, b) => (b.expiresAt ?? '').localeCompare(a.expiresAt ?? ''))
    const target = dated[0] ?? entries[0]
    return {
      expiresAt: target.expiresAt,
      expired: Boolean(target.expiresAt && new Date(target.expiresAt).getTime() < Date.now()),
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[240px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-subtle" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Nom, filière, établissement, email…"
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1">
          {(
            [
              { key: 'all', label: 'Tous' },
              { key: 'moderators', label: 'Modérateurs' },
              { key: 'others', label: 'Autres' },
            ] as const
          ).map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setFilter(item.key)}
              className={cn(
                'rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
                filter === item.key ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
              )}
            >
              {item.label}
            </button>
          ))}
        </div>
        <Select value={sectionFilter} onValueChange={setSectionFilter}>
          <SelectTrigger className="w-[210px]" aria-label="Filtrer par rubrique">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les rubriques</SelectItem>
            {FORGE_SECTIONS.map((section) => (
              <SelectItem key={section.slug} value={section.slug}>
                {section.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Badge variant="primary">
          <Filter className="mr-1 h-3 w-3" /> {list.length} comptes
        </Badge>
      </div>

      <div className="panel overflow-x-auto">
        <div className="min-w-[1080px]">
          <div className="grid grid-cols-[1.5fr_1.15fr_0.85fr_1.5fr_1.6fr_auto] gap-4 border-b border-border px-5 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
            <span>Nom & prénom</span>
            <span>Filière</span>
            <span>Établissement</span>
            <span>Email académique</span>
            <span>Rôle & rubriques</span>
            <span className="w-40 text-right">Actions</span>
          </div>
          <div className="divide-y divide-border">
            {list.length === 0 && (
              <p className="px-5 py-10 text-center text-[13px] text-fg-subtle">Aucun compte ne correspond.</p>
            )}
            {list.map((user) => {
              const userModerators = moderators.filter((m) => m.userId === user.id)
              return (
                <div
                  key={user.id}
                  className="grid grid-cols-[1.5fr_1.15fr_0.85fr_1.5fr_1.6fr_auto] items-center gap-4 px-5 py-3.5"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-surface-3 text-[11px] font-bold text-fg-muted">
                      {initials(user.fullName)}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-[13px] font-semibold text-fg">{user.fullName}</p>
                      <p className="truncate text-[11px] text-fg-subtle">{user.studentCode}</p>
                    </div>
                  </div>

                  <span className="truncate text-[12.5px] text-fg-muted">{user.program}</span>

                  <span className="truncate text-[12.5px] text-fg-muted">
                    {SCHOOLS[user.school]?.split(' — ')[0] ?? user.school}
                  </span>

                  <span className="truncate font-mono text-[11.5px] text-fg-muted">{user.academicEmail}</span>

                  <div className="flex min-w-0 flex-wrap gap-1">
                    {user.roleNames.slice(0, 2).map((name) => (
                      <Badge key={name} variant="primary" className="max-w-full whitespace-normal text-left">
                        {name}
                      </Badge>
                    ))}
                    {user.roleNames.length > 2 && <Badge>+{user.roleNames.length - 2}</Badge>}
                    {user.moderatedSections.map((section) => (
                      <Badge
                        key={section}
                        variant={expiredIds.has(user.id) ? 'default' : 'cyan'}
                        title={
                          expiredIds.has(user.id)
                            ? `${FORGE_SECTION_LABEL[section] ?? section} — mandat expiré`
                            : FORGE_SECTION_LABEL[section] ?? section
                        }
                      >
                        {FORGE_SECTION_LABEL[section] ?? section}
                      </Badge>
                    ))}
                    {user.roleNames.length === 0 && user.moderatedSections.length === 0 && (
                      <span className="text-[11.5px] text-fg-subtle">Aucun accès</span>
                    )}
                    {mandatOf(user.id) && (
                      <span
                        className={cn(
                          'w-full text-[10.5px]',
                          mandatOf(user.id)?.expired ? 'text-danger' : 'text-fg-subtle',
                        )}
                      >
                        {mandatOf(user.id)?.expired
                          ? `Mandat expiré le ${formatDate(mandatOf(user.id)!.expiresAt!)}`
                          : mandatOf(user.id)?.expiresAt
                            ? `Mandat jusqu’au ${formatDate(mandatOf(user.id)!.expiresAt!)}`
                            : 'Mandat permanent'}
                      </span>
                    )}
                  </div>

                  <div className="flex justify-end gap-1">
                    {user.roleCodes.includes('admin') ? (
                      <span
                        className="inline-flex h-8 cursor-not-allowed items-center gap-1.5 rounded-lg border border-border bg-surface-2 px-3 text-[12px] font-semibold text-fg-subtle"
                        title="Un administrateur dispose déjà d’un accès global : le périmètre de modération n’est pas nécessaire."
                      >
                        <ShieldCheck className="h-3.5 w-3.5" /> Accès global
                      </span>
                    ) : (
                      <Button variant="outline" size="sm" onClick={() => onAssign(user)}>
                        <ShieldCheck className="h-3.5 w-3.5" />
                        {user.isModerator ? 'Étendre' : 'Modérateur'}
                      </Button>
                    )}
                    {userModerators.map((m) => (
                      <Button
                        key={m.id}
                        variant="ghost"
                        size="sm"
                        onClick={() => onRevoke(m.id, user.fullName)}
                        title="Révoquer ce périmètre"
                        className="text-danger"
                      >
                        <CircleSlash className="h-3.5 w-3.5" />
                      </Button>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ============================================================ onglet COMPTES */

function UsersTab({ users, roles }: { users: ManagedUser[]; roles: Role[] }) {
  const { toast } = useToast()
  const updateStatus = useUpdateManagedUserStatus()
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const [role, setRole] = useState('all')
  const [school, setSchool] = useState('all')

  const list = users.filter((u) => {
    const q = search.trim().toLowerCase()
    return (
      (!q ||
        `${u.fullName} ${u.email} ${u.academicEmail} ${u.program}`.toLowerCase().includes(q)) &&
      (status === 'all' || u.status === status) &&
      (role === 'all' || u.roleCodes.includes(role)) &&
      (school === 'all' || u.school === school)
    )
  })

  const exportCsv = () => {
    const header = ['Nom', 'Prénom', 'Email académique', 'Filière', 'Établissement', 'Rôles', 'Statut']
    const rows = list.map((u) => [
      u.lastName,
      u.firstName,
      u.academicEmail,
      u.program,
      u.school,
      u.roleNames.join(' | ') || '—',
      u.status,
    ])
    const csv = [header, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(';'))
      .join('\n')
    const blob = new Blob([`﻿${csv}`], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'comptes-code212.csv'
    link.click()
    URL.revokeObjectURL(url)
    toast('Export CSV généré', { description: `${list.length} comptes exportés.`, kind: 'success' })
  }

  const toggleStatus = async (user: ManagedUser) => {
    const next = user.status === 'Suspendu' ? 'Actif' : 'Suspendu'
    try {
      await updateStatus.mutateAsync({ id: user.id, status: next })
      toast(`${user.fullName} — compte ${next === 'Actif' ? 'réactivé' : 'suspendu'}`, {
        description: 'La suspension est manuelle et tracée ; aucune règle automatique ne l’applique.',
        kind: next === 'Actif' ? 'success' : 'info',
      })
    } catch (error) {
      toast('Action impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-subtle" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un compte…"
            className="pl-9"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[185px]" aria-label="Filtrer par statut">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les statuts</SelectItem>
            <SelectItem value="Actif">Actifs</SelectItem>
            <SelectItem value="En attente">En attente</SelectItem>
            <SelectItem value="Inactif">Inactifs</SelectItem>
            <SelectItem value="Suspendu">Suspendus</SelectItem>
          </SelectContent>
        </Select>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-[235px]" aria-label="Filtrer par rôle">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les rôles</SelectItem>
            {roles
              .filter((r) => r.scope !== 'forge')
              .map((r) => (
                <SelectItem key={r.code} value={r.code}>
                  {r.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
        <Select value={school} onValueChange={setSchool}>
          <SelectTrigger className="w-[205px]" aria-label="Filtrer par établissement">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les établissements</SelectItem>
            {Object.keys(SCHOOLS).map((code) => (
              <SelectItem key={code} value={code}>
                {code}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={exportCsv}>
          <Download className="h-4 w-4" /> Exporter
        </Button>
      </div>

      <div className="panel overflow-x-auto">
        <div className="min-w-[1000px]">
          <div className="grid grid-cols-[1.6fr_1.3fr_1fr_1.5fr_1fr_auto] gap-4 border-b border-border px-5 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
            <span>Compte</span>
            <span>Filière</span>
            <span>Établissement</span>
            <span>Rôles</span>
            <span>Statut</span>
            <span className="w-28 text-right">Action</span>
          </div>
          <div className="divide-y divide-border">
            {list.map((user) => (
              <div
                key={user.id}
                className="grid grid-cols-[1.6fr_1.3fr_1fr_1.5fr_1fr_auto] items-center gap-4 px-5 py-3"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-surface-3 text-[11px] font-bold text-fg-muted">
                    {initials(user.fullName)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-fg">{user.fullName}</p>
                    <p className="truncate text-[11px] text-fg-subtle">{user.academicEmail}</p>
                  </div>
                </div>
                <span className="truncate text-[12.5px] text-fg-muted">{user.program}</span>
                <span className="truncate text-[12.5px] text-fg-muted">
                  {SCHOOLS[user.school]?.split(' — ')[0] ?? user.school}
                </span>
                <div className="flex min-w-0 flex-wrap gap-1">
                  {user.roleNames.map((name) => (
                    <Badge key={name} variant="primary" className="max-w-full whitespace-normal text-left">
                      {name}
                    </Badge>
                  ))}
                  {user.isModerator && <Badge variant="cyan">Modérateur</Badge>}
                  {user.roleNames.length === 0 && !user.isModerator && (
                    <span className="text-[11.5px] text-fg-subtle">Aucun accès</span>
                  )}
                </div>
                <Badge variant={STATUS_TONES[user.status]} className="w-fit">
                  {user.status}
                </Badge>
                <div className="flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleStatus(user)}
                    className={user.status === 'Suspendu' ? '' : 'text-danger'}
                  >
                    {user.status === 'Suspendu' ? (
                      <>
                        <Check className="h-3.5 w-3.5" /> Réactiver
                      </>
                    ) : (
                      <>
                        <Ban className="h-3.5 w-3.5" /> Suspendre
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

/* ============================================================= onglet JOURNAL */

function AuditTab({ events }: { events: import('@/types').RoleAuditEvent[] }) {
  return (
    <div>
      <SectionHeading
        kicker="Traçabilité"
        title="Journal des accès"
        action={<Badge variant="primary">{events.length} événements</Badge>}
      />
      <div className="panel overflow-hidden">
        <div className="divide-y divide-border">
          {events.length === 0 && (
            <p className="px-5 py-10 text-center text-[13px] text-fg-subtle">Aucun événement enregistré.</p>
          )}
          {events.map((event) => {
            const meta = AUDIT_LABELS[event.action] ?? { label: event.action, tone: 'primary' as const }
            return (
              <div key={event.id} className="flex items-start gap-3.5 px-5 py-3.5">
                <Badge variant={meta.tone} className="mt-0.5 shrink-0">
                  {meta.label}
                </Badge>
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] text-fg">
                    <span className="font-semibold">{event.target}</span>
                    <span className="text-fg-muted"> — {event.detail}</span>
                  </p>
                  <p className="mt-0.5 text-[11.5px] text-fg-subtle">
                    par {event.actor} · {formatDateTime(event.createdAt)} · {formatRelative(event.createdAt)}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

/* ======================================================== dialogue création */

function RoleEditorDialog({
  open,
  role,
  onClose,
}: {
  open: boolean
  role: Role | null
  onClose: () => void
}) {
  const { toast } = useToast()
  const create = useCreateRole()
  const update = useUpdateRole()

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [color, setColor] = useState(ROLE_COLORS[0])
  const [permissions, setPermissions] = useState<string[]>([])
  const [initialised, setInitialised] = useState(false)

  /** Réinitialise le formulaire à l'ouverture (création ou édition). */
  if (open && !initialised) {
    setInitialised(true)
    setName(role?.name ?? '')
    setDescription(role?.description ?? '')
    setColor(role?.color ?? ROLE_COLORS[0])
    setPermissions(role ? [...role.permissions] : [])
  }
  if (!open && initialised) {
    setInitialised(false)
  }

  const isEdit = Boolean(role)

  const submit = async () => {
    try {
      if (isEdit && role) {
        await update.mutateAsync({
          id: role.id,
          patch: { name, description, color, permissions },
        })
        toast(`Rôle « ${name} » mis à jour`, { kind: 'success' })
      } else {
        await create.mutateAsync({ name, description, color, permissions })
        toast(`Rôle « ${name} » créé`, {
          description: `${permissions.length} permissions accordées.`,
          kind: 'success',
        })
      }
      onClose()
    } catch (error) {
      toast('Enregistrement impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  const presetModules = (codes: string[]) => {
    const keys = PERMISSION_MODULES.filter((m) => codes.includes(m.code)).flatMap((m) =>
      m.permissions.map((p) => p.key),
    )
    setPermissions([...new Set([...permissions, ...keys])])
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !next && onClose()}>
      <DialogContent className="max-w-5xl">
        <DialogHeader>
          <DialogTitle>{isEdit ? `Modifier « ${role?.name} »` : 'Créer un rôle personnalisé'}</DialogTitle>
          <DialogDescription>
            Les droits sont atomiques : cochez précisément ce que le rôle permet. Un rôle système ne peut pas être
            modifié — dupliquez-le pour obtenir une variante.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-5 sm:grid-cols-[272px_minmax(0,1fr)]">
          <div className="min-w-0 space-y-3.5">
            <div>
              <Label htmlFor="role-name">Nom du rôle</Label>
              <Input
                id="role-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex. : Référent Cybersécurité"
              />
            </div>
            <div>
              <Label htmlFor="role-description">Description</Label>
              <Textarea
                id="role-description"
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="À quoi sert ce rôle, concrètement ?"
              />
            </div>
            <div>
              <Label>Couleur</Label>
              <div className="mt-2 flex flex-wrap gap-2">
                {ROLE_COLORS.map((swatch) => (
                  <button
                    key={swatch}
                    type="button"
                    onClick={() => setColor(swatch)}
                    className={cn(
                      'h-7 w-7 rounded-lg border-2 transition-transform',
                      color === swatch
                        ? 'scale-110 border-fg'
                        : 'border-transparent hover:scale-105',
                    )}
                    style={{ background: swatch }}
                    aria-label={`Couleur ${swatch}`}
                  />
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-border bg-surface-2 p-3">
              <p className="mb-2 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
                Modèles rapides
              </p>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => presetModules(['moderation'])}
                  className="chip hover:border-border-strong"
                >
                  + Modération
                </button>
                <button
                  type="button"
                  onClick={() => presetModules(['quests', 'missions'])}
                  className="chip hover:border-border-strong"
                >
                  + Quêtes & missions
                </button>
                <button
                  type="button"
                  onClick={() => presetModules(['paths', 'certifications'])}
                  className="chip hover:border-border-strong"
                >
                  + Parcours & certifications
                </button>
                <button
                  type="button"
                  onClick={() => presetModules(['arena'])}
                  className="chip hover:border-border-strong"
                >
                  + Arène
                </button>
                <button
                  type="button"
                  onClick={() => presetModules(['placement'])}
                  className="chip hover:border-border-strong"
                >
                  + Banque de questions
                </button>
              </div>
            </div>
          </div>

          <div className="min-w-0">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[11.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
                Permissions
              </p>
              <span className="text-[11.5px] font-semibold tabular-nums text-primary">
                {permissions.length} cochée(s)
              </span>
            </div>
            <div className="max-h-[46vh] overflow-y-auto pr-1">
              <PermissionMatrix value={permissions} onChange={setPermissions} />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={submit} disabled={!name.trim() || permissions.length === 0}>
            {isEdit ? 'Enregistrer' : 'Créer le rôle'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ========================================================= dialogue détail */

function RoleDetailDialog({
  role,
  assignments,
  onClose,
}: {
  role: Role | null
  assignments: import('@/types').RoleAssignment[]
  onClose: () => void
}) {
  if (!role) return null
  const members = assignments.filter((a) => a.roleCode === role.code)
  const groups = groupPermissions(role.permissions)

  return (
    <Dialog open={Boolean(role)} onOpenChange={(next) => !next && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-center gap-2.5">
            <span
              className="grid h-9 w-9 place-items-center rounded-xl text-white"
              style={{ background: role.color }}
            >
              <KeyRound className="h-4 w-4" />
            </span>
            <DialogTitle>{role.name}</DialogTitle>
          </div>
          <DialogDescription>{role.description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex flex-wrap gap-1.5">
            {role.isSystem ? (
              <Badge variant="outline">
                <BadgeCheck className="h-3 w-3" /> Rôle système
              </Badge>
            ) : (
              <Badge variant="accent">Rôle personnalisé</Badge>
            )}
            <Badge variant="default">{role.permissions.length} permissions</Badge>
            <Badge variant="default">{members.length} membre(s)</Badge>
            {role.createdBy && <Badge variant="outline">Créé par {role.createdBy}</Badge>}
          </div>

          {groups.length === 0 ? (
            <p className="rounded-xl border border-border bg-surface-2 px-4 py-6 text-center text-[12.5px] text-fg-subtle">
              {role.scope === 'forge'
                ? 'La modération de La Forge ne porte pas de permissions globales : elle est bornée par rubrique.'
                : 'Aucune permission accordée pour l’instant.'}
            </p>
          ) : (
            <div className="space-y-2">
              {groups.map((group) => {
                const Icon = moduleIcon(group.module.code)
                return (
                  <div key={group.module.code} className="rounded-xl border border-border p-3">
                    <div className="mb-2 flex items-center gap-2">
                      <span className="grid h-7 w-7 place-items-center rounded-lg bg-primary-soft text-primary">
                        <Icon className="h-3.5 w-3.5" />
                      </span>
                      <p className="text-[13px] font-bold text-fg">{group.module.label}</p>
                      <span className="ml-auto text-[11px] tabular-nums text-fg-subtle">
                        {group.granted.length}/{group.module.permissions.length}
                      </span>
                    </div>
                    <ul className="space-y-1">
                      {group.granted.map((permission) => (
                        <li key={permission.key} className="flex items-start gap-2 text-[12px] text-fg-muted">
                          <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-success" strokeWidth={3} />
                          <span>
                            {permission.label}
                            <code className="ml-1.5 font-mono text-[10px] text-fg-subtle/70">
                              {permission.key}
                            </code>
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )
              })}
            </div>
          )}

          {members.length > 0 && (
            <div>
              <p className="kicker mb-2">Membres</p>
              <div className="flex flex-wrap gap-1.5">
                {members.map((member) => (
                  <span
                    key={member.id}
                    className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface-2 py-1 pl-1 pr-2.5 text-[11.5px] font-medium text-fg-muted"
                  >
                    <span
                      className="grid h-5 w-5 place-items-center rounded-full text-[9px] font-bold text-white"
                      style={{ background: role.color }}
                    >
                      {initials(member.userName)}
                    </span>
                    {member.userName}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/* ======================================================= dialogue modérateur */

function ModeratorDialog({
  open,
  user,
  onClose,
}: {
  open: boolean
  user: ManagedUser | null
  onClose: () => void
}) {
  const { toast } = useToast()
  const assign = useAssignModerator()
  const [sections, setSections] = useState<string[]>([])
  const [note, setNote] = useState('')
  const [expiresAt, setExpiresAt] = useState('')
  const [initialised, setInitialised] = useState(false)

  if (open && !initialised) {
    setInitialised(true)
    setSections(user?.moderatedSections ?? [])
    setNote('')
    setExpiresAt('')
  }
  if (!open && initialised) {
    setInitialised(false)
  }

  const submit = async () => {
    if (!user) return
    try {
      await assign.mutateAsync({
        email: user.academicEmail,
        sections,
        note,
        expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
      })
      toast(`${user.fullName} — périmètre de modération mis à jour`, {
        description: sections
          .map((s) => FORGE_SECTION_LABEL[s] ?? s)
          .join(', '),
        kind: 'success',
      })
      onClose()
    } catch (error) {
      toast('Affectation impossible', { description: (error as Error).message, kind: 'error' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !next && onClose()}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Périmètre de modération</DialogTitle>
          <DialogDescription>
            {user
              ? `${user.fullName} — ${user.program} · ${SCHOOLS[user.school]?.split(' — ')[0] ?? user.school}. Choisissez les rubriques de La Forge qu’il ou elle modère.`
              : 'Sélectionnez les rubriques à confier.'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3.5">
          <div>
            <Label>Rubriques de La Forge</Label>
            <div className="mt-1.5 space-y-1.5">
              {FORGE_SECTIONS.map((section) => {
                const checked = sections.includes(section.slug)
                return (
                  <button
                    key={section.slug}
                    type="button"
                    onClick={() =>
                      setSections((current) =>
                        checked
                          ? current.filter((s) => s !== section.slug)
                          : [...current, section.slug],
                      )
                    }
                    className={cn(
                      'flex w-full items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-colors',
                      checked ? 'border-cyan/40 bg-cyan-soft/50' : 'border-border hover:bg-surface-2',
                    )}
                  >
                    <span
                      className={cn(
                        'mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border',
                        checked ? 'border-cyan-fg bg-cyan-fg text-white' : 'border-border-strong bg-surface',
                      )}
                    >
                      {checked && <Check className="h-3 w-3" strokeWidth={3} />}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[12.5px] font-semibold text-fg">{section.label}</span>
                      <span className="block text-[11.5px] leading-snug text-fg-subtle">
                        {section.description}
                      </span>
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          <div>
            <Label htmlFor="mod-expiry">Échéance du mandat</Label>
            <Input
              id="mod-expiry"
              type="date"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
            />
            <p className="mt-1 text-[11px] text-fg-subtle">
              Recommandé : un mandat de 3 à 6 mois, renouvelable. Sans date, la délégation reste permanente.
            </p>
          </div>

          <div>
            <Label htmlFor="mod-note">Note de périmètre</Label>
            <Textarea
              id="mod-note"
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ex. : relais des questions bloquées le week-end"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button onClick={submit} disabled={sections.length === 0 || assign.isPending}>
            <ShieldCheck className="h-4 w-4" />
            {assign.isPending ? 'Enregistrement…' : 'Confirmer le périmètre'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
