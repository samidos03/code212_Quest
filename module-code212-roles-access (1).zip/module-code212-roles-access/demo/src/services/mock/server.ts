/**
 * Code212 Quest — adaptateur « démo » de l'API.
 *
 * Reproduit la forme des réponses Laravel (`/api/v1`) et applique les mêmes
 * invariants métier que le backend : idempotence du ledger, gains XP uniques,
 * achats atomiques, quotas de la Forge, respect du consentement au classement.
 *
 * Le passage à l'API réelle se fait sans toucher aux composants : il suffit de
 * passer `VITE_USE_MOCK=false` et de renseigner `VITE_API_BASE_URL`.
 */
import {
  adminOverview,
  badges as seedBadges,
  certifications,
  challenges as seedChallenges,
  currentUser,
  forgeCategories,
  forgeSolutions as seedSolutions,
  forgeThreads as seedThreads,
  leaderboard as seedLeaderboard,
  levels,
  managedRoles,
  managedUsers,
  moderatorAssignments,
  roleAssignments,
  roleAudit,
  missions as seedMissions,
  paths as seedPaths,
  quests as seedQuests,
  rewardOrders as seedOrders,
  rewards as seedRewards,
  submissions as seedSubmissions,
  tracks as seedTracks,
  weeklyActivity,
  xpRules as seedRules,
} from './db'
import { CONFLICTING_ROLE_PAIRS, FORGE_SECTION_LABEL } from '@/lib/permissions'
import type {
  AdminOverview,
  Badge,
  Certification,
  Challenge,
  DashboardData,
  ForgeCategory,
  ForgeSolution,
  ForgeThread,
  LeaderboardEntry,
  LearningPath,
  LedgerEntry,
  ManagedUser,
  ManagedUserStatus,
  ModeratorAssignment,
  LevelConfig,
  Mission,
  Quest,
  QuestStep,
  Reward,
  RewardOrder,
  Role,
  RoleAssignment,
  RoleAuditEvent,
  Submission,
  Track,
  UserProfile,
  XpRule,
} from '@/types'

const slugify = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '')

const STORAGE_KEY = 'code212.mock.state'

interface MockState {
  xp: number
  germs: number
  ledger: LedgerEntry[]
  enrolled: number[]
  stepProgress: Record<string, { status: QuestStep['status']; score?: number }>
  claimedMissions: number[]
  joinedChallenges: number[]
  likedThreads: number[]
  likedSolutions: number[]
  purchases: { rewardId: number; quantity: number }[]
  orderStatus: Record<number, RewardOrder['status']>
  submissionStatus: Record<number, Submission['status']>
  ruleOverrides: Record<number, Partial<XpRule>>
  rulesEnabled: Record<number, boolean>
}

const defaultState = (): MockState => ({
  xp: currentUser.xp,
  germs: currentUser.germs,
  ledger: [
    { id: 1, xpDelta: 450, trackType: 'codeur', sourceEvent: 'quest.complete', referenceId: 'quest-1', label: 'Quête « AI Prompt Engineering » validée', createdAt: new Date(Date.now() - 3 * 86400000).toISOString(), ruleVersion: 3 },
    { id: 2, xpDelta: 260, trackType: 'codeur', sourceEvent: 'quest.complete', referenceId: 'quest-3', label: 'Quête « Build a REST API » validée', createdAt: new Date(Date.now() - 9 * 86400000).toISOString(), ruleVersion: 3 },
    { id: 3, xpDelta: 40, trackType: 'aidant', sourceEvent: 'forge.answer', referenceId: 'thread-1', label: 'Réponse acceptée dans La Forge', createdAt: new Date(Date.now() - 11 * 86400000).toISOString(), ruleVersion: 4 },
    { id: 4, xpDelta: 180, trackType: null, sourceEvent: 'streak.weekly', referenceId: 'streak-w42', label: 'Bonus de série hebdomadaire', createdAt: new Date(Date.now() - 13 * 86400000).toISOString(), ruleVersion: 2 },
    { id: 5, xpDelta: 600, trackType: 'codeur', sourceEvent: 'quest.complete', referenceId: 'quest-8', label: 'Quête « JavaScript Avancé » validée', createdAt: new Date(Date.now() - 21 * 86400000).toISOString(), ruleVersion: 3 },
  ],
  enrolled: [1, 8, 10],
  stepProgress: {
    '1-1': { status: 'valide', score: 92 },
    '1-2': { status: 'valide', score: 88 },
    '1-3': { status: 'valide', score: 95 },
    '1-4': { status: 'en_cours' },
    '8-1': { status: 'valide', score: 90 },
    '8-2': { status: 'en_cours' },
    '10-1': { status: 'valide', score: 85 },
  },
  claimedMissions: [5],
  joinedChallenges: [1, 5, 7],
  likedThreads: [2],
  likedSolutions: [],
  purchases: [],
  orderStatus: {},
  submissionStatus: {},
  ruleOverrides: {},
  rulesEnabled: {},
})

let state: MockState = load()

function load(): MockState {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultState()
    return { ...defaultState(), ...(JSON.parse(raw) as Partial<MockState>) }
  } catch {
    return defaultState()
  }
}

function persist() {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch {
    /* quota indisponible : la démo continue en mémoire */
  }
}

/** Latence simulée pour rendre l'UI réaliste (squelettes, états de chargement). */
const delay = (ms = 180 + Math.random() * 220) => new Promise((r) => setTimeout(r, ms))

function levelFor(xp: number): LevelConfig {
  return [...levels].reverse().find((l) => xp >= l.xpThreshold) ?? levels[0]
}

function nextLevelFor(xp: number): LevelConfig | null {
  return levels.find((l) => l.xpThreshold > xp) ?? null
}

/** Crée une entrée de ledger en respectant la clé d'idempotence serveur. */
function credit(sourceEvent: string, referenceId: string, xpDelta: number, label: string, trackType: LedgerEntry['trackType'] = null) {
  const existing = state.ledger.find((entry) => entry.sourceEvent === sourceEvent && entry.referenceId === referenceId)
  if (existing) return { awarded: false, entry: existing }
  const entry: LedgerEntry = {
    id: Date.now(),
    xpDelta,
    trackType,
    sourceEvent,
    referenceId,
    label,
    createdAt: new Date().toISOString(),
    ruleVersion: 1,
  }
  state.ledger = [entry, ...state.ledger]
  state.xp = Math.max(0, state.xp + xpDelta)
  persist()
  return { awarded: true, entry }
}

function hydrateQuest(quest: Quest): Quest {
  const steps = quest.steps.map((step) => {
    const progress = state.stepProgress[`${quest.id}-${step.id}`]
    return progress ? { ...step, ...progress } : step
  })
  const done = steps.filter((s) => s.status === 'valide').length
  const progress = steps.length ? Math.round((done / steps.length) * 100) : 0
  return { ...quest, steps, enrolled: state.enrolled.includes(quest.id), progress: state.enrolled.includes(quest.id) ? progress : 0 }
}

function profile(): UserProfile {
  const level = levelFor(state.xp)
  const next = nextLevelFor(state.xp)
  const trackPoints = { codeur: 1240, aidant: 860, batisseur: 610, explorateur: 430 } as UserProfile['trackPoints']
  return {
    id: currentUser.id,
    firstName: currentUser.firstName,
    lastName: currentUser.lastName,
    displayName: currentUser.displayName,
    pseudonym: currentUser.pseudonym,
    email: currentUser.email,
    studentCode: currentUser.studentCode,
    program: currentUser.program,
    cohort: currentUser.cohort,
    roles: [...currentUser.roles],
    level: level.level,
    levelTitle: level.title,
    xp: state.xp,
    xpToNextLevel: next ? next.xpThreshold - state.xp : 0,
    levelFloor: level.xpThreshold,
    levelCeiling: next?.xpThreshold ?? level.xpThreshold,
    germs: state.germs,
    streakDays: currentUser.streakDays,
    bestStreak: currentUser.bestStreak,
    questsCompleted: 9 + Math.max(0, Math.round((state.xp - currentUser.xp) / 500)),
    questsInProgress: state.enrolled.length,
    badgesEarned: seedBadges.filter((b) => b.earned).length,
    trackPoints,
    dominantTrack: 'codeur',
    competitionOptIn: currentUser.competitionOptIn,
    pseudonymized: currentUser.pseudonymized,
    weeklyGoalXp: currentUser.weeklyGoalXp,
    weeklyXp: currentUser.weeklyXp,
    joinedAt: currentUser.joinedAt,
  }
}

/* ------------------------------------------------------------- apprenant */

export const mockApi = {
  async getMe(): Promise<UserProfile> {
    await delay(120)
    return profile()
  },

  async getDashboard(): Promise<DashboardData> {
    await delay()
    const xp = state.xp
    const level = levelFor(xp)
    const next = nextLevelFor(xp)
    const hydrated = seedQuests.map(hydrateQuest)
    return {
      profile: profile(),
      level,
      nextLevel: next,
      weeklyActivity,
      recentBadges: seedBadges.filter((b) => b.earned).slice(0, 4),
      activeQuests: hydrated.filter((q) => state.enrolled.includes(q.id) && q.progress < 100),
      recommendedQuests: hydrated.filter((q) => !state.enrolled.includes(q.id)).slice(0, 3),
      leaderboardPreview: seedLeaderboard.slice(0, 5),
      trackSnapshot: seedTracks,
      nextMissions: seedMissions.filter((m) => !state.claimedMissions.includes(m.id)),
      streakDays: ['L', 'M', 'M', 'J', 'V', 'S', 'D'],
    }
  },

  async getQuests(params?: { track?: string; difficulty?: string; category?: string; search?: string }): Promise<Quest[]> {
    await delay()
    return seedQuests
      .map(hydrateQuest)
      .filter((q) => {
        if (params?.track && params.track !== 'all' && q.track !== params.track) return false
        if (params?.difficulty && params.difficulty !== 'all' && q.difficulty !== params.difficulty) return false
        if (params?.category && params.category !== 'all' && q.category !== params.category) return false
        if (params?.search && !`${q.title} ${q.subtitle} ${q.category}`.toLowerCase().includes(params.search.toLowerCase())) return false
        return true
      })
  },

  async getQuest(id: number): Promise<Quest> {
    await delay()
    const quest = seedQuests.find((q) => q.id === id)
    if (!quest) throw new Error('Quête introuvable')
    return hydrateQuest(quest)
  },

  async enrollQuest(id: number): Promise<Quest> {
    await delay()
    if (!state.enrolled.includes(id)) {
      state.enrolled.push(id)
      persist()
    }
    const quest = seedQuests.find((q) => q.id === id)
    if (!quest) throw new Error('Quête introuvable')
    return hydrateQuest(quest)
  },

  async submitStep(questId: number, stepId: number, content: string): Promise<{ status: Submission['status']; xpAwarded: number }> {
    await delay(320)
    const quest = seedQuests.find((q) => q.id === questId)
    if (!quest) throw new Error('Quête introuvable')
    const step = quest.steps.find((s) => s.id === stepId)
    if (!step) throw new Error('Étape introuvable')
    const key = `${questId}-${stepId}`
    if (state.stepProgress[key]?.status === 'valide') {
      // Idempotence : une étape déjà validée ne redonne pas d'XP.
      return { status: 'en_attente', xpAwarded: 0 }
    }
    state.stepProgress[key] = { status: 'en_cours' }
    void content
    const result = credit('quest.step', key, Math.round(step.xp * 0.4), `Étape « ${step.title} » déposée`, quest.track)
    return { status: 'en_attente', xpAwarded: result.awarded ? Math.round(step.xp * 0.4) : 0 }
  },

  async getLedger(): Promise<LedgerEntry[]> {
    await delay()
    return state.ledger
  },

  async getLeaderboard(period: string): Promise<LeaderboardEntry[]> {
    await delay()
    const factor = period === 'semaine' ? 0.12 : period === 'semestre' ? 0.7 : period === 'all_time' ? 1.4 : 0.35
    return seedLeaderboard.map((entry) => ({
      ...entry,
      xp: Math.round(entry.xp * factor),
      weeklyXp: Math.round(entry.weeklyXp * (period === 'semaine' ? 1 : 0.3)),
      isCurrentUser: entry.isCurrentUser,
    }))
  },

  async getBadges(): Promise<Badge[]> {
    await delay()
    return seedBadges
  },

  async getTracks(): Promise<Track[]> {
    await delay()
    return seedTracks
  },

  async getLevels(): Promise<LevelConfig[]> {
    await delay()
    return levels
  },

  async getPaths(): Promise<LearningPath[]> {
    await delay()
    return seedPaths
  },

  async getMissions(): Promise<Mission[]> {
    await delay()
    return seedMissions.map((m) => ({ ...m, claimed: state.claimedMissions.includes(m.id) }))
  },

  async claimMission(id: number): Promise<Mission> {
    await delay(260)
    const mission = seedMissions.find((m) => m.id === id)
    if (!mission) throw new Error('Mission introuvable')
    if (state.claimedMissions.includes(id)) return { ...mission, claimed: true }
    state.claimedMissions.push(id)
    credit('mission.complete', `mission-${id}`, mission.xpReward, `Mission « ${mission.title} » réclamée`)
    state.germs += mission.germsReward
    persist()
    return { ...mission, claimed: true }
  },

  async getChallenges(): Promise<Challenge[]> {
    await delay()
    return seedChallenges.map((c) => ({ ...c, joined: state.joinedChallenges.includes(c.id) }))
  },

  async joinChallenge(id: number): Promise<Challenge> {
    await delay(240)
    if (!state.joinedChallenges.includes(id)) {
      state.joinedChallenges.push(id)
      persist()
    }
    const challenge = seedChallenges.find((c) => c.id === id)
    if (!challenge) throw new Error('Challenge introuvable')
    return { ...challenge, joined: true }
  },

  async getRewards(): Promise<Reward[]> {
    await delay()
    return seedRewards.map((r) => ({
      ...r,
      owned: state.purchases.filter((p) => p.rewardId === r.id).reduce((sum, p) => sum + p.quantity, 0),
    }))
  },

  async purchaseReward(id: number): Promise<{ order: RewardOrder; balance: number }> {
    await delay(340)
    const reward = seedRewards.find((r) => r.id === id)
    if (!reward) throw new Error('Récompense introuvable')
    if (reward.stock <= 0) throw new Error('Stock épuisé')
    if (state.germs < reward.cost) throw new Error('Solde insuffisant')
    // Transaction atomique simulée : stock + solde + commande.
    reward.stock -= 1
    state.germs -= reward.cost
    const order: RewardOrder = {
      id: Date.now(),
      userId: currentUser.id,
      userName: currentUser.displayName,
      rewardId: reward.id,
      rewardName: reward.name,
      quantity: 1,
      total: reward.cost,
      status: 'en_attente',
      createdAt: new Date().toISOString(),
    }
    state.purchases.push({ rewardId: reward.id, quantity: 1 })
    persist()
    return { order, balance: state.germs }
  },

  async getCertifications(): Promise<Certification[]> {
    await delay()
    return certifications
  },

  /* -------------------------------------------------------------- La Forge */

  async getForgeCategories(): Promise<ForgeCategory[]> {
    await delay()
    return forgeCategories
  },

  async getForgeThreads(category?: string): Promise<ForgeThread[]> {
    await delay()
    return seedThreads
      .filter((t) => !category || category === 'all' || t.category === category)
      .map((t) => ({
        ...t,
        liked: state.likedThreads.includes(t.id),
        likes: t.likes + (state.likedThreads.includes(t.id) ? 1 : 0),
      }))
  },

  async getForgeThread(id: number): Promise<{ thread: ForgeThread; solutions: ForgeSolution[] }> {
    await delay()
    const thread = seedThreads.find((t) => t.id === id)
    if (!thread) throw new Error('Discussion introuvable')
    return {
      thread: { ...thread, liked: state.likedThreads.includes(thread.id) },
      solutions: seedSolutions
        .filter((s) => s.threadId === id)
        .map((s) => ({ ...s, likes: s.likes + (state.likedSolutions.includes(s.id) ? 1 : 0) })),
    }
  },

  async createThread(payload: { category: string; title: string; body: string; tags: string[] }): Promise<ForgeThread> {
    await delay(300)
    const thread: ForgeThread = {
      id: Date.now(),
      category: payload.category as ForgeThread['category'],
      title: payload.title,
      body: payload.body,
      authorId: currentUser.id,
      authorName: currentUser.displayName,
      authorPseudonym: currentUser.pseudonym,
      authorRole: 'student',
      createdAt: new Date().toISOString(),
      replies: 0,
      views: 1,
      likes: 0,
      liked: false,
      solved: false,
      tags: payload.tags,
      solutionIds: [],
    }
    credit('forge.question', `thread-${thread.id}`, 20, 'Question publiée dans La Forge', 'aidant')
    return thread
  },

  async replyToThread(threadId: number, body: string): Promise<ForgeSolution> {
    await delay(280)
    const solution: ForgeSolution = {
      id: Date.now(),
      threadId,
      authorId: currentUser.id,
      authorName: currentUser.displayName,
      authorPseudonym: currentUser.pseudonym,
      body,
      accepted: false,
      createdAt: new Date().toISOString(),
      likes: 0,
      mine: true,
    }
    return solution
  },

  async acceptSolution(threadId: number, solutionId: number): Promise<ForgeSolution> {
    await delay(260)
    const solution = seedSolutions.find((s) => s.id === solutionId)
    if (!solution) throw new Error('Solution introuvable')
    if (solution.authorId === currentUser.id) throw new Error('Auto-validation interdite')
    const result = credit('forge.answer.accepted', `thread-${threadId}-solution-${solutionId}`, 120, 'Solution acceptée dans La Forge', 'aidant')
    return { ...solution, accepted: true, acceptedAt: new Date().toISOString(), mine: false, likes: solution.likes + (result.awarded ? 1 : 0) }
  },

  async toggleLikeThread(id: number): Promise<{ likes: number; liked: boolean }> {
    await delay(120)
    const thread = seedThreads.find((t) => t.id === id)
    if (!thread) throw new Error('Discussion introuvable')
    const index = state.likedThreads.indexOf(id)
    if (index >= 0) {
      state.likedThreads.splice(index, 1)
      state.ledger = state.ledger.filter((e) => !(e.sourceEvent === 'forge.like' && e.referenceId === `thread-${id}`))
    } else {
      state.likedThreads.push(id)
      credit('forge.like', `thread-${id}`, 5, 'Vote positif donné dans La Forge', 'aidant')
    }
    persist()
    return { likes: thread.likes + (index >= 0 ? 0 : 1), liked: index < 0 }
  },

  async reportThread(threadId: number, reason: string): Promise<void> {
    await delay(200)
    void threadId
    void reason
  },

  /* ------------------------------------------------------------------ admin */

  async getAdminOverview(): Promise<AdminOverview> {
    await delay()
    return {
      ...adminOverview,
      pendingSubmissions: seedSubmissions
        .filter((s) => (state.submissionStatus[s.id] ?? s.status) === 'en_attente'),
      recentOrders: seedOrders.map((o) => ({ ...o, status: state.orderStatus[o.id] ?? o.status })),
    }
  },

  async getAdminSubmissions(): Promise<Submission[]> {
    await delay()
    return seedSubmissions.map((s) => ({ ...s, status: state.submissionStatus[s.id] ?? s.status }))
  },

  async reviewSubmission(id: number, decision: 'validee' | 'rejetee', feedback: string): Promise<Submission> {
    await delay(300)
    const submission = seedSubmissions.find((s) => s.id === id)
    if (!submission) throw new Error('Soumission introuvable')
    state.submissionStatus[id] = decision
    persist()
    if (decision === 'validee') {
      const quest = seedQuests.find((q) => q.id === submission.questId)
      const step = quest?.steps.find((s) => s.id === submission.stepId)
      if (quest && step) {
        state.stepProgress[`${quest.id}-${step.id}`] = { status: 'valide', score: 100 }
        credit('quest.step', `${quest.id}-${step.id}`, step.xp, `Étape « ${step.title} » validée`, quest.track)
      }
    }
    return { ...submission, status: decision, feedback, reviewedAt: new Date().toISOString(), reviewerName: 'Walid Bouarifi' }
  },

  async getAdminRules(): Promise<XpRule[]> {
    await delay()
    return seedRules.map((rule) => ({
      ...rule,
      ...(state.ruleOverrides[rule.id] ?? {}),
      active: state.rulesEnabled[rule.id] ?? rule.active,
    }))
  },

  async updateRule(id: number, patch: Partial<XpRule>): Promise<XpRule> {
    await delay(220)
    const rule = seedRules.find((r) => r.id === id)
    if (!rule) throw new Error('Règle introuvable')
    state.ruleOverrides[id] = { ...(state.ruleOverrides[id] ?? {}), ...patch }
    if (typeof patch.active === 'boolean') state.rulesEnabled[id] = patch.active
    persist()
    return { ...rule, ...patch, version: rule.version + 1 }
  },

  async getAdminOrders(): Promise<RewardOrder[]> {
    await delay()
    return seedOrders.map((o) => ({ ...o, status: state.orderStatus[o.id] ?? o.status }))
  },

  async updateOrder(id: number, status: RewardOrder['status']): Promise<RewardOrder> {
    await delay(220)
    const order = seedOrders.find((o) => o.id === id)
    if (!order) throw new Error('Commande introuvable')
    state.orderStatus[id] = status
    persist()
    return { ...order, status }
  },

  async getAdminStudents(): Promise<Array<{ id: number; name: string; pseudonym: string; email: string; program: string; xp: number; level: number; quests: number; status: string; joinedAt: string }>> {
    await delay()
    return seedLeaderboard.map((entry, i) => ({
      id: entry.userId + i,
      name: entry.displayName,
      pseudonym: entry.pseudonym,
      email: `${entry.pseudonym.toLowerCase().replace(/[^a-z]/g, '.')}@uca.ac.ma`,
      program: entry.program,
      xp: entry.xp,
      level: entry.level,
      quests: entry.questsCompleted,
      status: i === 3 ? 'En attente' : i === 6 ? 'Inactif' : 'Actif',
      joinedAt: new Date(Date.now() - (60 + i * 17) * 86400000).toISOString(),
    }))
  },

  /* ================================================= gestion des rôles & accès */

  async getAdminRoles(): Promise<Role[]> {
    await delay()
    return managedRoles.map((r) => ({ ...r, permissions: [...r.permissions] }))
  },

  async createRole(payload: {
    name: string
    description: string
    color: string
    permissions: string[]
  }): Promise<Role> {
    await delay(240)
    const name = payload.name.trim()
    if (!name) throw new Error('Le nom du rôle est obligatoire.')
    if (managedRoles.some((r) => r.name.toLowerCase() === name.toLowerCase())) {
      throw new Error(`Un rôle nommé « ${name} » existe déjà.`)
    }
    if (payload.permissions.length === 0) {
      throw new Error('Sélectionnez au moins une permission.')
    }
    const code = `${slugify(name)}_${managedRoles.length + 1}`
    const role: Role = {
      id: Math.max(...managedRoles.map((r) => r.id)) + 1,
      code,
      name,
      description: payload.description.trim() || 'Rôle personnalisé créé par la Direction.',
      color: payload.color,
      isSystem: false,
      permissions: [...payload.permissions],
      memberCount: 0,
      createdBy: currentUser.displayName,
      createdAt: new Date().toISOString(),
      revokedAt: null,
      scope: 'global',
    }
    managedRoles.push(role)
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_created',
      target: role.name,
      detail: `Rôle personnalisé créé avec ${role.permissions.length} permissions.`,
      actor: currentUser.displayName,
      createdAt: role.createdAt,
    })
    return { ...role }
  },

  async updateRole(
    id: number,
    patch: { name?: string; description?: string; color?: string; permissions?: string[] },
  ): Promise<Role> {
    await delay(240)
    const role = managedRoles.find((r) => r.id === id)
    if (!role) throw new Error('Rôle introuvable.')
    if (role.isSystem && patch.permissions) {
      throw new Error('Les permissions d’un rôle système sont verrouillées.')
    }
    Object.assign(role, {
      name: patch.name?.trim() ?? role.name,
      description: patch.description?.trim() ?? role.description,
      color: patch.color ?? role.color,
      permissions: patch.permissions ? [...patch.permissions] : role.permissions,
    })
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_updated',
      target: role.name,
      detail: patch.permissions
        ? `Permissions mises à jour (${role.permissions.length} actives).`
        : 'Informations du rôle mises à jour.',
      actor: currentUser.displayName,
      createdAt: new Date().toISOString(),
    })
    return { ...role }
  },

  async duplicateRole(id: number): Promise<Role> {
    await delay(240)
    const source = managedRoles.find((r) => r.id === id)
    if (!source) throw new Error('Rôle introuvable.')
    const copy: Role = {
      ...source,
      id: Math.max(...managedRoles.map((r) => r.id)) + 1,
      code: `${source.code}_copie`,
      name: `${source.name} (copie)`,
      isSystem: false,
      memberCount: 0,
      createdBy: currentUser.displayName,
      createdAt: new Date().toISOString(),
      revokedAt: null,
    }
    managedRoles.push(copy)
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_created',
      target: copy.name,
      detail: `Rôle dupliqué depuis « ${source.name} ».`,
      actor: currentUser.displayName,
      createdAt: copy.createdAt,
    })
    return { ...copy }
  },

  async revokeRole(id: number): Promise<Role> {
    await delay(220)
    const role = managedRoles.find((r) => r.id === id)
    if (!role) throw new Error('Rôle introuvable.')
    if (role.isSystem) throw new Error('Un rôle système ne peut pas être révoqué.')
    role.revokedAt = new Date().toISOString()
    roleAssignments
      .filter((a) => a.roleId === id)
      .forEach((a) => {
        roleAudit.unshift({
          id: Date.now(),
          action: 'role_unassigned',
          target: a.userName,
          detail: `Accès « ${role.name} » révoqué avec le rôle.`,
          actor: currentUser.displayName,
          createdAt: role.revokedAt!,
        })
      })
    const index = roleAssignments.findIndex((a) => a.roleId === id)
    if (index >= 0) roleAssignments.splice(index, 1)
    role.memberCount = 0
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_revoked',
      target: role.name,
      detail: 'Rôle révoqué.',
      actor: currentUser.displayName,
      createdAt: role.revokedAt,
    })
    return { ...role }
  },

  async deleteRole(id: number): Promise<void> {
    await delay(220)
    const role = managedRoles.find((r) => r.id === id)
    if (!role) throw new Error('Rôle introuvable.')
    if (role.isSystem) throw new Error('Un rôle système ne peut pas être supprimé.')
    if (role.memberCount > 0) {
      throw new Error('Retirez les membres de ce rôle avant de le supprimer.')
    }
    managedRoles.splice(managedRoles.indexOf(role), 1)
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_deleted',
      target: role.name,
      detail: 'Rôle personnalisé supprimé.',
      actor: currentUser.displayName,
      createdAt: new Date().toISOString(),
    })
  },

  async getAdminRoleAssignments(): Promise<RoleAssignment[]> {
    await delay()
    return roleAssignments.map((a) => ({ ...a }))
  },

  async assignRole(payload: {
    email: string
    roleCode: string
    reason: string
    expiresAt?: string | null
  }): Promise<RoleAssignment> {
    await delay(260)
    const email = payload.email.trim().toLowerCase()
    const user = managedUsers.find(
      (u) => u.academicEmail.toLowerCase() === email || u.email.toLowerCase() === email,
    )
    if (!user) throw new Error(`Aucun compte ne correspond à « ${email} ».`)
    const role = managedRoles.find((r) => r.code === payload.roleCode)
    if (!role) throw new Error('Rôle introuvable.')
    if (role.revokedAt) throw new Error('Ce rôle est révoqué.')
    if (roleAssignments.some((a) => a.userId === user.id && a.roleCode === role.code)) {
      throw new Error(`${user.fullName} porte déjà ce rôle.`)
    }
    const conflict = CONFLICTING_ROLE_PAIRS.find(
      ([a, b]) =>
        (a === role.code && user.roleCodes.includes(b)) || (b === role.code && user.roleCodes.includes(a)),
    )
    if (conflict) {
      throw new Error(
        `Conflit d’intérêts : « ${role.name} » est incompatible avec un rôle déjà attribué.`,
      )
    }
    const assignment: RoleAssignment = {
      id: Math.max(...roleAssignments.map((a) => a.id)) + 1,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.academicEmail,
      roleId: role.id,
      roleCode: role.code,
      roleName: role.name,
      roleColor: role.color,
      grantedBy: currentUser.displayName,
      grantedAt: new Date().toISOString(),
      expiresAt: payload.expiresAt ?? null,
      reason: payload.reason.trim() || 'Affectation directe par la Direction.',
    }
    roleAssignments.push(assignment)
    role.memberCount += 1
    user.roleCodes = [...user.roleCodes, role.code]
    user.roleNames = [...user.roleNames, role.name]
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_assigned',
      target: user.fullName,
      detail: `Rôle « ${role.name} » attribué.`,
      actor: currentUser.displayName,
      createdAt: assignment.grantedAt,
    })
    return { ...assignment }
  },

  async unassignRole(id: number): Promise<void> {
    await delay(220)
    const index = roleAssignments.findIndex((a) => a.id === id)
    if (index < 0) throw new Error('Affectation introuvable.')
    const [assignment] = roleAssignments.splice(index, 1)
    const role = managedRoles.find((r) => r.code === assignment.roleCode)
    if (role) role.memberCount = Math.max(0, role.memberCount - 1)
    const user = managedUsers.find((u) => u.id === assignment.userId)
    if (user) {
      user.roleCodes = user.roleCodes.filter((c) => c !== assignment.roleCode)
      user.roleNames = user.roleNames.filter((n) => n !== assignment.roleName)
    }
    roleAudit.unshift({
      id: Date.now(),
      action: 'role_unassigned',
      target: assignment.userName,
      detail: `Rôle « ${assignment.roleName} » retiré.`,
      actor: currentUser.displayName,
      createdAt: new Date().toISOString(),
    })
  },

  async getAdminModerators(): Promise<ModeratorAssignment[]> {
    await delay()
    return moderatorAssignments.map((m) => ({ ...m, sections: [...m.sections] }))
  },

  async assignModerator(payload: {
    email: string
    sections: string[]
    expiresAt?: string | null
    note: string
  }): Promise<ModeratorAssignment> {
    await delay(260)
    const email = payload.email.trim().toLowerCase()
    const user = managedUsers.find(
      (u) => u.academicEmail.toLowerCase() === email || u.email.toLowerCase() === email,
    )
    if (!user) throw new Error(`Aucun compte ne correspond à « ${email} ».`)
    if (payload.sections.length === 0) throw new Error('Sélectionnez au moins une rubrique à modérer.')
    if (user.roleCodes.includes('admin')) {
      throw new Error('Un administrateur n’a pas besoin d’un périmètre de modération.')
    }
    const conflict = payload.sections.find((s) => user.moderatedSections.includes(s))
    if (conflict) throw new Error('Cette personne modère déjà cette rubrique.')
    const assignment: ModeratorAssignment = {
      id: Math.max(...moderatorAssignments.map((m) => m.id)) + 1,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.academicEmail,
      sections: [...payload.sections],
      grantedBy: currentUser.displayName,
      grantedAt: new Date().toISOString(),
      expiresAt: payload.expiresAt ?? null,
      note: payload.note.trim() || 'Modération de rubrique.',
      revokedAt: null,
    }
    moderatorAssignments.push(assignment)
    user.isModerator = true
    user.moderatedSections = [...new Set([...user.moderatedSections, ...assignment.sections])]
    roleAudit.unshift({
      id: Date.now(),
      action: 'moderator_assigned',
      target: user.fullName,
      detail: `Modération des rubriques ${assignment.sections
        .map((s) => FORGE_SECTION_LABEL[s] ?? s)
        .join(', ')}.`,
      actor: currentUser.displayName,
      createdAt: assignment.grantedAt,
    })
    return { ...assignment }
  },

  async revokeModerator(id: number): Promise<void> {
    await delay(220)
    const index = moderatorAssignments.findIndex((m) => m.id === id)
    if (index < 0) throw new Error('Périmètre introuvable.')
    const [assignment] = moderatorAssignments.splice(index, 1)
    const user = managedUsers.find((u) => u.id === assignment.userId)
    if (user) {
      user.moderatedSections = user.moderatedSections.filter(
        (s) => !assignment.sections.includes(s),
      )
      user.isModerator = user.moderatedSections.length > 0
    }
    roleAudit.unshift({
      id: Date.now(),
      action: 'moderator_revoked',
      target: assignment.userName,
      detail: `Périmètre de modération révoqué (${assignment.sections
        .map((s) => FORGE_SECTION_LABEL[s] ?? s)
        .join(', ')}).`,
      actor: currentUser.displayName,
      createdAt: new Date().toISOString(),
    })
  },

  async getAdminManagedUsers(): Promise<ManagedUser[]> {
    await delay()
    return managedUsers.map((u) => ({ ...u, roleCodes: [...u.roleCodes], roleNames: [...u.roleNames] }))
  },

  async updateManagedUserStatus(id: number, status: ManagedUserStatus): Promise<ManagedUser> {
    await delay(220)
    const user = managedUsers.find((u) => u.id === id)
    if (!user) throw new Error('Compte introuvable.')
    user.status = status
    return { ...user }
  },

  async getRoleAudit(): Promise<RoleAuditEvent[]> {
    await delay()
    return roleAudit.map((e) => ({ ...e }))
  },

  async updateProfile(patch: Partial<Pick<UserProfile, 'pseudonym' | 'competitionOptIn' | 'weeklyGoalXp' | 'email'>>): Promise<UserProfile> {
    await delay(200)
    Object.assign(currentUser, patch)
    persist()
    return profile()
  },

  async reset(): Promise<void> {
    state = defaultState()
    persist()
  },
}

export type MockApi = typeof mockApi
