import { useState } from 'react'
import {
  Award,
  BookOpenCheck,
  Check,
  GraduationCap,
  KeyRound,
  ListChecks,
  ScrollText,
  ShieldCheck,
  Swords,
  Target,
  type LucideIcon,
} from 'lucide-react'
import { PERMISSION_MODULES, type PermissionModuleCode } from '@/lib/permissions'
import { cn } from '@/lib/utils'

const MODULE_ICONS: Record<PermissionModuleCode, LucideIcon> = {
  moderation: ShieldCheck,
  quests: ScrollText,
  paths: BookOpenCheck,
  missions: Target,
  certifications: Award,
  arena: Swords,
  placement: ListChecks,
  mentorship: GraduationCap,
  roles: KeyRound,
}

export function moduleIcon(code: string): LucideIcon {
  return MODULE_ICONS[code as PermissionModuleCode] ?? ShieldCheck
}

/**
 * Matrice de sélection des permissions, groupée par module métier.
 *
 * Les permissions sont atomiques : on coche un droit précis, jamais
 * « tout le module ». Un module entièrement coché affiche un raccourci
 * « tout cocher / tout décocher ».
 */
export function PermissionMatrix({
  value,
  onChange,
  disabled,
  className,
}: {
  value: string[]
  onChange: (keys: string[]) => void
  disabled?: boolean
  className?: string
}) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})

  const toggle = (key: string) => {
    if (disabled) return
    onChange(value.includes(key) ? value.filter((k) => k !== key) : [...value, key])
  }

  const toggleModule = (keys: string[]) => {
    if (disabled) return
    const allSelected = keys.every((k) => value.includes(k))
    onChange(allSelected ? value.filter((k) => !keys.includes(k)) : [...new Set([...value, ...keys])])
  }

  return (
    <div className={cn('space-y-2', className)}>
      {PERMISSION_MODULES.map((module) => {
        const keys = module.permissions.map((p) => p.key)
        const selected = keys.filter((k) => value.includes(k)).length
        const Icon = MODULE_ICONS[module.code]
        const isCollapsed = collapsed[module.code]
        const complete = selected === keys.length
        const partial = selected > 0 && !complete

        return (
          <div
            key={module.code}
            className={cn(
              'overflow-hidden rounded-xl border transition-colors',
              complete ? 'border-primary/35 bg-primary-soft/40' : partial ? 'border-border-strong bg-surface-2/60' : 'border-border bg-surface',
            )}
          >
            <button
              type="button"
              onClick={() => setCollapsed((c) => ({ ...c, [module.code]: !c[module.code] }))}
              className="flex w-full items-center gap-3 px-3.5 py-3 text-left"
            >
              <span
                className={cn(
                  'grid h-8 w-8 shrink-0 place-items-center rounded-lg',
                  complete ? 'bg-primary text-white' : 'bg-surface-3 text-fg-muted',
                )}
              >
                <Icon className="h-4 w-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[13px] font-semibold text-fg">{module.label}</span>
                <span className="block truncate text-[11.5px] text-fg-subtle">{module.description}</span>
              </span>
              <span
                className={cn(
                  'shrink-0 rounded-full px-2 py-0.5 text-[10.5px] font-bold tabular-nums',
                  complete
                    ? 'bg-primary text-white'
                    : partial
                      ? 'bg-primary-soft text-primary'
                      : 'bg-surface-3 text-fg-subtle',
                )}
              >
                {selected}/{keys.length}
              </span>
            </button>

            {!isCollapsed && (
              <div className="border-t border-border/70 px-3.5 py-2.5">
                <div className="mb-1.5 flex items-center justify-between">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-fg-subtle">
                    Droits du module
                  </p>
                  <button
                    type="button"
                    disabled={disabled}
                    onClick={() => toggleModule(keys)}
                    className="text-[11.5px] font-semibold text-primary transition-colors hover:text-primary/75 disabled:opacity-40"
                  >
                    {complete ? 'Tout décocher' : 'Tout cocher'}
                  </button>
                </div>
                <div className="space-y-0.5">
                  {module.permissions.map((permission) => {
                    const checked = value.includes(permission.key)
                    return (
                      <button
                        key={permission.key}
                        type="button"
                        disabled={disabled}
                        onClick={() => toggle(permission.key)}
                        className={cn(
                          'flex w-full items-start gap-2.5 rounded-lg px-2 py-1.5 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-60',
                          checked ? 'bg-primary-soft/60' : 'hover:bg-surface-2',
                        )}
                      >
                        <span
                          className={cn(
                            'mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded border transition-colors',
                            checked ? 'border-primary bg-primary text-white' : 'border-border-strong bg-surface',
                          )}
                        >
                          {checked && <Check className="h-3 w-3" strokeWidth={3} />}
                        </span>
                        <span className="min-w-0">
                          <span className="block text-[12.5px] font-medium text-fg">{permission.label}</span>
                          <span className="block text-[11px] leading-snug text-fg-subtle">
                            {permission.description}
                          </span>
                          <code className="mt-0.5 block font-mono text-[10px] text-fg-subtle/70">
                            {permission.key}
                          </code>
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
