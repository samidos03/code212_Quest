#!/usr/bin/env bash
#
# Intégration du module « Rôles & accès » dans Code212 Quest.
#
#   ./apply.sh [RACINE_DU_PROJET] [DOSSIER_DU_MODULE]
#
# Par défaut : RACINE_DU_PROJET = repertoire courant, DOSSIER_DU_MODULE = dossier du script.
# Le script est idempotent : le rejouer sur un projet deja integre ne modifie rien.

set -euo pipefail

MODULE_DIR="${2:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
TARGET="${1:-$PWD}"

if [ ! -d "$TARGET/apps/web" ] || [ ! -d "$TARGET/apps/api" ]; then
  echo "ERREUR : '$TARGET' ne ressemble pas a un depot Code212 Quest (apps/web et apps/api attendus)." >&2
  exit 1
fi

if ! command -v patch >/dev/null 2>&1; then
  echo "ERREUR : l'outil 'patch' est introuvable. Installez 'patch' ou appliquez les diffs a la main." >&2
  exit 1
fi

echo "=============================================================="
echo " Integration du module « Roles & acces »"
echo " Module  : $MODULE_DIR"
echo " Cible   : $TARGET"
echo "=============================================================="

# ---------------------------------------------------------------- 1. copie
echo ""
echo "[1/2] Copie des fichiers nouveaux"
copied=0
while IFS= read -r -d '' f; do
  rel="${f#$MODULE_DIR/new-files/}"
  mkdir -p "$TARGET/$(dirname "$rel")"
  cp "$f" "$TARGET/$rel"
  echo "      + $rel"
  copied=$((copied+1))
done < <(find "$MODULE_DIR/new-files" -type f -print0)
echo "      $copied fichier(s) copie(s)"

# ---------------------------------------------------------------- 2. patchs
echo ""
echo "[2/2] Application des patchs sur les fichiers existants"
applied=0
skipped=0
for p in "$MODULE_DIR"/patches/*.patch; do
  [ -e "$p" ] || continue
  name="$(basename "$p")"
  if patch -p1 --forward --batch --silent -d "$TARGET" < "$p"; then
    echo "      OK   $name"
    applied=$((applied+1))
  else
    # soit le module est deja integre, soit le contexte a change.
    # On conserve le motif dans le rapport mais on ne laisse pas de .rej dans le depot.
    rejects="$(find "$TARGET" -name '*.rej' -newer "$p" 2>/dev/null | head -3)"
    if [ -n "$rejects" ]; then
      echo "      SKIP $name (deja applique, ou conflit sur : $(echo "$rejects" | tr '\n' ' '))"
    else
      echo "      SKIP $name (deja applique)"
    fi
    find "$TARGET" -name '*.rej' -delete 2>/dev/null || true
    skipped=$((skipped+1))
  fi
done
echo "      $applied patch(s) applique(s), $skipped deja integres(s)"

echo ""
echo "=============================================================="
echo " Integration terminee."
echo ""
echo " A faire maintenant :"
echo "   cd $TARGET/apps/web && npm run typecheck && npm run build"
echo "   cd $TARGET/apps/api  && php artisan migrate --seed && php artisan test"
echo "=============================================================="
