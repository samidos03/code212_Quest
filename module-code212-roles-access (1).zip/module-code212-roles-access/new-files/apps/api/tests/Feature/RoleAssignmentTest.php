<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Role;
use App\Models\RoleAssignment;
use App\Services\RoleService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Laravel\Sanctum\Sanctum;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * Nominations : attribuer un role a un compte, profiler les acces, les retirer.
 */
class RoleAssignmentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\PermissionSeeder::class);
        $this->seed(\Database\Seeders\SystemRoleSeeder::class);
    }

    #[Test]
    public function un_administrateur_nomme_un_membre_par_email(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $membre = $this->makeUser(['email' => 'mentor.test@uca.ac.ma', 'academic_email' => 'mentor.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $response = $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'mentor.test@uca.ac.ma',
            'role_code' => 'mentor',
            'justification' => 'Mentor référent.',
        ]);

        $response->assertCreated();

        $assignment = RoleAssignment::query()->firstOrFail();

        $this->assertSame($membre->getKey(), $assignment->user_id);
        $this->assertSame('mentor', $assignment->role->code);
        $this->assertTrue($membre->refresh()->hasAppRole('mentor'));
    }

    #[Test]
    public function un_email_inconnu_est_refuse(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'inconnu@uca.ac.ma',
            'role_code' => 'mentor',
        ])->assertStatus(422);
    }

    #[Test]
    public function un_cumul_avant_conflict_d_interets_est_refuse(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $membre = $this->makeUser(['email' => 'evaluateur.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'evaluateur.test@uca.ac.ma',
            'role_code' => 'evaluator',
        ])->assertCreated();

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'evaluateur.test@uca.ac.ma',
            'role_code' => 'quest_creator',
        ])->assertStatus(422);

        $this->assertSame(1, RoleAssignment::query()->count());
    }

    #[Test]
    public function un_membre_ne_peut_pas_etre_nomme_deux_fois(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $membre = $this->makeUser(['email' => 'double.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'double.test@uca.ac.ma',
            'role_code' => 'mentor',
        ])->assertCreated();

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'double.test@uca.ac.ma',
            'role_code' => 'mentor',
        ])->assertStatus(422);
    }

    #[Test]
    public function le_profil_effectif_repose_sur_les_roles_actifs(): void
    {
        $service = app(RoleService::class);
        $membre = $this->makeUser();
        $mentor = Role::query()->where('code', 'mentor')->firstOrFail();

        $this->assertFalse($service->userCan($membre, 'quests.submissions.validate'));

        RoleAssignment::query()->create([
            'user_id' => $membre->getKey(),
            'role_id' => $mentor->getKey(),
            'granted_by' => $membre->getKey(),
            'reason' => 'Test.',
        ]);

        $this->assertTrue($service->userCan($membre->refresh(), 'quests.submissions.validate'));
        $this->assertFalse($service->userCan($membre->refresh(), 'roles.assign'));

        // Un mandat expire ne donne plus d'acces.
        RoleAssignment::query()->where('user_id', $membre->getKey())->update([
            'expires_at' => Carbon::now()->subDay(),
        ]);

        $this->assertFalse($service->userCan($membre->refresh(), 'quests.submissions.validate'));
    }

    #[Test]
    public function un_administrateur_beneficie_du_profil_complet(): void
    {
        $service = app(RoleService::class);
        $admin = $this->makeUser(['roles' => ['admin']]);

        $this->assertTrue($service->userCan($admin, 'roles.assign'));
        $this->assertTrue($service->userCan($admin, 'arena.challenges.arbitrate'));
        $this->assertCount(42, $service->effectivePermissions($admin));
    }

    #[Test]
    public function le_retrait_d_une_nomination_libere_le_membre(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $membre = $this->makeUser(['email' => 'retrait.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'retrait.test@uca.ac.ma',
            'role_code' => 'mentor',
        ])->assertCreated();

        $assignment = RoleAssignment::query()->firstOrFail();

        $this->deleteJson("/api/v1/admin/role-assignments/{$assignment->getKey()}")->assertStatus(204);

        $this->assertSame(0, RoleAssignment::query()->count());
        $this->assertFalse($membre->refresh()->hasAppRole('mentor'));
    }

    #[Test]
    public function le_registre_des_affectations_est_expose(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $membre = $this->makeUser(['email' => 'registre.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/role-assignments', [
            'email' => 'registre.test@uca.ac.ma',
            'role_code' => 'coding_league',
        ])->assertCreated();

        $response = $this->getJson('/api/v1/admin/role-assignments')->assertOk();

        $this->assertCount(1, $response->json('data'));
        $this->assertSame('Responsable Coding League', $response->json('data.0.role_name'));
    }
}
