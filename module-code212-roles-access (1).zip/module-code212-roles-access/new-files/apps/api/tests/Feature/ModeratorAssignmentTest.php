<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\ModeratorScope;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Laravel\Sanctum\Sanctum;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * Perimetres de moderation sur La Forge.
 */
class ModeratorAssignmentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\PermissionSeeder::class);
        $this->seed(\Database\Seeders\SystemRoleSeeder::class);
    }

    #[Test]
    public function un_administrateur_confie_un_perimetre_de_modération(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $moderateur = $this->makeUser(['email' => 'mod.test@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $response = $this->postJson('/api/v1/admin/moderators', [
            'email' => 'mod.test@uca.ac.ma',
            'sections' => ['entraide', 'cafe'],
            'note' => 'Relais des questions.',
            'expire_le' => Carbon::now()->addMonths(6)->toDateString(),
        ]);

        $response->assertCreated();

        $scope = ModeratorScope::query()->firstOrFail();

        $this->assertSame($moderateur->getKey(), $scope->user_id);
        $this->assertSame(['entraide', 'cafe'], $scope->sections);
        $this->assertTrue($scope->isActive());
    }

    #[Test]
    public function une_rubrique_inconnue_est_refusee(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'mod.inconnu@uca.ac.ma',
            'sections' => ['rubrique-inexistante'],
        ])->assertStatus(422);
    }

    #[Test]
    public function un_perimetre_sans_rubrique_est_refuse(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'mod.vide@uca.ac.ma',
            'sections' => [],
        ])->assertStatus(422);
    }

    #[Test]
    public function un_administrateur_ne_peut_pas_avoir_de_perimetre(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'admin.test@uca.ac.ma',
            'sections' => ['entraide'],
        ])->assertStatus(422);
    }

    #[Test]
    public function un_perimetre_expire_n_est_plus_actif(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $moderateur = $this->makeUser(['email' => 'mod.expire@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'mod.expire@uca.ac.ma',
            'sections' => ['entraide'],
        ])->assertCreated();

        $scope = ModeratorScope::query()->firstOrFail();

        $scope->expires_at = Carbon::now()->subDay();
        $scope->save();

        $this->assertFalse($scope->refresh()->isActive());
    }

    #[Test]
    public function la_revoque_ferme_le_perimetre(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $moderateur = $this->makeUser(['email' => 'mod.revoque@uca.ac.ma']);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'mod.revoque@uca.ac.ma',
            'sections' => ['projets'],
        ])->assertCreated();

        $scope = ModeratorScope::query()->firstOrFail();

        $this->deleteJson("/api/v1/admin/moderators/{$scope->getKey()}")->assertStatus(204);

        $this->assertFalse($scope->refresh()->isActive());
    }

    #[Test]
    public function un_apprenant_ne_peut_pas_nommer_de_moderateur(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['student']]), ['read', 'write']);

        $this->getJson('/api/v1/admin/moderators')->assertForbidden();
        $this->postJson('/api/v1/admin/moderators', [
            'email' => 'interdit@uca.ac.ma',
            'sections' => ['entraide'],
        ])->assertForbidden();
    }

    #[Test]
    public function la_liste_des_comptes_expose_filiere_et_etablissement(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);

        User::query()->create([
            'name' => 'Aya Nassiri',
            'first_name' => 'Aya',
            'last_name' => 'Nassiri',
            'email' => 'aya.nassiri@uca.ac.ma',
            'academic_email' => 'aya.nassiri@uca.ac.ma',
            'filiere' => 'Génie informatique',
            'etablissement' => 'FST',
            'password' => bcrypt('motdepasse123'),
            'roles' => ['student'],
            'locale' => 'fr',
        ]);

        Sanctum::actingAs($admin, ['read', 'write']);

        $response = $this->getJson('/api/v1/admin/users')->assertOk();

        $this->assertNotEmpty($response->json('data'));
        $this->assertSame('FST', $response->json('data.0.school'));
        $this->assertSame('Génie informatique', $response->json('data.0.program'));
    }
}
