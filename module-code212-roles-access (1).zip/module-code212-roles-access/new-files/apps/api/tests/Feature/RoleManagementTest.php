<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Permission;
use App\Models\Role;
use App\Models\RoleAssignment;
use App\Support\PermissionCatalog;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * Creation et cycle de vie des roles applicatifs.
 */
class RoleManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\PermissionSeeder::class);
        $this->seed(\Database\Seeders\SystemRoleSeeder::class);
    }

    #[Test]
    public function le_catalogue_expose_neuf_modules_quarante_deux_permissions(): void
    {
        $modules = PermissionCatalog::toArray();

        $this->assertCount(9, $modules);
        $this->assertCount(42, PermissionCatalog::keys());

        $total = 0;

        foreach ($modules as $module) {
            $total += count($module['permissions']);
        }

        $this->assertSame(42, $total);
    }

    #[Test]
    public function un_administrateur_cree_un_role_personnalise(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $response = $this->postJson('/api/v1/admin/roles', [
            'nom' => 'Référent Cybersécurité',
            'description' => 'Pilote le parcours Cybersécurité.',
            'couleur' => '#10b981',
            'permissions' => ['quests.read', 'quests.create', 'moderation.reports.read'],
        ]);

        $response->assertCreated();

        $role = Role::query()->where('name', 'Référent Cybersécurité')->firstOrFail();

        $this->assertFalse($role->is_system);
        $this->assertCount(3, $role->permissions);
    }

    #[Test]
    public function une_permission_hors_catalogue_est_refusee(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/roles', [
            'nom' => 'Role invalide',
            'permissions' => ['quests.read', 'permissions.inconnue'],
        ])->assertStatus(422);

        $this->assertSame(0, Role::query()->where('name', 'Role invalide')->count());
    }

    #[Test]
    public function un_role_sans_permission_est_refuse(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $this->postJson('/api/v1/admin/roles', [
            'nom' => 'Role vide',
            'permissions' => [],
        ])->assertStatus(422);
    }

    #[Test]
    public function les_permissions_d_un_role_systeme_sont_verrouillees(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);

        Sanctum::actingAs($admin, ['read', 'write']);

        $mentor = Role::query()->where('code', 'mentor')->firstOrFail();

        $this->patchJson("/api/v1/admin/roles/{$mentor->getKey()}", [
            'permissions' => ['quests.delete'],
        ])->assertStatus(422);

        $this->assertNotContains('quests.delete', $mentor->refresh()->permissions->pluck('key')->all());
    }

    #[Test]
    public function un_role_avec_des_membres_ne_peut_pas_etre_supprime(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $member = $this->makeUser();
        $role = Role::query()->where('code', 'mentor')->firstOrFail();

        RoleAssignment::query()->create([
            'user_id' => $member->getKey(),
            'role_id' => $role->getKey(),
            'granted_by' => $admin->getKey(),
            'reason' => 'Test.',
        ]);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->deleteJson("/api/v1/admin/roles/{$role->getKey()}")->assertStatus(422);

        $this->assertSame(1, Role::query()->where('code', 'mentor')->count());
    }

    #[Test]
    public function un_role_personnalise_sans_membre_est_supprimable(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read', 'write']);

        $role = Role::query()->where('code', 'referent_data')->firstOrFail();

        $this->deleteJson("/api/v1/admin/roles/{$role->getKey()}")->assertStatus(204);

        $this->assertNull(Role::query()->where('code', 'referent_data')->first());
    }

    #[Test]
    public function la_revocation_d_un_role_retire_les_membres(): void
    {
        $admin = $this->makeUser(['roles' => ['admin']]);
        $member = $this->makeUser();
        $role = Role::query()->where('code', 'referent_data')->firstOrFail();

        RoleAssignment::query()->create([
            'user_id' => $member->getKey(),
            'role_id' => $role->getKey(),
            'granted_by' => $admin->getKey(),
            'reason' => 'Test.',
        ]);

        Sanctum::actingAs($admin, ['read', 'write']);

        $this->postJson("/api/v1/admin/roles/{$role->getKey()}/revoke")->assertOk();

        $this->assertNotNull($role->refresh()->revoked_at);
        $this->assertSame(0, RoleAssignment::query()->where('role_id', $role->getKey())->count());
    }

    #[Test]
    public function un_apprenant_ne_peut_pas_gerer_les_roles(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['student']]), ['read', 'write']);

        $this->getJson('/api/v1/admin/roles')->assertForbidden();
        $this->postJson('/api/v1/admin/roles', [
            'nom' => 'Role interdit',
            'permissions' => ['quests.read'],
        ])->assertForbidden();
    }

    #[Test]
    public function un_evaluateur_ne_peut_pas_creer_de_role_mais_peut_consulter(): void
    {
        $evaluator = $this->makeUser(['roles' => ['student']]);
        $role = Role::query()->where('code', 'evaluator')->firstOrFail();

        RoleAssignment::query()->create([
            'user_id' => $evaluator->getKey(),
            'role_id' => $role->getKey(),
            'granted_by' => $evaluator->getKey(),
            'reason' => 'Test.',
        ]);

        Sanctum::actingAs($evaluator, ['read', 'write']);

        $this->getJson('/api/v1/admin/roles')->assertOk();
        $this->postJson('/api/v1/admin/roles', [
            'nom' => 'Role interdit',
            'permissions' => ['quests.read'],
        ])->assertForbidden();
    }

    #[Test]
    public function les_permissions_du_catalogue_sont_bien_enregistrees(): void
    {
        $this->assertSame(42, Permission::query()->count());
        $this->assertSame(9, Permission::query()->distinct()->count('module'));
    }
}
