<?php

declare(strict_types=1);

namespace App\Services;

use App\Exceptions\BusinessRuleException;
use App\Models\Role;
use App\Models\RoleAssignment;
use App\Models\User;
use App\Support\PermissionCatalog;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Cadrage des roles applicatifs et des nominations.
 *
 * Regles non negociables :
 * - les permissions sont atomiques et issues du catalogue ;
 * - un role systeme n'est ni modifiable ni supprimable ;
 * - `admin` donne un acces total et n'est pas materialise en base ;
 * - toute mutation est tracee dans `audit_logs`.
 */
final class RoleService
{
    public function __construct(
        private readonly AuditLogger $audit,
    ) {
    }

    /**
     * Catalogue des permissions, pret a etre consomme par le front.
     *
     * @return list<array<string, mixed>>
     */
    public function catalog(): array
    {
        return PermissionCatalog::toArray();
    }

    /**
     * Tous les roles avec leurs permissions et leur nombre de membres.
     *
     * @return Collection<int, Role>
     */
    public function all(): Collection
    {
        return Role::query()
            ->with(['permissions', 'assignments'])
            ->orderBy('is_system', 'desc')
            ->orderBy('name')
            ->get();
    }

    /**
     * Creer un role personnalise.
     *
     * @param array{name: string, description?: string, color?: string, permissions: list<string>} $payload
     */
    public function create(array $payload, User $actor): Role
    {
        $name = trim($payload['name']);

        if ($name === '') {
            throw BusinessRuleException::make('Le nom du rôle est obligatoire.');
        }

        if (Role::query()->whereRaw('lower(name) = lower(?)', [$name])->exists()) {
            throw BusinessRuleException::make(sprintf('Un rôle nommé « %s » existe déjà.', $name));
        }

        $permissions = $this->normalizePermissions($payload['permissions'] ?? []);

        if ($permissions === []) {
            throw BusinessRuleException::make('Sélectionnez au moins une permission.');
        }

        $role = DB::transaction(function () use ($payload, $name, $permissions, $actor): Role {
            $role = Role::query()->create([
                'code' => $this->uniqueCode($name),
                'name' => $name,
                'description' => trim($payload['description'] ?? '') ?: 'Rôle personnalisé créé par la Direction.',
                'color' => $payload['color'] ?? '#6701e6',
                'is_system' => false,
                'scope' => 'global',
                'created_by' => $actor->getKey(),
            ]);

            $this->syncPermissions($role, $permissions);

            return $role;
        });

        $this->audit->log(
            $actor,
            'admin.role_created',
            'role',
            $role->getKey(),
            null,
            ['nom' => $role->name, 'permissions' => count($permissions)],
        );

        return $role->load(['permissions', 'assignments']);
    }

    /**
     * Modifier un role personnalise (les roles systeme sont verrouilles).
     *
     * @param array{name?: string, description?: string, color?: string, permissions?: list<string>} $payload
     */
    public function update(Role $role, array $payload, User $actor): Role
    {
        if ($role->is_system) {
            throw BusinessRuleException::make('Les permissions d’un rôle système sont verrouillées.');
        }

        $permissions = array_key_exists('permissions', $payload)
            ? $this->normalizePermissions($payload['permissions'])
            : null;

        if ($permissions !== null && $permissions === []) {
            throw BusinessRuleException::make('Sélectionnez au moins une permission.');
        }

        DB::transaction(function () use ($role, $payload, $permissions): void {
            if (array_key_exists('name', $payload)) {
                $name = trim($payload['name']);
                $role->name = $name === '' ? $role->name : $name;
            }

            if (array_key_exists('description', $payload)) {
                $role->description = trim($payload['description']);
            }

            if (array_key_exists('color', $payload)) {
                $role->color = $payload['color'];
            }

            $role->save();

            if ($permissions !== null) {
                $this->syncPermissions($role, $permissions);
            }
        });

        $this->audit->log(
            $actor,
            'admin.role_updated',
            'role',
            $role->getKey(),
            null,
            ['nom' => $role->name, 'permissions' => $permissions === null ? null : count($permissions)],
        );

        return $role->load(['permissions', 'assignments']);
    }

    /**
     * Dupliquer un role pour en creer une variante personnalisee.
     */
    public function duplicate(Role $source, User $actor): Role
    {
        $copy = $this->create(
            [
                'name' => $source->name.' (copie)',
                'description' => $source->description,
                'color' => $source->color,
                'permissions' => $source->permissions->pluck('key')->all(),
            ],
            $actor,
        );

        $this->audit->log(
            $actor,
            'admin.role_duplicated',
            'role',
            $copy->getKey(),
            null,
            ['source' => $source->code],
        );

        return $copy;
    }

    /**
     * Revoquer un role : ses membres perdent immediatement l'acces.
     */
    public function revoke(Role $role, User $actor): Role
    {
        if ($role->is_system) {
            throw BusinessRuleException::make('Un rôle système ne peut pas être révoqué.');
        }

        DB::transaction(function () use ($role): void {
            $role->revoked_at = Carbon::now();
            $role->save();

            RoleAssignment::query()->where('role_id', $role->getKey())->delete();
        });

        $this->audit->log($actor, 'admin.role_revoked', 'role', $role->getKey());

        return $role->load(['permissions', 'assignments']);
    }

    /**
     * Supprimer un role personnalise depourvu de membres.
     */
    public function delete(Role $role, User $actor): void
    {
        if ($role->is_system) {
            throw BusinessRuleException::make('Un rôle système ne peut pas être supprimé.');
        }

        if ($role->assignments()->count() > 0) {
            throw BusinessRuleException::make('Retirez les membres de ce rôle avant de le supprimer.');
        }

        DB::transaction(function () use ($role): void {
            DB::table('role_permissions')->where('role_id', $role->getKey())->delete();
            $role->delete();
        });

        $this->audit->log($actor, 'admin.role_deleted', 'role', $role->getKey(), null, ['nom' => $role->name]);
    }

    /**
     * Nommer un membre de l'equipe.
     */
    public function assign(
        User $user,
        string $roleCode,
        ?string $reason,
        ?Carbon $expiresAt,
        User $actor,
    ): RoleAssignment {
        $role = Role::query()->where('code', $roleCode)->first();

        if ($role === null) {
            throw BusinessRuleException::make('Rôle introuvable.');
        }

        if (! $role->isActive()) {
            throw BusinessRuleException::make('Ce rôle est révoqué.');
        }

        if (RoleAssignment::query()
            ->where('user_id', $user->getKey())
            ->where('role_id', $role->getKey())
            ->exists()
        ) {
            throw BusinessRuleException::make(sprintf('%s porte déjà ce rôle.', $user->name));
        }

        $existing = $user->roleCodes();

        if (PermissionCatalog::hasConflict($roleCode, $existing)) {
            throw BusinessRuleException::make(
                sprintf('Conflit d’intérêts : « %s » est incompatible avec un rôle déjà attribué.', $role->name),
            );
        }

        $assignment = DB::transaction(fn (): RoleAssignment => RoleAssignment::query()->create([
            'user_id' => $user->getKey(),
            'role_id' => $role->getKey(),
            'granted_by' => $actor->getKey(),
            'expires_at' => $expiresAt,
            'reason' => trim($reason ?? '') ?: 'Affectation directe par la Direction.',
        ]));

        $this->audit->log(
            $actor,
            'admin.role_assigned',
            'user',
            $user->getKey(),
            $assignment->reason,
            ['role' => $role->code],
        );

        return $assignment->load(['user', 'role', 'granter']);
    }

    /**
     * Retirer une nomination.
     */
    public function unassign(RoleAssignment $assignment, User $actor): void
    {
        $role = $assignment->role;
        $user = $assignment->user;

        $assignment->delete();

        $this->audit->log(
            $actor,
            'admin.role_unassigned',
            'user',
            $user?->getKey(),
            null,
            ['role' => $role?->code],
        );
    }

    /**
     * Permissions effectives d'un compte (union des roles actifs non expires).
     *
     * @return list<string>
     */
    public function effectivePermissions(User $user): array
    {
        if ($user->isAdmin()) {
            return PermissionCatalog::keys();
        }

        return DB::table('role_assignments')
            ->join('roles', 'roles.id', '=', 'role_assignments.role_id')
            ->join('role_permissions', 'role_permissions.role_id', '=', 'roles.id')
            ->where('role_assignments.user_id', $user->getKey())
            ->whereNull('roles.revoked_at')
            ->where(static function ($query): void {
                $query->whereNull('role_assignments.expires_at')
                    ->orWhere('role_assignments.expires_at', '>', now());
            })
            ->distinct()
            ->pluck('role_permissions.permission_key')
            ->filter(static fn (?string $key): bool => $key !== null)
            ->values()
            ->all();
    }

    /**
     * Le compte dispose-t-il de la permission demandee ?
     */
    public function userCan(User $user, string $permissionKey): bool
    {
        return in_array($permissionKey, $this->effectivePermissions($user), true);
    }

    /**
     * Normalise et valide une liste de cles de permissions.
     *
     * @param list<string> $keys
     *
     * @return list<string>
     */
    private function normalizePermissions(array $keys): array
    {
        $clean = array_values(array_unique(array_filter(
            array_map(static fn (string $key): string => trim($key), $keys),
            static fn (string $key): bool => $key !== '',
        )));

        $unknown = array_values(array_diff($clean, PermissionCatalog::keys()));

        if ($unknown !== []) {
            throw BusinessRuleException::make(sprintf(
                'Permission(s) inconnue(s) : %s.',
                implode(', ', $unknown),
            ));
        }

        return $clean;
    }

    /**
     * Figure les permissions d'un role.
     *
     * @param list<string> $permissions
     */
    private function syncPermissions(Role $role, array $permissions): void
    {
        DB::table('role_permissions')->where('role_id', $role->getKey())->delete();

        $rows = [];

        foreach ($permissions as $key) {
            $rows[] = [
                'role_id' => $role->getKey(),
                'permission_key' => $key,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ];
        }

        foreach (array_chunk($rows, 200) as $chunk) {
            DB::table('role_permissions')->insert($chunk);
        }
    }

    /**
     * Genere un code unique a partir du libelle.
     */
    private function uniqueCode(string $name): string
    {
        $base = Str::slug($name, '_');
        $code = $base;
        $index = 2;

        while (Role::query()->where('code', $code)->exists()) {
            $code = $base.'_'.$index;
            $index++;
        }

        return $code;
    }
}
