<?php

declare(strict_types=1);

namespace App\Services;

use App\Exceptions\BusinessRuleException;
use App\Models\ModeratorScope;
use App\Models\User;
use App\Support\PermissionCatalog;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Perimetres de moderation sur La Forge.
 *
 * Un compte = un perimetre, portant les rubriques qui lui sont confiees.
 * Le mandat peut etre date ; au-dela il n'a plus effet.
 */
final class ModeratorService
{
    public function __construct(
        private readonly AuditLogger $audit,
    ) {
    }

    /**
     * Tous les perimetres, revoked et expires compris.
     *
     * @return Collection<int, ModeratorScope>
     */
    public function all(): Collection
    {
        return ModeratorScope::query()
            ->with(['user', 'granter'])
            ->orderBy('user_id')
            ->get();
    }

    /**
     * Confier (ou etendre) un perimetre de moderation a un compte.
     *
     * @param list<string> $sections
     */
    public function assign(
        User $user,
        array $sections,
        ?Carbon $expiresAt,
        string $note,
        User $actor,
    ): ModeratorScope {
        $sections = $this->normalizeSections($sections);

        if ($user->isAdmin()) {
            throw BusinessRuleException::make('Un administrateur n’a pas besoin d’un périmètre de modération.');
        }

        $existing = ModeratorScope::query()
            ->where('user_id', $user->getKey())
            ->whereNull('revoked_at')
            ->first();

        if ($existing !== null) {
            $duplicates = array_values(array_intersect($existing->sections ?? [], $sections));

            if ($duplicates !== []) {
                throw BusinessRuleException::make('Cette personne modère déjà cette rubrique.');
            }
        }

        $scope = DB::transaction(function () use ($user, $sections, $expiresAt, $note, $actor, $existing): ModeratorScope {
            if ($existing !== null) {
                $existing->sections = array_values(array_unique(array_merge($existing->sections ?? [], $sections)));
                $existing->expires_at = $expiresAt;
                $existing->scope_note = trim($note) !== '' ? trim($note) : $existing->scope_note;
                $existing->revoked_at = null;
                $existing->granted_by = $actor->getKey();
                $existing->save();

                return $existing;
            }

            return ModeratorScope::query()->create([
                'user_id' => $user->getKey(),
                'sections' => $sections,
                'granted_by' => $actor->getKey(),
                'expires_at' => $expiresAt,
                'scope_note' => trim($note) ?: 'Modération de rubrique.',
            ]);
        });

        $this->audit->log(
            $actor,
            'admin.moderator_assigned',
            'user',
            $user->getKey(),
            $scope->scope_note,
            ['sections' => $scope->sections],
        );

        return $scope->load(['user', 'granter']);
    }

    /**
     * Revoquer un perimetre de moderation.
     */
    public function revoke(ModeratorScope $scope, User $actor): void
    {
        $scope->revoked_at = Carbon::now();
        $scope->save();

        $this->audit->log(
            $actor,
            'admin.moderator_revoked',
            'user',
            $scope->user_id,
            null,
            ['sections' => $scope->sections],
        );
    }

    /**
     * Rubriques valides pour un perimetre.
     *
     * @param list<string> $sections
     *
     * @return list<string>
     */
    private function normalizeSections(array $sections): array
    {
        $known = array_column(PermissionCatalog::forgeSections(), 'slug');

        $clean = array_values(array_unique(array_filter(
            array_map(static fn (string $slug): string => trim($slug), $sections),
            static fn (string $slug): bool => $slug !== '',
        )));

        if ($clean === []) {
            throw BusinessRuleException::make('Sélectionnez au moins une rubrique à modérer.');
        }

        $unknown = array_values(array_diff($clean, $known));

        if ($unknown !== []) {
            throw BusinessRuleException::make(sprintf('Rubrique(s) inconnue(s) : %s.', implode(', ', $unknown)));
        }

        return $clean;
    }
}
