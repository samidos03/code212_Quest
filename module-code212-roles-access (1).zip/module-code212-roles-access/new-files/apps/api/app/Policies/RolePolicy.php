<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Role;
use App\Models\User;
use App\Services\RoleService;

/**
 * Autorisations sur les roles applicatifs.
 */
class RolePolicy
{
    public function __construct(
        private readonly RoleService $roles,
    ) {
    }

    public function viewAny(User $user): bool
    {
        return $this->roles->userCan($user, 'roles.read');
    }

    public function create(User $user): bool
    {
        return $this->roles->userCan($user, 'roles.create');
    }

    public function update(User $user, Role $role): bool
    {
        return ! $role->is_system && $this->roles->userCan($user, 'roles.update');
    }

    public function revoke(User $user, Role $role): bool
    {
        return ! $role->is_system && $this->roles->userCan($user, 'roles.revoke');
    }

    public function delete(User $user, Role $role): bool
    {
        return ! $role->is_system && $this->roles->userCan($user, 'roles.delete');
    }

    public function assign(User $user): bool
    {
        return $this->roles->userCan($user, 'roles.assign');
    }
}
