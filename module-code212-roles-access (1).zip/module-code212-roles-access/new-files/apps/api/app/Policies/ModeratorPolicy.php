<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use App\Services\RoleService;

/**
 * Autorisations sur les perimetres de moderation.
 */
class ModeratorPolicy
{
    public function __construct(
        private readonly RoleService $roles,
    ) {
    }

    public function viewAny(User $user): bool
    {
        return $this->roles->userCan($user, 'moderation.reports.read');
    }

    public function assign(User $user): bool
    {
        return $this->roles->userCan($user, 'moderation.moderators.manage');
    }
}
