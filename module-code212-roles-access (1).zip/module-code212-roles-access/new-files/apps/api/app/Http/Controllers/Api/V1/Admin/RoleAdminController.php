<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Exceptions\BusinessRuleException;
use App\Http\Controllers\Controller;
use App\Http\Requests\AssignRoleRequest;
use App\Http\Requests\StoreRoleRequest;
use App\Http\Requests\UpdateRoleRequest;
use App\Http\Resources\RoleAssignmentResource;
use App\Http\Resources\RoleResource;
use App\Models\AuditLog;
use App\Models\Role;
use App\Models\RoleAssignment;
use App\Models\User;
use App\Services\RoleService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

/**
 * Gestion des roles applicatifs et des nominations.
 */
class RoleAdminController extends Controller
{
    public function __construct(
        private readonly RoleService $roles,
    ) {
    }

    /**
     * Liste des roles avec permissions et nombre de membres.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Role::class);

        $roles = $this->roles->all();

        return ApiResponse::collection(RoleResource::collection($roles));
    }

    /**
     * Catalogue des permissions, groupe par module metier.
     */
    public function permissions(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Role::class);

        return ApiResponse::data($this->roles->catalog());
    }

    /**
     * Creer un role personnalise.
     */
    public function store(StoreRoleRequest $request): JsonResponse
    {
        $this->authorize('create', Role::class);

        $payload = $request->validated();

        $role = $this->roles->create(
            [
                'name' => $payload['nom'],
                'description' => $payload['description'] ?? '',
                'color' => $payload['couleur'] ?? '#6701e6',
                'permissions' => $payload['permissions'],
            ],
            $request->user(),
        );

        return ApiResponse::resource(new RoleResource($role), 201);
    }

    /**
     * Modifier un role personnalise.
     */
    public function update(UpdateRoleRequest $request, Role $role): JsonResponse
    {
        $this->authorize('update', $request->user());

        $payload = $request->validated();

        $patch = [];

        if (array_key_exists('nom', $payload)) {
            $patch['name'] = $payload['nom'];
        }

        if (array_key_exists('description', $payload)) {
            $patch['description'] = $payload['description'] ?? '';
        }

        if (array_key_exists('couleur', $payload)) {
            $patch['color'] = $payload['couleur'];
        }

        if (array_key_exists('permissions', $payload)) {
            $patch['permissions'] = $payload['permissions'];
        }

        $updated = $this->roles->update($role, $patch, $request->user());

        return ApiResponse::resource(new RoleResource($updated));
    }

    /**
     * Dupliquer un role pour en creer une variante.
     */
    public function duplicate(Request $request, Role $role): JsonResponse
    {
        $this->authorize('create', Role::class);

        $copy = $this->roles->duplicate($role, $request->user());

        return ApiResponse::resource(new RoleResource($copy), 201);
    }

    /**
     * Revoquer un role personnalise.
     */
    public function revoke(Request $request, Role $role): JsonResponse
    {
        $this->authorize('revoke', $request->user());

        $revoked = $this->roles->revoke($role, $request->user());

        return ApiResponse::resource(new RoleResource($revoked));
    }

    /**
     * Supprimer un role personnalise depourvu de membres.
     */
    public function destroy(Request $request, Role $role): JsonResponse
    {
        $this->authorize('delete', $request->user());

        $this->roles->delete($role, $request->user());

        return ApiResponse::data(null, 204);
    }

    /**
     * Registre des nominations en cours.
     */
    public function assignments(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Role::class);

        $assignments = RoleAssignment::query()
            ->with(['user', 'role', 'granter'])
            ->orderByDesc('created_at')
            ->get();

        return ApiResponse::collection(RoleAssignmentResource::collection($assignments));
    }

    /**
     * Nommer un membre de l'equipe a partir de son email.
     */
    public function assign(AssignRoleRequest $request): JsonResponse
    {
        $this->authorize('assign', Role::class);

        $payload = $request->validated();

        $user = $this->findUserByEmail($payload['email']);

        $expiresAt = isset($payload['expire_le'])
            ? Carbon::parse($payload['expire_le'])
            : null;

        $assignment = $this->roles->assign(
            $user,
            $payload['role_code'],
            $payload['justification'] ?? null,
            $expiresAt,
            $request->user(),
        );

        return ApiResponse::resource(new RoleAssignmentResource($assignment), 201);
    }

    /**
     * Retirer une nomination.
     */
    public function unassign(Request $request, RoleAssignment $roleAssignment): JsonResponse
    {
        $this->authorize('assign', Role::class);

        $this->roles->unassign($roleAssignment, $request->user());

        return ApiResponse::data(null, 204);
    }

    /**
     * Journal des evenements lies aux roles et a la moderation.
     */
    public function audit(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Role::class);

        $events = AuditLog::query()
            ->where('action', 'like', 'admin.role_%')
            ->orWhere('action', 'like', 'admin.moderator_%')
            ->orderByDesc('created_at')
            ->limit((int) $request->integer('limite', 50))
            ->get();

        return ApiResponse::collection($events->map(static fn (AuditLog $log): array => [
            'id' => $log->id,
            'action' => $log->action,
            'target' => $log->target_type,
            'detail' => $log->justification ?? '',
            'actor' => $log->actor_id === null ? 'Système' : (string) $log->actor_id,
            'created_at' => $log->created_at?->toIso8601String(),
        ]));
    }

    /**
     * Retrouve un compte par son email academique ou son email de connexion.
     */
    private function findUserByEmail(string $email): User
    {
        $normalized = trim($email);

        $user = User::query()
            ->where('academic_email', $normalized)
            ->orWhere('email', $normalized)
            ->first();

        if ($user === null) {
            throw BusinessRuleException::make(sprintf('Aucun compte ne correspond à « %s ».', $email));
        }

        return $user;
    }
}
