<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Exceptions\BusinessRuleException;
use App\Http\Controllers\Controller;
use App\Http\Requests\AssignModeratorRequest;
use App\Http\Resources\ModeratorScopeResource;
use App\Models\ModeratorScope;
use App\Models\User;
use App\Services\ModeratorService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

/**
 * Perimetres de moderation sur La Forge.
 */
class ModeratorAdminController extends Controller
{
    public function __construct(
        private readonly ModeratorService $moderators,
    ) {
    }

    /**
     * Liste des perimetres de moderation.
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', ModeratorScope::class);

        $scopes = $this->moderators->all();

        return ApiResponse::collection(ModeratorScopeResource::collection($scopes));
    }

    /**
     * Confier (ou etendre) un perimetre de moderation.
     */
    public function store(AssignModeratorRequest $request): JsonResponse
    {
        $this->authorize('assign', ModeratorScope::class);

        $payload = $request->validated();

        $user = $this->findUserByEmail($payload['email']);

        $expiresAt = isset($payload['expire_le'])
            ? Carbon::parse($payload['expire_le'])
            : null;

        $scope = $this->moderators->assign(
            $user,
            $payload['sections'],
            $expiresAt,
            $payload['note'] ?? '',
            $request->user(),
        );

        return ApiResponse::resource(new ModeratorScopeResource($scope), 201);
    }

    /**
     * Revoquer un perimetre de moderation.
     */
    public function destroy(Request $request, ModeratorScope $moderatorScope): JsonResponse
    {
        $this->authorize('assign', ModeratorScope::class);

        $this->moderators->revoke($moderatorScope, $request->user());

        return ApiResponse::data(null, 204);
    }

    /**
     * Retrouve un compte par son email academique ou son email de connexion.
     */
    private function findUserByEmail(string $email): User
    {
        $normalized = trim($email);

        $user = User::query()
            ->where('academic_email', $normalized)
            ->orWhere('email', $normalized)
            ->first();

        if ($user === null) {
            throw BusinessRuleException::make(sprintf('Aucun compte ne correspond à « %s ».', $email));
        }

        return $user;
    }
}
