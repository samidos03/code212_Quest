<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ManagedUserResource;
use App\Models\User;
use App\Services\AuditLogger;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * Gestion de l'ensemble des comptes utilisateurs.
 */
class ManagedUserAdminController extends Controller
{
    public function __construct(
        private readonly AuditLogger $audit,
    ) {
    }

    /**
     * Annuaire des comptes (paginé, filtrable).
     */
    public function index(Request $request): JsonResponse
    {
        $this->authorize('manageStudents', $request->user());

        $users = User::query()
            ->with(['roles', 'moderatorScope'])
            ->when($request->filled('recherche'), static function ($query) use ($request): void {
                $term = (string) $request->string('recherche');
                $query->where(function ($sub) use ($term): void {
                    $sub->where('name', 'ilike', '%'.$term.'%')
                        ->orWhere('email', 'ilike', '%'.$term.'%')
                        ->orWhere('academic_email', 'ilike', '%'.$term.'%')
                        ->orWhere('filiere', 'ilike', '%'.$term.'%')
                        ->orWhere('etablissement', 'ilike', '%'.$term.'%');
                });
            })
            ->when($request->filled('etablissement'), static fn ($q) => $q->where('etablissement', $request->string('etablissement')))
            ->when($request->filled('role'), static fn ($q) => $q->whereHas(
                'roles',
                static fn ($sub) => $sub->where('roles.code', $request->string('role')),
            ))
            ->orderBy('name')
            ->paginate((int) $request->integer('limite', 50));

        return ApiResponse::paginated($users, ManagedUserResource::collection($users->getCollection()));
    }

    /**
     * Changer le statut d'un compte (decision manuelle, jamais automatique).
     */
    public function updateStatus(Request $request, User $user): JsonResponse
    {
        $this->authorize('manageStudents', $request->user());

        $payload = $request->validate([
            'statut' => ['required', 'string', Rule::in(['Actif', 'En attente', 'Inactif', 'Suspendu'])],
            'justification' => ['nullable', 'string', 'max:500'],
        ]);

        $previous = $user->roles;
        $target = (string) $payload['statut'];

        // « Suspendu » retire les acces d'equipe ; « Actif » les restaure.
        if ($target === 'Suspendu') {
            $user->roles = array_values(array_filter(
                $previous,
                static fn (string $role): bool => $role !== 'admin',
            ));
            $user->save();
        } elseif ($target === 'Actif' && ! in_array('admin', $previous, true)) {
            // Les roles applicatifs sont geres via les nominations : rien a restaurer ici.
            $user->touch();
        }

        $this->audit->log(
            $request->user(),
            'admin.user_status_updated',
            'user',
            $user->getKey(),
            $payload['justification'] ?? null,
            ['statut' => $target],
        );

        return ApiResponse::resource(new ManagedUserResource($user->load(['roles', 'moderatorScope'])));
    }
}
