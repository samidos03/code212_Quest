<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Services\RoleService;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Restreint l'acces a une permission applicative (alias : `permission`).
 *
 * Le controle s'appuie sur le profil effectif de l'utilisateur : union des
 * permissions des roles actifs et non expires (les administrateurs ont un
 * acces total).
 */
class EnsureUserHasPermission
{
    public function __construct(
        private readonly RoleService $roles,
    ) {
    }

    public function handle(Request $request, Closure $next, string ...$permissions): Response
    {
        $user = $request->user();

        if ($user === null) {
            return response()->json([
                'message' => 'Authentification requise.',
                'errors' => (object) [],
            ], 401);
        }

        foreach ($permissions as $permission) {
            if ($this->roles->userCan($user, $permission)) {
                return $next($request);
            }
        }

        return response()->json([
            'message' => 'Accès refusé : permission insuffisante.',
            'errors' => (object) [],
        ], 403);
    }
}
