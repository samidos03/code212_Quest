<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Support\PermissionCatalog;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Creation d'un role personnalise.
 */
class StoreRoleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'nom' => ['required', 'string', 'max:120'],
            'description' => ['nullable', 'string', 'max:500'],
            'couleur' => ['nullable', 'string', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'permissions' => ['required', 'array', 'min:1', 'max:60'],
            'permissions.*' => ['required', 'string', Rule::in(PermissionCatalog::keys())],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'permissions.required' => 'Sélectionnez au moins une permission.',
            'permissions.*.in' => 'Permission inconnue du catalogue.',
            'couleur.regex' => 'La couleur doit être un code hexadécimal (#6701e6).',
        ];
    }
}
