<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * Nomination d'un membre de l'equipe : on designate la personne par son email.
 */
class AssignRoleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'max:160'],
            'role_code' => ['required', 'string', 'max:64'],
            'justification' => ['nullable', 'string', 'max:500'],
            'expire_le' => ['nullable', 'date', 'after:now'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'email.required' => 'Saisissez l’email de la personne à nommer.',
            'role_code.required' => 'Choisissez le rôle à attribuer.',
            'expire_le.after' => 'L’échéance doit être postérieure à aujourd’hui.',
        ];
    }
}
