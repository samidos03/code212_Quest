<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Support\PermissionCatalog;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Nomination d'un moderateur de La Forge et definition de son perimetre.
 */
class AssignModeratorRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'max:160'],
            'sections' => ['required', 'array', 'min:1', 'max:10'],
            'sections.*' => ['required', 'string', Rule::in(array_column(PermissionCatalog::forgeSections(), 'slug'))],
            'note' => ['nullable', 'string', 'max:500'],
            'expire_le' => ['nullable', 'date', 'after:now'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'sections.required' => 'Sélectionnez au moins une rubrique à modérer.',
            'sections.*.in' => 'Rubrique inconnue.',
        ];
    }
}
