<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ModeratorScope;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin ModeratorScope
 */
class ModeratorScopeResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'user_name' => $this->whenLoaded('user', fn () => $this->user?->name),
            'user_email' => $this->whenLoaded('user', fn () => $this->user?->academic_email ?? $this->user?->email),
            'sections' => $this->sections ?? [],
            'granted_by' => $this->whenLoaded('granter', fn () => $this->granter?->name),
            'granted_at' => $this->created_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'note' => $this->scope_note,
            'revoked_at' => $this->revoked_at?->toIso8601String(),
            'active' => $this->isActive(),
        ];
    }
}
