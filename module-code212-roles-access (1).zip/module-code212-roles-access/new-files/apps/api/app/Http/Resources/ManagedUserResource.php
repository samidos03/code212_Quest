<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Compte utilisateur tel que vu par la Direction.
 *
 * @mixin User
 */
class ManagedUserResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $roleCodes = $this->resource->roleCodes();
        $scope = $this->resource->moderatorScope;

        return [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'full_name' => $this->name,
            'email' => $this->email,
            'academic_email' => $this->academic_email,
            'student_code' => $this->uca_matricule,
            'program' => $this->filiere,
            'school' => $this->etablissement,
            'level' => $this->level_no,
            'xp' => $this->xp_total,
            'quests_completed' => $this->questEnrollments()->whereNotNull('completed_at')->count(),
            'status' => $this->status(),
            'joined_at' => $this->created_at?->toIso8601String(),
            'last_active_at' => $this->last_login_at?->toIso8601String(),
            'role_codes' => $roleCodes,
            'role_names' => $this->resource->roles()
                ->whereIn('roles.code', $roleCodes)
                ->pluck('roles.name')
                ->values()
                ->all(),
            'is_moderator' => $scope !== null && $scope->isActive(),
            'moderated_sections' => $scope !== null && $scope->isActive() ? ($scope->sections ?? []) : [],
        ];
    }

    /**
     * Statut du compte (jamais applique automatiquement : decision manuelle).
     */
    private function status(): string
    {
        if ($this->resource->roles()->where('roles.code', 'admin')->exists()) {
            return 'Actif';
        }

        if ($this->resource->last_login_at === null) {
            return 'En attente';
        }

        if ($this->resource->last_login_at->diffInDays(Carbon::now()) > 30) {
            return 'Inactif';
        }

        return 'Actif';
    }
}
