<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\RoleAssignment;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin RoleAssignment
 */
class RoleAssignmentResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'user_name' => $this->whenLoaded('user', fn () => $this->user?->name),
            'user_email' => $this->whenLoaded('user', fn () => $this->user?->academic_email ?? $this->user?->email),
            'role_id' => $this->role_id,
            'role_code' => $this->whenLoaded('role', fn () => $this->role?->code),
            'role_name' => $this->whenLoaded('role', fn () => $this->role?->name),
            'role_color' => $this->whenLoaded('role', fn () => $this->role?->color),
            'granted_by' => $this->whenLoaded('granter', fn () => $this->granter?->name),
            'granted_at' => $this->created_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'reason' => $this->reason,
        ];
    }
}
