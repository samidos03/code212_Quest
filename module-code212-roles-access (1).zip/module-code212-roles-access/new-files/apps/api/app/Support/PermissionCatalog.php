<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Catalogue des permissions Code212 Quest.
 *
 * Source de verite unique du cote API : 9 modules metier, 42 permissions
 * atomiques. Les cles sont volontairement stables car elles sont consommees
 * par le front (apps/web/src/lib/permissions.ts) et stockees en base dans
 * `permissions.key` puis `role_permissions.permission_key`.
 */
final class PermissionCatalog
{
    /**
     * Modules metier et permissions associees.
     *
     * @return array<string, array{label: string, description: string, permissions: array<string, array{label: string, description: string}>}>
     */
    public static function modules(): array
    {
        return [
            'moderation' => [
                'label' => 'Modération',
                'description' => 'Traitement des signalements, nettoyage des contenus et encadrement des modérateurs.',
                'permissions' => [
                    'moderation.reports.read' => [
                        'label' => 'Consulter les signalements',
                        'description' => 'Voir la file de modération et son historique.',
                    ],
                    'moderation.content.hide' => [
                        'label' => 'Masquer un contenu',
                        'description' => 'Retirer un fil ou une réponse de la Forge.',
                    ],
                    'moderation.ban.manage' => [
                        'label' => 'Gérer les exclusions',
                        'description' => 'Activer ou lever une exclusion temporaire d’un compte.',
                    ],
                    'moderation.moderators.manage' => [
                        'label' => 'Gérer les modérateurs',
                        'description' => 'Nommer et révoquer les modérateurs par rubrique.',
                    ],
                ],
            ],
            'quests' => [
                'label' => 'Quêtes & supervision',
                'description' => 'Concevoir les quêtes, les publier et superviser les livrables des étudiants.',
                'permissions' => [
                    'quests.read' => [
                        'label' => 'Consulter les quêtes',
                        'description' => 'Voir le catalogue et le contenu des quêtes.',
                    ],
                    'quests.create' => [
                        'label' => 'Créer une quête',
                        'description' => 'Rédiger une quête et ses étapes.',
                    ],
                    'quests.publish' => [
                        'label' => 'Publier une quête',
                        'description' => 'Rendre une quête visible par les apprenants.',
                    ],
                    'quests.update' => [
                        'label' => 'Modifier une quête',
                        'description' => 'Éditer une quête déjà publiée.',
                    ],
                    'quests.delete' => [
                        'label' => 'Supprimer une quête',
                        'description' => 'Retirer définitivement une quête du catalogue.',
                    ],
                    'quests.submissions.validate' => [
                        'label' => 'Valider les livrables',
                        'description' => 'Noter et valider les travaux soumis.',
                    ],
                ],
            ],
            'paths' => [
                'label' => 'Parcours de compétences',
                'description' => 'Structurer les parcours, leur contenu et leur ouverture aux étudiants.',
                'permissions' => [
                    'paths.read' => [
                        'label' => 'Consulter les parcours',
                        'description' => 'Voir les parcours et leur progression.',
                    ],
                    'paths.create' => [
                        'label' => 'Créer un parcours',
                        'description' => 'Composer un parcours de compétences.',
                    ],
                    'paths.update' => [
                        'label' => 'Modifier un parcours',
                        'description' => 'Éditer les étapes et les ressources d’un parcours.',
                    ],
                    'paths.publish' => [
                        'label' => 'Publier un parcours',
                        'description' => 'Ouvrir un parcours aux apprenants.',
                    ],
                ],
            ],
            'missions' => [
                'label' => 'Missions',
                'description' => 'Créer, lancer et clôturer les missions périodiques de la plateforme.',
                'permissions' => [
                    'missions.read' => [
                        'label' => 'Consulter les missions',
                        'description' => 'Voir les missions et le taux de participation.',
                    ],
                    'missions.create' => [
                        'label' => 'Créer une mission',
                        'description' => 'Rédiger une mission et sa récompense.',
                    ],
                    'missions.launch' => [
                        'label' => 'Lancer une mission',
                        'description' => 'Activer une mission sur une durée donnée.',
                    ],
                    'missions.close' => [
                        'label' => 'Clôturer une mission',
                        'description' => 'Arrêter une mission en cours et attribuer les gains.',
                    ],
                ],
            ],
            'certifications' => [
                'label' => 'Certifications',
                'description' => 'Définir, délivrer et révoquer les certifications CODE212.',
                'permissions' => [
                    'certifications.read' => [
                        'label' => 'Consulter les certifications',
                        'description' => 'Voir les certifications et les critères.',
                    ],
                    'certifications.create' => [
                        'label' => 'Créer une certification',
                        'description' => 'Définir un référentiel de certification.',
                    ],
                    'certifications.criteria.manage' => [
                        'label' => 'Gérer les critères',
                        'description' => 'Ajouter ou retirer des critères de validation.',
                    ],
                    'certifications.issue' => [
                        'label' => 'Délivrer une certification',
                        'description' => 'Décerner la certification à un apprenant.',
                    ],
                    'certifications.revoke' => [
                        'label' => 'Révoquer une certification',
                        'description' => 'Retirer une certification délivrée.',
                    ],
                ],
            ],
            'arena' => [
                'label' => 'Arène & compétitions',
                'description' => 'Organiser les défis chronométrés, les duels, les hackathons et la Coding League.',
                'permissions' => [
                    'arena.read' => [
                        'label' => 'Consulter l’Arène',
                        'description' => 'Voir les défis et les classements.',
                    ],
                    'arena.challenges.create' => [
                        'label' => 'Créer un défi',
                        'description' => 'Paramétrer un défi chronométré, duel ou hackathon.',
                    ],
                    'arena.challenges.open' => [
                        'label' => 'Ouvrir les inscriptions',
                        'description' => 'Publier un défi et ouvrir les inscriptions.',
                    ],
                    'arena.challenges.arbitrate' => [
                        'label' => 'Arbitrer un défi',
                        'description' => 'Trancher les litiges et valider les résultats.',
                    ],
                    'arena.challenges.close' => [
                        'label' => 'Clôturer un défi',
                        'description' => 'Fermer un défi et figer le classement.',
                    ],
                    'arena.coding_league.manage' => [
                        'label' => 'Piloter la Coding League',
                        'description' => 'Organiser les étapes, équipes et calendriers de la ligue.',
                    ],
                ],
            ],
            'placement' => [
                'label' => 'Banque de questions',
                'description' => 'Préparer, relire et publier les quiz de positionnement.',
                'permissions' => [
                    'placement.questions.read' => [
                        'label' => 'Consulter la banque',
                        'description' => 'Voir les questions et leur statut.',
                    ],
                    'placement.questions.create' => [
                        'label' => 'Rédiger une question',
                        'description' => 'Ajouter une question et ses explications.',
                    ],
                    'placement.questions.review' => [
                        'label' => 'Relire une question',
                        'description' => 'Vérifier la formulation et la réponse correcte.',
                    ],
                    'placement.questions.publish' => [
                        'label' => 'Publier dans le test',
                        'description' => 'Rendre une question disponible pour le positionnement.',
                    ],
                ],
            ],
            'mentorship' => [
                'label' => 'Mentorat',
                'description' => 'Suivre les apprenants, organiser les sessions et donner du feedback.',
                'permissions' => [
                    'mentorship.learners.read' => [
                        'label' => 'Consulter les apprenants',
                        'description' => 'Voir la progression des étudiants suivis.',
                    ],
                    'mentorship.sessions.manage' => [
                        'label' => 'Organiser les sessions',
                        'description' => 'Planifier les sessions de mentorat.',
                    ],
                    'mentorship.feedback.write' => [
                        'label' => 'Rédiger du feedback',
                        'description' => 'Commenter les livrables et progressions.',
                    ],
                ],
            ],
            'roles' => [
                'label' => 'Rôles & accès',
                'description' => 'Administrer les rôles, les permissions et les affectations de l’équipe.',
                'permissions' => [
                    'roles.read' => [
                        'label' => 'Consulter les rôles',
                        'description' => 'Voir les rôles et leurs permissions.',
                    ],
                    'roles.create' => [
                        'label' => 'Créer un rôle',
                        'description' => 'Créer un rôle personnalisé.',
                    ],
                    'roles.update' => [
                        'label' => 'Modifier un rôle',
                        'description' => 'Modifier les permissions d’un rôle.',
                    ],
                    'roles.revoke' => [
                        'label' => 'Révoquer un rôle',
                        'description' => 'Suspendre un rôle et ses accès.',
                    ],
                    'roles.delete' => [
                        'label' => 'Supprimer un rôle',
                        'description' => 'Supprimer un rôle personnalisé sans membre.',
                    ],
                    'roles.assign' => [
                        'label' => 'Affecter un rôle',
                        'description' => 'Nommer ou retirer un membre de l’équipe.',
                    ],
                ],
            ],
        ];
    }

    /**
     * Toutes les cles de permissions, a plat.
     *
     * @return list<string>
     */
    public static function keys(): array
    {
        $keys = [];

        foreach (self::modules() as $module) {
            foreach (array_keys($module['permissions']) as $key) {
                $keys[] = $key;
            }
        }

        return $keys;
    }

    /**
     * Catalogue serialise pour l'API (un module par objet).
     *
     * @return list<array<string, mixed>>
     */
    public static function toArray(): array
    {
        $out = [];
        $order = 0;

        foreach (self::modules() as $code => $module) {
            $permissions = [];

            foreach ($module['permissions'] as $key => $permission) {
                $permissions[] = [
                    'key' => $key,
                    'label' => $permission['label'],
                    'description' => $permission['description'],
                ];
            }

            $out[] = [
                'code' => $code,
                'label' => $module['label'],
                'description' => $module['description'],
                'order' => $order++,
                'permissions' => $permissions,
            ];
        }

        return $out;
    }

    /**
     * Le code existe-t-il dans le catalogue ?
     */
    public static function isValid(string $key): bool
    {
        return in_array($key, self::keys(), true);
    }

    /**
     * Roles systeme livres avec la plateforme (non supprimables).
     *
     * `admin` est traite a part : acces total, aucune ligne en base.
     *
     * @return array<string, array{name: string, description: string, color: string, permissions: list<string>}>
     */
    public static function systemRoles(): array
    {
        return [
            'admin' => [
                'name' => 'Administrateur',
                'description' => 'Accès complet à la plateforme, y compris la gestion des rôles et des exclusions.',
                'color' => '#6701e6',
                'permissions' => self::keys(),
            ],
            'quest_creator' => [
                'name' => 'Créateur de quêtes',
                'description' => 'Conçoit des quêtes et des missions, et supervise les parcours de compétences.',
                'color' => '#c5027f',
                'permissions' => [
                    'quests.read', 'quests.create', 'quests.publish', 'quests.update', 'quests.delete', 'quests.submissions.validate',
                    'missions.read', 'missions.create', 'missions.launch', 'missions.close',
                    'paths.create', 'paths.update',
                    'roles.read',
                ],
            ],
            'evaluator' => [
                'name' => 'Évaluateur',
                'description' => 'Examine les travaux soumis par les étudiants et rend un avis motivé.',
                'color' => '#00b8d4',
                'permissions' => [
                    'quests.read', 'quests.submissions.validate',
                    'missions.read', 'paths.read', 'certifications.read',
                    'roles.read',
                ],
            ],
            'coding_league' => [
                'name' => 'Responsable Coding League',
                'description' => 'Organise les compétitions, les duels, les hackathons et le calendrier de la ligue.',
                'color' => '#f59e0b',
                'permissions' => [
                    'arena.read', 'arena.challenges.create', 'arena.challenges.open', 'arena.challenges.arbitrate',
                    'arena.challenges.close', 'arena.coding_league.manage',
                    'quests.read', 'missions.read', 'placement.questions.read',
                    'roles.read',
                ],
            ],
            'question_bank' => [
                'name' => 'Gestionnaire de la banque de questions',
                'description' => 'Prépare, relit et valide les quiz de positionnement des nouveaux arrivants.',
                'color' => '#10b981',
                'permissions' => [
                    'placement.questions.read', 'placement.questions.create', 'placement.questions.review', 'placement.questions.publish',
                    'quests.read', 'roles.read',
                ],
            ],
            'mentor' => [
                'name' => 'Mentor',
                'description' => 'Accompagne les étudiants dans leur progression et anime les sessions de mentorat.',
                'color' => '#8b5cf6',
                'permissions' => [
                    'quests.read', 'quests.submissions.validate', 'missions.read', 'paths.read', 'placement.questions.read',
                    'mentorship.learners.read', 'mentorship.sessions.manage', 'mentorship.feedback.write',
                    'roles.read',
                ],
            ],
        ];
    }

    /**
     * Roles dont le cumul est un conflit d'interets.
     *
     * @return list<array{0: string, 1: string}>
     */
    public static function conflictingPairs(): array
    {
        return [
            ['admin', 'evaluator'],
            ['admin', 'quest_creator'],
            ['quest_creator', 'evaluator'],
        ];
    }

    /**
     * Rubriques de La Forge pouvant etre confiees a un moderateur.
     *
     * @return list<array{slug: string, label: string, description: string}>
     */
    public static function forgeSections(): array
    {
        return [
            ['slug' => 'entraide', 'label' => 'Entraide', 'description' => 'Questions techniques, blocages, aide entre étudiants.'],
            ['slug' => 'projets', 'label' => 'Projets', 'description' => 'Présentations et dépôts de projets étudiants.'],
            ['slug' => 'coding-league', 'label' => 'Coding League', 'description' => 'Discussions des compétitions et équipes.'],
            ['slug' => 'annonces', 'label' => 'Annonces', 'description' => 'Informations officielles de la Forge.'],
            ['slug' => 'cafe', 'label' => 'Café de la Forge', 'description' => 'Discussion libre, hors sujets techniques.'],
        ];
    }

    /**
     * Un couple de codes de roles est-il en conflit ?
     *
     * @param list<string> $roleCodes
     */
    public static function hasConflict(string $candidate, array $roleCodes): bool
    {
        foreach (self::conflictingPairs() as [$a, $b]) {
            if ($candidate === $a && in_array($b, $roleCodes, true)) {
                return true;
            }

            if ($candidate === $b && in_array($a, $roleCodes, true)) {
                return true;
            }
        }

        return false;
    }
}
