<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * Permission atomique du catalogue (module metier + cle stable).
 *
 * @property int $id
 * @property string $module
 * @property string $key
 * @property string $label
 * @property string $description
 * @property int $group_order
 */
class Permission extends Model
{
    use HasFactory;

    protected $fillable = [
        'module',
        'key',
        'label',
        'description',
        'group_order',
    ];

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_permissions', 'permission_id', 'role_id');
    }
}
