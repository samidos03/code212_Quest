<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Role applicatif porte par un ou plusieurs comptes.
 *
 * @property int $id
 * @property string $code
 * @property string $name
 * @property string $description
 * @property string $color
 * @property bool $is_system
 * @property string $scope
 * @property int|null $created_by
 * @property \Illuminate\Support\Carbon|null $revoked_at
 */
class Role extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'description',
        'color',
        'is_system',
        'scope',
        'created_by',
        'revoked_at',
    ];

    protected function casts(): array
    {
        return [
            'is_system' => 'boolean',
            'revoked_at' => 'datetime',
        ];
    }

    // ---------------------------------------------------------------- Relations

    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(
            Permission::class,
            'role_permissions',
            'role_id',
            'permission_key',
            'id',
            'key',
        );
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(RoleAssignment::class);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'role_assignments')
            ->withPivot(['granted_by', 'expires_at', 'reason'])
            ->withTimestamps();
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // ------------------------------------------------------------------ Helpers

    /**
     * Le role est-il actuellement actif (non revoque) ?
     */
    public function isActive(): bool
    {
        return $this->revoked_at === null;
    }

    /**
     * Le role donne-t-il un acces global (hors perimetre Forge) ?
     */
    public function isGlobalScope(): bool
    {
        return $this->scope !== 'forge';
    }
}
