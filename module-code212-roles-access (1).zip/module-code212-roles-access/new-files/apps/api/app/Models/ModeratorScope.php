<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Perimetre de moderation d'un compte sur les rubriques de La Forge.
 *
 * @property int $id
 * @property int $user_id
 * @property list<string> $sections
 * @property int|null $granted_by
 * @property \Illuminate\Support\Carbon|null $expires_at
 * @property string $scope_note
 * @property \Illuminate\Support\Carbon|null $revoked_at
 */
class ModeratorScope extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'sections',
        'granted_by',
        'expires_at',
        'scope_note',
        'revoked_at',
    ];

    protected function casts(): array
    {
        return [
            'sections' => 'array',
            'expires_at' => 'datetime',
            'revoked_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function granter(): BelongsTo
    {
        return $this->belongsTo(User::class, 'granted_by');
    }

    /**
     * Le mandat est-il encore valable ?
     */
    public function isActive(): bool
    {
        if ($this->revoked_at !== null) {
            return false;
        }

        return $this->expires_at === null || $this->expires_at->isFuture();
    }
}
