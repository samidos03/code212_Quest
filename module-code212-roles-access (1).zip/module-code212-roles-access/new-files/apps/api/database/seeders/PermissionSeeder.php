<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Permission;
use App\Support\PermissionCatalog;
use Illuminate\Database\Seeder;

/**
 * Catalogue des permissions (9 modules, 42 droits atomiques).
 */
class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        foreach (PermissionCatalog::toArray() as $order => $module) {
            foreach ($module['permissions'] as $position => $permission) {
                Permission::query()->updateOrCreate(
                    ['key' => $permission['key']],
                    [
                        'module' => $module['code'],
                        'label' => $permission['label'],
                        'description' => $permission['description'],
                        'group_order' => ($order * 100) + $position,
                    ],
                );
            }
        }
    }
}
