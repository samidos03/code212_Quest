<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use App\Support\PermissionCatalog;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Roles systeme et roles personnalises d'exemple.
 *
 * `admin` n'est pas materialise : il donne un acces total et se detecte via
 * le role applicatif `admin` porte par `users.roles`.
 */
class SystemRoleSeeder extends Seeder
{
    public function run(): void
    {
        foreach (PermissionCatalog::systemRoles() as $code => $definition) {
            if ($code === 'admin') {
                continue;
            }

            $role = Role::query()->updateOrCreate(
                ['code' => $code],
                [
                    'name' => $definition['name'],
                    'description' => $definition['description'],
                    'color' => $definition['color'],
                    'is_system' => true,
                    'scope' => 'global',
                ],
            );

            $this->syncPermissions($role, $definition['permissions']);
        }

        // Role de perimetre : la moderation se joue par rubrique de La Forge.
        $moderator = Role::query()->updateOrCreate(
            ['code' => 'moderator'],
            [
                'name' => 'Modérateur (La Forge)',
                'description' => 'Périmètre de modération par rubrique. Aucun accès global : la portée est limitée aux sections confiées.',
                'color' => '#64748b',
                'is_system' => true,
                'scope' => 'forge',
            ],
        );

        $this->syncPermissions($moderator, []);

        // Deux roles personnalises d'exemple, conformes a une Direction en cours de cadrage.
        $examples = [
            [
                'code' => 'referent_data',
                'name' => 'Référent Data & IA',
                'description' => 'Pilote le parcours Data et IA, prépare les quiz de positionnement et encadre les mentors.',
                'color' => '#00b8d4',
                'permissions' => [
                    'quests.read', 'quests.create', 'quests.publish', 'quests.update', 'quests.submissions.validate',
                    'placement.questions.read', 'placement.questions.create', 'placement.questions.review', 'placement.questions.publish',
                    'mentorship.learners.read', 'mentorship.sessions.manage', 'mentorship.feedback.write',
                ],
            ],
            [
                'code' => 'ambassador_forge',
                'name' => 'Ambassadeur de la Forge',
                'description' => 'Relève la communauté : premier rempart de la modération, relais des annonces officielles.',
                'color' => '#f59e0b',
                'permissions' => [
                    'moderation.reports.read',
                    'quests.read', 'paths.read', 'arena.read', 'missions.read',
                ],
            ],
        ];

        foreach ($examples as $example) {
            $role = Role::query()->updateOrCreate(
                ['code' => $example['code']],
                [
                    'name' => $example['name'],
                    'description' => $example['description'],
                    'color' => $example['color'],
                    'is_system' => false,
                    'scope' => 'global',
                ],
            );

            $this->syncPermissions($role, $example['permissions']);
        }
    }

    /**
     * Figure les permissions d'un role.
     *
     * @param list<string> $permissions
     */
    private function syncPermissions(Role $role, array $permissions): void
    {
        DB::table('role_permissions')->where('role_id', $role->getKey())->delete();

        if ($permissions === []) {
            return;
        }

        $known = Permission::query()->whereIn('key', $permissions)->pluck('key')->all();

        $rows = [];
        $now = now();

        foreach (array_intersect($permissions, $known) as $key) {
            $rows[] = [
                'role_id' => $role->getKey(),
                'permission_key' => $key,
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        DB::table('role_permissions')->insert($rows);
    }
}
