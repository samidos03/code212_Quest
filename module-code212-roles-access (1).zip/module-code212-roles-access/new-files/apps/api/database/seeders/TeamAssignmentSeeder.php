<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\ModeratorScope;
use App\Models\Role;
use App\Models\RoleAssignment;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

/**
 * Equipe de demonstration : nominations de roles et perimetres de moderation.
 */
class TeamAssignmentSeeder extends Seeder
{
    public function run(): void
    {
        $director = User::query()->where('email', 'admin@code212.ma')->first()
            ?? User::query()->where('email', 'mehdi.alaoui@uca.ma')->first();

        if ($director === null) {
            return;
        }

        $assignments = [
            ['amina.bouzid@uca.ma', 'mentor', 'Mentor référent du parcours Génie Logiciel.', null],
            ['youssef.elamine@uca.ma', 'coding_league', 'Pilote la Coding League.', null],
            ['salma.nadir@uca.ma', 'evaluator', 'Évalue les livrables du module Réseaux.', null],
            ['karim.tazi@uca.ma', 'quest_creator', 'Conçoit les quêtes d’introduction.', null],
            ['hind.lamrani@uca.ma', 'question_bank', 'Prépare les quiz de positionnement.', null],
        ];

        foreach ($assignments as [$email, $roleCode, $reason, $expiresAt]) {
            $user = User::query()->where('email', $email)->first();
            $role = Role::query()->where('code', $roleCode)->first();

            if ($user === null || $role === null) {
                continue;
            }

            RoleAssignment::query()->updateOrCreate(
                ['user_id' => $user->getKey(), 'role_id' => $role->getKey()],
                [
                    'granted_by' => $director->getKey(),
                    'expires_at' => $expiresAt,
                    'reason' => $reason,
                ],
            );
        }

        $scopes = [
            ['amina.bouzid@uca.ma', ['entraide', 'cafe'], 'Relais des questions d’entraide.'],
            ['youssef.elamine@uca.ma', ['coding-league', 'projets'], 'Anime les discussions Coding League.'],
            ['hind.lamrani@uca.ma', ['entraide'], 'Relais des questions bloquées.'],
        ];

        foreach ($scopes as [$email, $sections, $note]) {
            $user = User::query()->where('email', $email)->first();

            if ($user === null) {
                continue;
            }

            ModeratorScope::query()->updateOrCreate(
                ['user_id' => $user->getKey()],
                [
                    'sections' => $sections,
                    'granted_by' => $director->getKey(),
                    'expires_at' => Carbon::now()->addMonths(6),
                    'scope_note' => $note,
                ],
            );
        }
    }
}
