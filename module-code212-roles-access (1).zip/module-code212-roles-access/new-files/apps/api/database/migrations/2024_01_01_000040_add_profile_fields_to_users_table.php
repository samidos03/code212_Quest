<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Identite complete des comptes : prenom, nom, etablissement, email academique.
 *
 * `email` reste l'identifiant de connexion ; `academic_email` porte
 * l'adresse institutionnelle UCA (prenom.nom@uca.ac.ma).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->string('first_name', 80)->nullable()->after('name');
            $table->string('last_name', 80)->nullable()->after('first_name');
            $table->string('etablissement', 120)->nullable()->after('filiere');
            $table->string('academic_email', 160)->nullable()->unique()->after('email');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropColumn(['first_name', 'last_name', 'etablissement', 'academic_email']);
        });
    }
};
