<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Catalogue des permissions (source : App\Support\PermissionCatalog).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table): void {
            $table->id();
            $table->string('module', 48);
            $table->string('key', 96)->unique();
            $table->string('label', 160);
            $table->string('description', 500)->default('');
            $table->unsignedSmallInteger('group_order')->default(0);
            $table->timestamps();

            $table->index('module');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};
