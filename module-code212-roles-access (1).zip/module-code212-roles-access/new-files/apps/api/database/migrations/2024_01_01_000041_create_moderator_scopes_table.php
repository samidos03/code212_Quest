<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Perimetre de moderation d'un compte sur La Forge.
 *
 * Un compte = une ligne, portant la liste des rubriques (`sections`) qui lui
 * sont confiees, la date d'expiration du mandat et la note de cadrage.
 *
 * La table historique `forge_moderator_assignments` (une ligne par couple
 * categorie/utilisateur) reste en place : elle continue de porter la
 * delegation de moderation technique.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('moderator_scopes', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->jsonb('sections')->default(DB::raw("'[]'::jsonb"));
            $table->foreignId('granted_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('expires_at')->nullable();
            $table->string('scope_note', 500)->default('');
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->unique('user_id');
            $table->index('revoked_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('moderator_scopes');
    }
};
