<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Roles applicatifs : roles systeme (is_system = true) et roles personnalises.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table): void {
            $table->id();
            $table->string('code', 64)->unique();
            $table->string('name', 120);
            $table->string('description', 500)->default('');
            $table->string('color', 16)->default('#6701e6');
            $table->boolean('is_system')->default(false);
            $table->string('scope', 16)->default('global');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->index('is_system');
            $table->index('revoked_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};
