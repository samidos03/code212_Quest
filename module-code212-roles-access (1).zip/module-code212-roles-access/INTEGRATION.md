# Intégration du module « Rôles & accès »

Guide destiné au stagiaire qui intègre le module dans le dépôt **Code212 Quest**.

---

## 1. Vue d'ensemble

Le module touche **2 zones** de l'application :

| Zone | Nature | Volume |
|---|---|---|
| `apps/web` (front) | 4 fichiers créés, 7 modifiés | ~2 900 lignes ajoutées |
| `apps/api` (back) | 33 fichiers créés, 10 modifiés | ~4 200 lignes ajoutées |

Aucune dépendance externe ajoutée. Aucune route existante modifiée (les nouvelles routes
sont ajoutées dans des groupes séparés). Aucune table existante vidée ou altérée : une seule
migration **ajoute** des colonnes (`users.first_name`, `users.last_name`,
`users.academic_email`, `users.etablissement`).

---

## 2. Méthode d'intégration

### Option A — script (recommandé)

```bash
cd /chemin/vers/code212-quest
bash /chemin/vers/module-code212-roles-access/apply.sh
```

### Option B — manuelle

```bash
# a) Copier les 37 fichiers nouveaux
cp -r module-code212-roles-access/new-files/* .

# b) Appliquer les 11 patchs de modification, dans l'ordre
cd module-code212-roles-access/patches
for p in *.patch; do patch -p1 --forward < "$p"; done
# (les 37 fichiers a creer sont deja copies en a) ; les patchs equivalents
#  sont fournis dans patches/nouveaux-fichiers/ pour les flux `git apply`)
```

> Les patchs sont des diffs unifiés standards : ils s'appliquent avec `patch -p1`
> ou `git apply`. En cas de conflit, vérifier que le fichier cible est à sa version
> d'origine (le patch est idempotent : le rejouer sur un fichier déjà patché
> ne le modifie pas).

---

## 3. Points d'intégration fichier par fichier

### 3.1 Front — fichiers modifiés

| Fichier | Modification | Pourquoi |
|---|---|---|
| `src/types/index.ts` | **ajout** en fin de fichier : `Role`, `RoleAssignment`, `ModeratorAssignment`, `ManagedUser`, `RoleAuditEvent`, `ManagedUserStatus` | Types métier du module |
| `src/lib/permissions.ts` | **créé** | Catalogue des 9 modules / 42 permissions + rubriques de la Forge + rôles système + paires de conflits |
| `src/lib/schools.ts` | **créé** | Table des établissements UCA (FSM, FST, ENSAM, ENI, EST, ENA) |
| `src/lib/navigation.ts` | import `KeyRound` + entrée `{ label: 'Rôles & accès', to: '/admin/roles' }` dans le groupe « Pilotage » de `adminNav` | Rendre la page accessible depuis la navigation Directeur |
| `src/components/shared/permission-matrix.tsx` | **créé** | Matrice de sélection des permissions, groupée par module, réutilisable |
| `src/pages/admin/admin-roles-page.tsx` | **créé** | La page (5 onglets) |
| `src/App.tsx` | import + `<Route path="/admin/roles" element={<AdminRolesPage />} />` | Route React |
| `src/services/api.ts` | 15 méthodes de facade (`adminRoles`, `createRole`, `assignRole`, `assignModerator`…) | Point d'entrée unique : bascule front ⇄ API par `VITE_USE_MOCK` |
| `src/hooks/use-api.ts` | 15 hooks React Query (`useAdminRoles`, `useCreateRole`…) | Cache, invalidation et états de chargement |
| `src/services/mock/db.ts` | jeu de démonstration : 26 comptes, 9 rôles, 8 nominations, 4 périmètres, 8 événements de journal | Permet de travailler sur le module **sans backend** |
| `src/services/mock/server.ts` | implémentation des 15 endpoints en mode démo, avec les mêmes règles métier que l'API (catalogue validé, conflits refusés, mandat daté) | Idem |

### 3.2 API — fichiers modifiés

| Fichier | Modification |
|---|---|
| `app/Models/User.php` | import `BelongsToMany` ; `fillable` enrichi ; relations `roles()`, `roleAssignments()`, `moderatorScope()` ; helpers `roleCodes()` et `hasAppRole()` (ignorent les mandats expirés) |
| `app/Providers/AppServiceProvider.php` | enregistrement de `RolePolicy` (modèle `Role`) et `ModeratorPolicy` (modèle `ModeratorScope`) |
| `bootstrap/app.php` | alias de middleware `permission` → `EnsureUserHasPermission` |
| `routes/api.php` | 2 groupes de routes nouvelles (`admin/roles…` et `admin/moderators…`, `admin/users…`), placées **après** le groupe `admin` existant, sans le modifier |
| `database/seeders/DatabaseSeeder.php` | enregistrement de `PermissionSeeder`, `SystemRoleSeeder` (toujours) et `TeamAssignmentSeeder` (mode démo) |
| `database/seeders/DemoUserSeeder.php` ||first_name`, `last_name`, `academic_email`, `etablissement` renseignés |

### 3.3 API — fichiers créés

| Catégorie | Fichiers |
|---|---|
| Catalogue | `app/Support/PermissionCatalog.php` |
| Modèles | `app/Models/Role.php`, `Permission.php`, `RoleAssignment.php`, `ModeratorScope.php` |
| Migrations | `000036_create_roles_table`, `000037_create_permissions_table`, `000038_create_role_permissions_table`, `000039_create_role_assignments_table`, `000040_add_profile_fields_to_users_table`, `000041_create_moderator_scopes_table` |
| Services | `app/Services/RoleService.php`, `ModeratorService.php` |
| HTTP | `app/Http/Middleware/EnsureUserHasPermission.php`, 4 `FormRequest`, 4 `Resource`, 3 `Controller` |
| Policies | `app/Policies/RolePolicy.php`, `ModeratorPolicy.php` |
| Seeders | `PermissionSeeder`, `SystemRoleSeeder`, `TeamAssignmentSeeder` |
| Tests | `RoleManagementTest` (9), `RoleAssignmentTest` (8), `ModeratorAssignmentTest` (7) |

---

## 4. Modèle de données

```
users ──┬── role_assignments ──── roles ──── role_permissions ──── permissions
        │       (nominations)       │            (droits)           (catalogue)
        └── moderator_scopes ────────── rubriques de La Forge (périmètre)
```

| Table | Colonnes clés | Rôle |
|---|---|---|
| `roles` | `code` (unique), `name`, `color`, `is_system`, `scope` (`global`\|`forge`), `created_by`, `revoked_at` | Rôles système + personnalisés. `admin` **n'est pas** materialisé : accès total détecté via `users.roles` |
| `permissions` | `key` (unique), `module`, `label`, `group_order` | Catalogue figé des 42 droits |
| `role_permissions` | `role_id`, `permission_key` (FK → `permissions.key`) | Droits portés par un rôle |
| `role_assignments` | `user_id`, `role_id`, `granted_by`, `expires_at`, `reason` — unique `(user_id, role_id)` | Nominations datées |
| `moderator_scopes` | `user_id` (unique), `sections` (jsonb), `granted_by`, `expires_at`, `scope_note`, `revoked_at` | Périmètre de modération (une ligne par personne) |
| `users` | **+** `first_name`, `last_name`, `academic_email` (unique), `etablissement` | Identité complète des comptes |

---

## 5. Routes ajoutées

Protégées par le middleware `permission:<clé>` — l'accès dépend du **profil effectif**
(union des permissions des rôles actifs et non expirés), pas du seul rôle `admin`.

| Méthode | Route | Permission |
|---|---|---|
| GET | `/api/v1/admin/roles` | `roles.read` |
| GET | `/api/v1/admin/permissions` | `roles.read` |
| POST | `/api/v1/admin/roles` | `roles.create` |
| PATCH | `/api/v1/admin/roles/{id}` | `roles.update` |
| POST | `/api/v1/admin/roles/{id}/duplicate` | `roles.create` |
| POST | `/api/v1/admin/roles/{id}/revoke` | `roles.revoke` |
| DELETE | `/api/v1/admin/roles/{id}` | `roles.delete` |
| GET | `/api/v1/admin/role-assignments` | `roles.read` |
| POST | `/api/v1/admin/role-assignments` | `roles.assign` |
| DELETE | `/api/v1/admin/role-assignments/{id}` | `roles.assign` |
| GET | `/api/v1/admin/role-audit` | `roles.read` |
| GET | `/api/v1/admin/moderators` | `moderation.reports.read` |
| POST | `/api/v1/admin/moderators` | `moderation.moderators.manage` |
| DELETE | `/api/v1/admin/moderators/{id}` | `moderation.moderators.manage` |
| GET | `/api/v1/admin/users` | `moderation.reports.read` |
| PATCH | `/api/v1/admin/users/{id}/status` | `moderation.ban.manage` |

---

## 6. Checklist de recette

### Avant l'intégration — harnais de démonstration

Le dossier `demo/` permet de valider le module **seul**, avant toute intégration :

- [ ] `cd demo && npm install && npm run dev` → http://localhost:5174
- [ ] Le module s'affiche, les 5 onglets fonctionnent, aucune erreur console

### Front

- [ ] `npm run typecheck` — aucune erreur
- [ ] `npm run build` — build vert
- [ ] `/admin/roles` s'affiche et l'entrée « Rôles & accès » apparaît dans la navigation
- [ ] Les 5 onglets s'affichent sans erreur console
- [ ] Création d'un rôle personnalisé → il apparaît dans la liste et dans la matrice
- [ ] Nomination par email → la fiche de la personne s'affiche, le registre se met à jour
- [ ] Nomination d'un modérateur → les rubriques et le mandat s'affichent
- [ ] Export CSV → le fichier `comptes-code212.csv` se télécharge
- [ ] Journal → les événements s'affichent avec auteur et horodatage
- [ ] Rendu mobile 390 px : onglets défilables, tableaux scrollables

### API

- [ ] `php artisan migrate --seed` — 6 migrations + 3 seeders
- [ ] `php artisan test` — les 24 tests passent (11 nouveaux)
- [ ] `GET /api/v1/admin/roles` renvoie 9 rôles (6 système + 2 exemple + 1 périmètre)
- [ ] `GET /api/v1/admin/permissions` renvoie 9 modules et 42 permissions
- [ ] Un compte sans la permission `roles.create` reçoit bien **403** sur `POST /admin/roles`
- [ ] Le cumul `admin` + `évaluateur` est bien refusé (**422**) à l'affectation
- [ ] Une nomination expirée ne donne plus accès (vérifier `RoleService::effectivePermissions`)

### Bascule sur l'API réelle

- [ ] Passer `VITE_USE_MOCK=false` et `VITE_API_BASE_URL=…`
- [ ] Vérifier le mapping des noms de champs dans `src/services/api.ts`
  (API en français : `nom`, `couleur`, `role_code`, `sections`… ; front en anglais)
- [ ] Vérifier que `users.academic_email` est bien renseigné (sinon la nomination par email échoue)

---

## 7. Points de vigilance

1. **Le code PHP n'a pas été exécuté.** PHP et Composer étaient absents de l'environnement de
   rédaction. Le code a été relu statiquement (imports résolus, accolades équilibrées, cohérence
   des types entre front et API) mais **les tests n'ont pas été lancés**.
2. **Ordre des migrations.** `role_permissions.permission_key` référence `permissions.key` :
   `000037` doit s'exécuter avant `000038`. Les numéros de fichiers garantissent cet ordre, mais
   vérifier si une migration a été renumérotée.
3. **Concurrence sur `role_assignments`.** La contrainte unique `(user_id, role_id)` protège
   contre la double nomination ; en cas de course, l'erreur SQL remonte en 500 — à convertir en
   422 si le volume de nominations devient important.
4. **Le rôle `admin` n'est pas dans la table `roles`.** Il est détecté via `users.roles`
   (rôle applicatif historique). C'est volontaire : `admin` est un accès total, pas un rôle
   paramétrable. Si l'on souhaite l'afficher dans la matrice, l'ajouter au seeder en
   `is_system = true` **et** traiter le cas dans `RoleService::effectivePermissions()`.
5. **Deux sources de vérité sur le catalogue** : `app/Support/PermissionCatalog.php` (API) et
   `apps/web/src/lib/permissions.ts` (front). Toute évolution doit être répercutée des deux
   côtés — c'est la principale source de dérive possible.
