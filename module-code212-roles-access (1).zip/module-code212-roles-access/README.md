# Module « Rôles & accès » — Code212 Quest

Module **autonome** d'administration des rôles, des permissions et des nominations,
destiné à être intégré dans l'application **Code212 Quest** (React + TypeScript / Laravel).

> Ce dossier est un livrable d'intégration, pas une application. Il contient
> uniquement les fichiers du module et les patchs à appliquer sur l'existant.

---

## 1. Ce que fait le module

Un écran unique, `/admin/roles`, dans l'espace **Directeur · Super Admin**, articulé en 5 onglets :

| Onglet | Contenu |
|---|---|
| **Rôles & permissions** | Cartes des rôles (système / personnalisés), vue **matrice** rôles × modules, création et modification d'un rôle via une matrice de permissions atomiques, duplication, révocation, suppression |
| **Affectations** | Nomination d'un membre à partir de son email, avec fiche de la personne, justification, échéance facultative, registre des nominations |
| **Modérateurs** | Tableau des comptes (Nom & prénom, Filière, Établissement, Email académique, Rôle & rubriques) et définition du **périmètre de modération** par rubrique de La Forge |
| **Comptes utilisateurs** | Annuaire complet, filtres (statut / rôle / établissement), export CSV, suspension et réactivation manuelles |
| **Journal** | Traçabilité des créations, modifications, révocations, nominations et périmètres |

### Modèle de droits

**9 modules, 42 permissions atomiques** :

`moderation` · `quests` · `paths` · `missions` · `certifications` · `arena` ·
`placement` (banque de questions) · `mentorship` · `roles` (accès & gouvernance)

**6 rôles système** (verrouillés, non supprimables) :

`Administrateur` · `Créateur de quêtes` · `Évaluateur` · `Responsable Coding League` ·
`Gestionnaire de la banque de questions` · `Mentor`

+ 1 rôle **à périmètre** : `Modérateur (La Forge)` — aucun accès global, l'autorité est
bornée aux rubriques confiées.

### Règles de gouvernance implémentées

- **Rôles système immuables** : pour les faire varier, on duplique le rôle.
- **Droits atomiques** : une permission hors catalogue est refusée à la création.
- **Mandat daté** : une nomination peut expirer ; l'accès cesse sans intervention.
- **Séparation des pouvoirs** : le cumul `admin` + `évaluateur`, `admin` + `créateur de quêtes`
  ou `créateur de quêtes` + `évaluateur` est **refusé** à l'affectation.
- **Un administrateur n'a pas de périmètre de modération** : son accès est déjà global.
- **Aucune sanction automatique** : la suspension d'un compte est une décision manuelle,
  tracée dans le journal d'audit.
- **Traçabilité** : chaque mutation est journalisée (auteur, cible, justification).

---

## 2. Contenu du livrable

```
module-code212-roles-access/
├── README.md              ← ce document
├── INTEGRATION.md         ← procédure d'intégration détaillée (à lire en premier)
├── apply.sh               ← application en une commande
├── demo/                  ← harnais de démonstration autonome (à lancer seul)
├── new-files/             ← 37 fichiers À COPIER tels quels
│   ├── web/src/…          (4 fichiers front)
│   └── api/…              (33 fichiers API)
└── patches/               ← patchs unifiés pour les fichiers EXISTANTS
    ├── 01-web-types.patch              (types métier)
    ├── 02-web-navigation.patch         (entrée de menu)
    ├── 03-web-routing.patch            (route React)
    ├── 04-web-api-facade.patch         (facade API + hooks)
    ├── 05-web-mock-data.patch          (jeu de données de démonstration)
    ├── 06-api-model-user.patch         (relations + helpers du modèle User)
    ├── 07-api-provider.patch           (enregistrement des policies)
    ├── 08-api-bootstrap.patch          (alias de middleware)
    ├── 09-api-routes.patch             (15 routes)
    ├── 10-api-seeders.patch            (enregistrement des seeders)
    ├── 11-docs.patch                   (documentation)
    └── nouveaux-fichiers/              ← même contenu que new-files/, en patch
        ├── n01-web-lib.patch … n12-api-tests.patch
```

Les patchs de `patches/` ne touchent que des **fichiers existants** (11 patchs) ;
les **fichiers à créer** sont fournis deux fois : en clair dans `new-files/` (37 fichiers)
et en patch dans `patches/nouveaux-fichiers/` (12 patchs), pour les flux `git apply`.

---

## 3. Tester le module seul (sans l'application)

Un **harnais de démonstration** est fourni dans `demo/` : une mini-application qui ne
contient que le module et l'infrastructure partagée dont il dépend (composants `ui/`,
tokens de charte, catalogue de permissions, adaptateur de démonstration).

```bash
cd demo
npm install       # ou : ln -s ../chemin/vers/apps/web/node_modules node_modules
npm run dev
```

Ouvrez **http://localhost:5174**. Vous pouvez créer un rôle, nommer un membre, désigner
un modérateur, révoquer, suspendre, exporter — tout est fonctionnel, les données sont
simplement en mémoire (le bouton « Réinitialiser » remet à zéro).

> La page affichée est **le fichier exact du livrable** (`admin-roles-page.tsx`), pas une
> reconstitution : ce que vous testez ici est ce que le stagiaire obtiendra.

Détail : [`demo/README.md`](demo/README.md).

## 4. Intégrer dans l'application

```bash
# 1. Se placer à la racine du dépôt Code212 Quest
cd /chemin/vers/code212-quest

# 2. Appliquer le module (copie des nouveaux fichiers + patchs)
./apply.sh /chemin/vers/module-code212-roles-access

# 3. Vérifier
cd apps/web && npm run typecheck && npm run build
cd ../api && php artisan migrate --seed && php artisan test
```

`apply.sh` est idempotent et affiche un compte rendu fichier par fichier.
Pour une intégration manuelle, voir `INTEGRATION.md`.

---

## 5. Prérequis

| Composant | Version | Remarque |
|---|---|---|
| React | 18 | compatible 18.x |
| TypeScript | 5.x | `strict`, `noUnusedLocals` |
| Vite | 5 | — |
| Tailwind CSS | 3 | tokens de charte déjà en place |
| Radix UI / shadcn | — | composants `ui/` déjà en place |
| TanStack Query | 5 | — |
| Laravel | 11 / 12 | API only, PostgreSQL, Sanctum |
| PHP | 8.2+ | `declare(strict_types=1)` |

Le module **n'ajoute aucune dépendance npm ni composer**. Il réutilise les composants
existants (`ui/`, `page-header`, `useToast`, `Button`, `Dialog`, `Select`, `Badge`…).

---

## 6. État de la recette

**Vérifié**

- TypeScript : `tsc -b` sans erreur, stricte activée.
- Build de production : vert, chunks inchangés.
- Parcours navigateur complet (création de rôle → nomination → modérateur → révocation →
  suspension → export CSV → journal) : **0 erreur console**.
- **Harnais `demo/`** : `tsc -b` sans erreur, `vite build` vert, parcours navigateur
  rejoué dans le harnais → **0 erreur console**.
- Les 21 routes de l'application rendent sans erreur après intégration.
- Rendu contrôlé en 1440 px et 390 px.
- **Les patchs reproduisent exactement l'intégration** : réapplication contrôlée sur une
  copie de l'état d'origine, comparaison octet par octet avec l'application intégrée.

**Non vérifié — à faire par le stagiaire**

- **Le code PHP n'a pas pu être exécuté** (PHP et Composer absents de l'environnement de
  rédaction). Les 11 tests API fournis n'ont donc **pas été exécutés**. C'est le premier
  point à traiter.
- Les tests API n'ont pas été lancés contre PostgreSQL : vérifier l'ordre des migrations
  (les tables `roles`, `permissions`, `role_permissions`, `role_assignments` et
  `moderator_scopes` doivent précéder les contraintes de clé étrangère).
- Le passage du mode démonstration (`VITE_USE_MOCK=true`) à l'API réelle suppose de
  vérifier le mapping des noms de champs : l'API est en français
  (`nom`, `description`, `couleur`, `permissions`, `email`, `role_code`, `sections`),
  le front parle anglais (`name`, `description`, `color`, `permissions`, `email`,
  `roleCode`, `sections`). La conversion est centralisée dans `src/services/api.ts`.

---

## 7. Licence et réemploi

Ce module suit les conventions du dépôt (PHP : PSR-12, typage strict, français ; front :
TypeScript strict, français, composants `shadcn` maison). Il peut être réadapté pour un
autre module en conservant la même mécanique : **fichiers à copier + patchs + guide**.
