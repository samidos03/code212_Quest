# Module « Moule d'administration » — Code212 Quest

Paquet autonome, prêt à intégrer dans le monorepo `code212-quest`
(`apps/web` React + TypeScript, `apps/api` Laravel 11).

> **Ce module ne réécrit pas l'application.** Il lui apporte un **patron de
> fabrication commun** à tous les écrans d'administration, et son pendant API
> (`GET /api/v1/admin/context`).

---

## 1. Le problème traité

Les écrans d'administration de la plateforme (*Vue d'ensemble*, *Étudiants*,
*Quêtes*, *Validation*, *Règles XP*, *Modération*, *Analytics*, *Rôles &
accès*) avaient chacun écrit leur propre en-tête, leur propre barre de filtres,
leur propre table et leur propre état vide. Résultat : huit écrans, huit
façons de présenter la même information, et une Direction qui doit réapprendre
à chaque écran où trouver l'information.

Le **moule** fixe un patron, un ordre et un vocabulaire :

```
1. le bandeau de contexte   — qui pilote, quel périmètre, quoi en attente
2. l'en-tête                — chapô, titre, description, actions d'écriture
3. les indicateurs          — 4 à 5 chiffres qui résument la situation
4. la barre d'outils        — recherche, filtres, compteur, actions
5. le contenu               — table, cartes ou graphiques, même cadre
```

Un nouvel écran d'administration se construit en **remplissant ces
emplacements**, jamais en réécrivant la structure.

---

## 2. Ce que contient le module

### 2.1 Les sept primitives (front)

| Fichier | Brique | Rôle |
|---|---|---|
| `components/admin/admin-context-bar.tsx` | Bandeau de contexte | Identité + rôle, périmètre, synchronisation UCA, alertes, action de resynchronisation. |
| `components/admin/admin-page.tsx` | Cadre de page | Assemble l'ordre imposé (1→5) ; c'est le seul point d'entrée d'un écran. |
| `components/admin/admin-kpi.tsx` | Indicateurs | `AdminKpi` (une carte) et `AdminKpiStrip` (grille responsive 2→5 colonnes). |
| `components/admin/admin-toolbar.tsx` | Barre d'outils | `AdminToolbar`, `AdminSearch`, `AdminFilter`, `AdminSegmented`, `AdminResultCount`. |
| `components/admin/admin-table.tsx` | Table | `AdminTable`, `AdminTableRow`, `AdminTableCell` ; gabarit de grille déclaré une fois et propagé par contexte. |
| `components/admin/admin-empty-state.tsx` | États | `AdminEmptyState` (vide / recherche infructueuse), `AdminEmptyAction`, `AdminTableSkeleton`. |
| `components/admin/admin-panel.tsx` | Panneau de section | Conteneur titré avec action à droite et pied optionnel. |

### 2.2 La page de référence — `/admin/mould`

Un écran de documentation **vivant** : anatomie du patron, exemple de chaque
brique, **bac à sable** pour voir les trois états d'une table (données,
chargement, vide), états d'erreur et squelette de code à recopier.

Elle est atteinte depuis l'espace Administration, rubrique
« Système de conception ».

### 2.3 La démonstration — `/admin/students`

L'écran *Étudiants* a été **reconstruit** avec le moule : c'est la preuve
que le patron tient sur une page réelle. Le fichier est fourni en
remplacement complet (`new-files/…/admin-students-page.tsx`).

Avant / après sur la même page :

| | Avant | Après |
|---|---|---|
| Contexte | absent | bandeau (identité, périmètre, synchronisation, alertes) |
| Indicateurs | aucun | 4 cartes (comptes, actifs, en attente, inactifs) |
| Barre d'outils | posée à la main | primitive (recherche + filtre + compteur) |
| Table | grille écrite à la main | primitive (gabarit partagé, état vide, pied) |
| Note de cadrage | section flottante | pied de page du cadre |

### 2.4 Le pendant API — `GET /api/v1/admin/context`

Source unique du bandeau de contexte et des indicateurs :

```jsonc
{
  "data": {
    "identity": { "name": "…", "role": "Directeur · Super Admin", "roleCode": "admin",
                  "scopeLabel": "Centre CODE212 · Université Cadi Ayyad",
                  "isGlobalAccess": true, "avatarKind": "super_admin" },
    "sync":     { "source": "UCA", "lastSyncAt": "…", "pendingRecords": 14, "status": "attention" },
    "alerts":   [{ "label": "Validations", "count": 3, "tone": "info" }, …],
    "counters": [{ "key": "students", "label": "Apprenants actifs", "value": 2486, "to": "/admin/students" }, …],
    "permissions": ["*"]
  }
}
```

- `GET /api/v1/admin/context` — rôle `admin` ou `moderator` (le groupe
  `/api/v1/admin` est déjà protégé par le rôle).
- Fichiers API : `AdminWorkspaceService`, `AdminWorkspaceResource`,
  `AdminWorkspaceController`, une route, et 5 tests
  (`AdminWorkspaceContextTest`).

---

## 3. Contenu du paquet

```
module-code212-mould-admin/
├── README.md                     ce document
├── INTEGRATION.md                guide d'intégration pas à pas
├── apply.sh                      application idempotente (copie + patchs)
├── new-files/                    13 fichiers
│   ├── apps/web/src/components/admin/*        les 7 primitives
│   ├── apps/web/src/pages/admin/*             la page de référence + la démonstration
│   └── apps/api/…                             service, ressource, contrôleur, test
├── patches/                      9 patchs sur les fichiers existants
│   └── nouveaux-fichiers/        13 diffs /dev/null des fichiers nouveaux
└── demo/                         harnais de démonstration autonome (port 5174)
```

### 3.1 Fichiers modifiés (9)

| Fichier | Modification |
|---|---|
| `apps/web/src/types/index.ts` | type `AdminContext` |
| `apps/web/src/services/mock/db.ts` | jeu de données de démonstration du contexte |
| `apps/web/src/services/mock/server.ts` | endpoint `getAdminContext()` |
| `apps/web/src/services/api.ts` | façade `adminContext()` |
| `apps/web/src/hooks/use-api.ts` | hook `useAdminContext()` (cache 5 min) |
| `apps/web/src/lib/navigation.ts` | rubrique « Système de conception » |
| `apps/web/src/App.tsx` | route `/admin/mould` |
| `apps/web/src/components/layout/topbar.tsx` | fil d'Ariane : le chemin le plus long l'emporte |
| `apps/api/routes/api.php` | route `GET /admin/context` |

> Le **catalogue de permissions n'est pas modifié** : le module s'appuie sur le
> rôle et le périmètre existants.

---

## 4. Installation

```bash
bash apply.sh /chemin/vers/code212-quest

cd /chemin/vers/code212-quest/apps/web
npm install && npm run typecheck && npm run build

cd ../api
composer install && php artisan migrate --seed && php artisan test
```

`apply.sh` est **idempotent** : le rejouer ne modifie rien et ne laisse aucun
`.rej`. Les patchs ont été vérifiés en rejouant l'intégration depuis l'état
« avant » et en comparant le résultat **octet par octet** avec l'état cible.

> `apps/web/src/pages/admin/admin-students-page.tsx` est **écrasé
> intentionnellement** : c'est la version reconstruite avec le moule.

---

## 5. Harnais de démonstration

```bash
cd demo
npm install
npm run dev      # http://localhost:5174
```

Deux vues : le **référentiel** (page de référence du moule, avec bac à sable)
et l'**écran métier** (Étudiants reconstruit). Les données sont en mémoire.

---

## 6. Limites connues

- **Le code Laravel n'a pas pu être exécuté** dans l'environnement de
  préparation (PHP absent) : le service, le contrôleur et les 5 tests sont
  écrits mais **doivent être lancés** par l'intégrateur.
- Seul l'écran *Étudiants* a été reconstruit avec le moule. Les sept autres
  écrans d'administration restent sur leur structure d'origine : la migration
  est progressive, écran par écran.
- La synchronisation UCA est lue depuis `libki_sync_logs` ; un tableau de bord
  de synchronisation dédié reste à prévoir.
- Les compteurs sont recalculés à chaque appel : à passer en cache si la
  volumétrie grandit.
