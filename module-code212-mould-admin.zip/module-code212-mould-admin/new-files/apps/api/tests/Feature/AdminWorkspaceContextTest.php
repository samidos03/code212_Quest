<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\ModeratorScope;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Laravel\Sanctum\Sanctum;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;

/**
 * Contexte d'administration : source unique du bandeau de contexte, des
 * indicateurs et des raccourcis de navigation.
 */
class AdminWorkspaceContextTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(\Database\Seeders\PermissionSeeder::class);
        $this->seed(\Database\Seeders\SystemRoleSeeder::class);
    }

    #[Test]
    public function un_administrateur_recupere_son_contexte(): void
    {
        $admin = $this->makeUser(['name' => 'Walid Bouarifi', 'roles' => ['admin']]);

        Sanctum::actingAs($admin, ['read']);

        $response = $this->getJson('/api/v1/admin/context')->assertOk();

        $this->assertSame('Walid Bouarifi', $response->json('data.identity.name'));
        $this->assertSame('Directeur · Super Admin', $response->json('data.identity.role'));
        $this->assertSame('admin', $response->json('data.identity.roleCode'));
        $this->assertTrue($response->json('data.identity.isGlobalAccess'));
        $this->assertSame('super_admin', $response->json('data.identity.avatarKind'));
    }

    #[Test]
    public function un_moderateur_a_un_perimetre_restreint(): void
    {
        $moderator = $this->makeUser(['name' => 'Ghita Amrani', 'roles' => ['moderator']]);

        ModeratorScope::query()->create([
            'user_id' => $moderator->getKey(),
            'sections' => ['entraide', 'cafe'],
            'scope_note' => 'Relais entraide.',
        ]);

        Sanctum::actingAs($moderator, ['read']);

        $response = $this->getJson('/api/v1/admin/context')->assertOk();

        $this->assertFalse($response->json('data.identity.isGlobalAccess'));
        $this->assertStringContainsString('entraide', $response->json('data.identity.scopeLabel'));
        $this->assertSame('moderator', $response->json('data.identity.roleCode'));
    }

    #[Test]
    public function le_contexte_expose_alertes_et_compteurs(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read']);

        $response = $this->getJson('/api/v1/admin/context')->assertOk();

        $alerts = collect($response->json('data.alerts'))->pluck('label')->all();
        $this->assertContains('Validations', $alerts);
        $this->assertContains('Signalements', $alerts);
        $this->assertContains('Escalades', $alerts);

        $counters = collect($response->json('data.counters'))->pluck('key')->all();
        $this->assertContains('students', $counters);
        $this->assertContains('quests', $counters);
        $this->assertContains('roles', $counters);
        $this->assertContains('moderators', $counters);
    }

    #[Test]
    public function le_contexte_decrit_la_synchronisation_uca(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['admin']]), ['read']);

        $response = $this->getJson('/api/v1/admin/context')->assertOk();

        $this->assertSame('UCA', $response->json('data.sync.source'));
        $this->assertContains($response->json('data.sync.status'), ['ok', 'attention', 'echec']);
        $this->assertNotNull($response->json('data.sync.lastSyncAt'));
    }

    #[Test]
    public function un_apprenant_ne_peut_pas_lire_le_contexte(): void
    {
        Sanctum::actingAs($this->makeUser(['roles' => ['student']]), ['read']);

        $this->getJson('/api/v1/admin/context')->assertForbidden();
    }
}
