<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\ForgeReportStatus;
use App\Enums\QuestStatus;
use App\Enums\SubmissionStatus;
use App\Models\BanRequest;
use App\Models\ForgeReport;
use App\Models\LibkiSyncLog;
use App\Models\ModeratorScope;
use App\Models\Quest;
use App\Models\Role;
use App\Models\Submission;
use App\Models\User;
use Illuminate\Support\Carbon;

/**
 * Contexte d'administration : ce que l'ecran d'administration doit savoir
 * avant d'afficher quoi que ce soit.
 *
 * Le service ne redige rien : il rassemble l'etat courant (identite,
 * perimetre, synchronisation, alertes, compteurs) et le rend disponible sous
 * une forme stable. Le bandeau de contexte du front, les indicateurs et les
 * raccourcis de navigation s'y branchent.
 */
final class AdminWorkspaceService
{
    public function __construct(
        private readonly RoleService $roles,
    ) {
    }

    /**
     * Contexte complet pour un administrateur donne.
     *
     * @return array<string, mixed>
     */
    public function context(User $actor): array
    {
        return [
            'identity' => $this->identity($actor),
            'sync' => $this->sync(),
            'alerts' => $this->alerts(),
            'counters' => $this->counters(),
            'permissions' => $actor->isAdmin()
                ? ['*']
                : $this->roles->effectivePermissions($actor),
        ];
    }

    /**
     * Identite, role et perimetre de l'acteur.
     *
     * @return array<string, mixed>
     */
    private function identity(User $actor): array
    {
        $scope = $actor->moderatorScope;
        $isGlobal = $actor->isAdmin();

        $roleLabel = match (true) {
            $actor->isAdmin() => 'Directeur · Super Admin',
            $actor->hasRole('moderator') => 'Modérateur · La Forge',
            $actor->hasRole('trainer') => 'Formateur',
            default => 'Membre de l’équipe',
        };

        $scopeLabel = $isGlobal
            ? 'Centre CODE212 · Université Cadi Ayyad'
            : ($scope !== null && $scope->isActive()
                ? 'Rubriques '.implode(', ', $scope->sections ?? [])
                : 'Aucun périmètre');

        return [
            'name' => $actor->name,
            'role' => $roleLabel,
            'roleCode' => $actor->isAdmin() ? 'admin' : ($actor->hasRole('moderator') ? 'moderator' : 'staff'),
            'scopeLabel' => $scopeLabel,
            'isGlobalAccess' => $isGlobal,
            'avatarKind' => $actor->isAdmin() ? 'super_admin' : 'standard',
        ];
    }

    /**
     * Etat de la synchronisation avec l'annuaire institutionnel.
     *
     * @return array<string, mixed>
     */
    private function sync(): array
    {
        $last = LibkiSyncLog::query()->latest('event_at')->first();

        $pending = LibkiSyncLog::query()->whereNull('processed_at')->count();

        return [
            'source' => 'UCA',
            'lastSyncAt' => ($last?->event_at ?? $last?->created_at)?->toIso8601String() ?? now()->subHour()->toIso8601String(),
            'pendingRecords' => $pending,
            'status' => $pending > 20 ? 'echec' : ($pending > 0 ? 'attention' : 'ok'),
        ];
    }

    /**
     * Ce qui reclame une decision de l'administrateur.
     *
     * @return list<array{label: string, count: int, tone: string}>
     */
    private function alerts(): array
    {
        return [
            [
                'label' => 'Validations',
                'count' => Submission::query()->where('status', SubmissionStatus::Pending->value)->count(),
                'tone' => 'info',
            ],
            [
                'label' => 'Signalements',
                'count' => ForgeReport::query()->where('status', ForgeReportStatus::Open->value)->count(),
                'tone' => 'warning',
            ],
            [
                'label' => 'Escalades',
                'count' => BanRequest::query()->where('status', 'en_attente')->count(),
                'tone' => 'danger',
            ],
        ];
    }

    /**
     * Compteurs de pilotage.
     *
     * @return list<array{key: string, label: string, value: int, to?: string}>
     */
    private function counters(): array
    {
        return [
            [
                'key' => 'students',
                'label' => 'Apprenants actifs',
                'value' => User::query()->where('roles', '?', json_encode(['student']))->count(),
                'to' => '/admin/students',
            ],
            [
                'key' => 'quests',
                'label' => 'Quêtes publiées',
                'value' => Quest::query()->where('status', QuestStatus::Published->value)->count(),
                'to' => '/admin/quests',
            ],
            [
                'key' => 'validations',
                'label' => 'Validations en attente',
                'value' => Submission::query()->where('status', SubmissionStatus::Pending->value)->count(),
                'to' => '/admin/validation',
            ],
            [
                'key' => 'reports',
                'label' => 'Signalements ouverts',
                'value' => ForgeReport::query()->where('status', ForgeReportStatus::Open->value)->count(),
                'to' => '/admin/moderation',
            ],
            [
                'key' => 'roles',
                'label' => 'Rôles configurés',
                'value' => Role::query()->whereNull('revoked_at')->count(),
                'to' => '/admin/roles',
            ],
            [
                'key' => 'moderators',
                'label' => 'Modérateurs nommés',
                'value' => ModeratorScope::query()
                    ->whereNull('revoked_at')
                    ->where(static function ($query): void {
                        $query->whereNull('expires_at')->orWhere('expires_at', '>', Carbon::now());
                    })
                    ->count(),
                'to' => '/admin/roles',
            ],
        ];
    }
}
