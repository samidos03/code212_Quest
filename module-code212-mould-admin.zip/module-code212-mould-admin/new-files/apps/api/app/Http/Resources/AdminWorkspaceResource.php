<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Contexte d'administration (bandeau de contexte, indicateurs, raccourcis).
 *
 * @mixin \App\Services\AdminWorkspaceService
 */
class AdminWorkspaceResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return $this->resource;
    }
}
