<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdminWorkspaceResource;
use App\Services\AdminWorkspaceService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Contexte d'administration : identite, perimetre, synchronisation, alertes,
 * compteurs et permissions effectives.
 *
 * C'est la source unique du bandeau de contexte et des indicateurs presents
 * sur tous les ecrans d'administration.
 */
class AdminWorkspaceController extends Controller
{
    public function __construct(private readonly AdminWorkspaceService $workspace)
    {
    }

    public function context(Request $request): JsonResponse
    {
        return ApiResponse::resource(new AdminWorkspaceResource($this->workspace->context($request->user())));
    }
}
