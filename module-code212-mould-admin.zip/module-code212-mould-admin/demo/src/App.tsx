import { useState } from 'react'
import { FlaskConical, LayoutTemplate, RotateCcw, Users } from 'lucide-react'
import { AdminMouldPage } from '@/pages/admin/admin-mould-page'
import { AdminStudentsPage } from '@/pages/admin/admin-students-page'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

/**
 * Harnais de demonstration : le « moule d'administration » est presente seul.
 *
 * Deux vues : le referentiel (anatomie, briques, bac a sable) et une page
 * metier reconstruite avec le moule (ecran « Etudiants »).
 */
export default function App() {
  const [view, setView] = useState<'mould' | 'metier'>('mould')

  return (
    <div className="min-h-screen bg-bg">
      <header className="border-b border-border bg-surface/80 backdrop-blur">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-gradient text-[11px] font-bold text-white">
            212
          </span>
          <div className="min-w-0 flex-1 basis-full sm:basis-auto">
            <p className="text-[14px] font-bold leading-tight text-fg">
              Harnais de démonstration · module « Moule d’administration »
            </p>
            <p className="truncate text-[11.5px] text-fg-subtle">
              Le patron commun à tous les écrans d’administration — données de démonstration en mémoire.
            </p>
          </div>

          <div className="flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1">
            <button
              type="button"
              onClick={() => setView('mould')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all ${
                view === 'mould' ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg'
              }`}
            >
              <LayoutTemplate className="h-3.5 w-3.5" /> Référentiel
            </button>
            <button
              type="button"
              onClick={() => setView('metier')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all ${
                view === 'metier' ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg'
              }`}
            >
              <Users className="h-3.5 w-3.5" /> Écran métier
            </button>
          </div>

          <Badge variant="warning" className="shrink-0">
            <FlaskConical className="h-3 w-3" /> Mode démo
          </Badge>
          <Button
            variant="outline"
            size="sm"
            className="shrink-0"
            onClick={() => window.location.reload()}
          >
            <RotateCcw className="h-3.5 w-3.5" /> Réinitialiser
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
        {view === 'mould' ? <AdminMouldPage /> : <AdminStudentsPage />}
      </main>

      <footer className="mx-auto max-w-[1600px] px-4 pb-8 text-[11.5px] text-fg-subtle sm:px-6">
        Rappel : les changements faits ici sont en mémoire. Pour des données persistantes, basculez
        <code className="mx-1 rounded bg-surface-2 px-1 py-0.5 font-mono text-[10.5px]">VITE_USE_MOCK=false</code>
        et renseignez <code className="rounded bg-surface-2 px-1 py-0.5 font-mono text-[10.5px]">VITE_API_BASE_URL</code>.
      </footer>
    </div>
  )
}
