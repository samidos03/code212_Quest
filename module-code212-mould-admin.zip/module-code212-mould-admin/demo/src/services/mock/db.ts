/**
 * Code212 Quest — jeu de données de démonstration.
 *
 * Ces données alimentent le mode « démo » de l'API (VITE_USE_MOCK=true).
 * Elles respectent la forme des payloads exposés par Laravel dans `/api/v1`
 * afin que le basculement vers le backend réel n'implique aucun changement
 * de composants.
 */
import type {
  AdminContext,
  AdminOverview,
  Badge,
  Certification,
  Challenge,
  ForgeCategory,
  ForgeSolution,
  ForgeThread,
  LeaderboardEntry,
  LearningPath,
  ManagedUser,
  ModeratorAssignment,
  ModeratorSection,
  ModerationAction,
  ModerationBan,
  ModerationMotif,
  ModerationReport,
  ModerationReportStatus,
  ModerationSeverity,
  ReportedUser,
  BanEscalation,
  Role,
  RoleAssignment,
  RoleAuditEvent,
  LevelConfig,
  Mission,
  Quest,
  Reward,
  RewardOrder,
  Submission,
  Track,
  TrackCode,
  XpRule,
} from '@/types'
import { PERMISSION_MODULES, SYSTEM_ROLES } from '@/lib/permissions'

const now = Date.now()
const iso = (daysAgo: number, hour = 10) => {
  const d = new Date(now - daysAgo * 86400000)
  d.setHours(hour, (daysAgo * 7) % 60, 0, 0)
  return d.toISOString()
}

/* ------------------------------------------------------------------ niveaux */

export const levels: LevelConfig[] = [
  { level: 1, title: 'Nouveau venus', xpThreshold: 0, requirements: ['Créer son profil'], benefits: ['Accès aux quêtes d’introduction'] },
  { level: 2, title: 'Explorateur', xpThreshold: 250, requirements: ['Compléter 1 quête'], benefits: ['Voie Codeur débloquée'] },
  { level: 3, title: 'Apprenti', xpThreshold: 600, requirements: ['Compléter 3 quêtes', '1 badge obtenu'], benefits: ['La Forge — poster une question'] },
  { level: 4, title: 'Praticien', xpThreshold: 1100, requirements: ['5 quêtes', '2 badges'], benefits: ['Créer une quête (candidature)'] },
  { level: 5, title: 'Confirmé', xpThreshold: 1800, requirements: ['10 quêtes', 'série de 3 jours'], benefits: ['Voie Aidant débloquée'] },
  { level: 6, title: 'Avancé', xpThreshold: 2700, requirements: ['15 quêtes', '1 parcours validé'], benefits: ['Certifications Open Badges'] },
  { level: 7, title: 'Expert', xpThreshold: 3600, requirements: ['25 quêtes', '3 parcours'], benefits: ['Voie Bâtisseur débloquée'] },
  { level: 8, title: 'Architecte', xpThreshold: 4500, requirements: ['35 quêtes', '5 badges', 'niveau 6 validé'], benefits: ['Accès aux défis inter-universités'] },
  { level: 9, title: 'Maître', xpThreshold: 5800, requirements: ['45 quêtes', 'voie dominante identifiée'], benefits: ['Voie Explorateur débloquée'] },
  { level: 10, title: 'Légende Code212', xpThreshold: 8000, requirements: ['60 quêtes', '10 badges', 'validation Centre'], benefits: ['Statut de mentor, badge sigmatique'] },
]

/* -------------------------------------------------------------------- voies */

const rankNames: Record<TrackCode, string[]> = {
  codeur: ['Novice', 'Apprenti', 'Confirmé', 'Expert', 'Maître'],
  aidant: ['Passerelle', 'Soutien', 'Mentor', 'Pilier', 'Référent'],
  batisseur: ['Éclaireur', 'Bâtisseur', 'Architecte', 'Chef de projet', 'Monument'],
  explorateur: ['Curieux', 'Randonneur', 'Pionnier', 'Ambassadeur', 'Légende'],
}
const rankThresholds = [0, 100, 400, 1000, 2000]

function buildTrack(code: TrackCode, name: string, description: string, icon: string, color: string, points: number, questIds: number[]): Track {
  const ranks = rankNames[code].map((label, i) => ({
    rank: i + 1,
    code: `${code}-r${i + 1}`,
    label,
    threshold: rankThresholds[i],
  }))
  const current = [...ranks].reverse().find((r) => points >= r.threshold) ?? ranks[0]
  const next = ranks.find((r) => r.threshold > points) ?? null
  return { code, name, description, icon, color, points, rank: current, nextRank: next, questIds }
}

export const tracks: Track[] = [
  buildTrack('codeur', 'Codeur', 'Maîtrise technique : algorithmique, frameworks, qualité de code.', '</>', '#6701e6', 1240, [1, 3, 5, 8]),
  buildTrack('aidant', 'Aidant', 'Entraide, mentorat et qualité de la communauté.', '✦', '#c5027f', 860, [2, 6, 9]),
  buildTrack('batisseur', 'Bâtisseur', 'Projets de bout en bout et architecture de solutions.', '◈', '#00b8d4', 610, [4, 7, 11]),
  buildTrack('explorateur', 'Explorateur', 'Veille, nouveaux domaines et ouverture internationale.', '⌘', '#f59e0b', 430, [10, 12]),
]

/* ------------------------------------------------------------------ quêtes */

type StepSeed = [title: string, kind: QuestStepKind, xp: number, minutes: number, description: string]
type QuestStepKind = 'lecture' | 'quiz' | 'code' | 'livrable' | 'live'

const step = (order: number, [title, kind, xp, minutes, description]: StepSeed) => ({
  id: order,
  order,
  title,
  description,
  kind,
  xp,
  durationMinutes: minutes,
  status: 'verrouille' as const,
})

const questSeeds: Array<{
  id: number
  slug: string
  title: string
  subtitle: string
  category: string
  track: TrackCode
  difficulty: Quest['difficulty']
  xpReward: number
  trackPoints: number
  germs: number
  minutes: number
  participants: number
  rate: number
  author: string
  icon: string
  gradient: string
  days: number
  prereq: number[]
  objectives: string[]
  badges: string[]
  steps: StepSeed[]
}> = [
  {
    id: 1, slug: 'ai-prompt-engineering', title: 'AI Prompt Engineering', subtitle: 'Construire des prompts qui tiennent la route',
    category: 'Intelligence artificielle', track: 'codeur', difficulty: 'debutant', xpReward: 450, trackPoints: 120, germs: 30,
    minutes: 45, participants: 128, rate: 68, author: 'Dr. Salma Bennani', icon: '✦', gradient: 'violet', days: 26, prereq: [],
    objectives: ['Maîtriser les 6 blocs d’un prompt efficace', 'Évaluer une réponse de modèle', 'Documenter une stratégie de prompting'],
    badges: ['AI Explorer'],
    steps: [
      ['Comprendre les LLM', 'lecture', 60, 10, 'Panorama des modèles, fenêtres de contexte et limites.'],
      ['Anatomie d’un prompt', 'quiz', 80, 10, 'Rôle, contexte, consignes, exemples, format, itération.'],
      ['Atelier prompt itératif', 'code', 180, 15, 'Construire puis raffiner un prompt de qualification technique.'],
      ['Livrable : bibliothèque de prompts', 'livrable', 130, 10, 'Documenter 5 prompts réutilisables et leur grille d’évaluation.'],
    ],
  },
  {
    id: 2, slug: 'cybersecurity-sprint', title: 'Cybersecurity Sprint', subtitle: 'Penser comme un attaquant, agir comme un gardien',
    category: 'Cybersécurité', track: 'codeur', difficulty: 'intermediaire', xpReward: 700, trackPoints: 180, germs: 45,
    minutes: 80, participants: 86, rate: 54, author: 'Prof. Karim Idrissi', icon: '⌘', gradient: 'cyan', days: 24, prereq: [1],
    objectives: ['Modéliser une surface d’attaque', 'Auditer une configuration', 'Rédiger un rapport exploitable'],
    badges: ['Cyber Guardian'],
    steps: [
      ['Surface d’attaque d’une application web', 'lecture', 100, 15, 'OWASP Top 10 appliqué au contexte étudiant.'],
      ['TP : cartographie d’une API vulnérable', 'code', 240, 30, 'Tester un endpoint avec les outils autorisés du centre.'],
      ['Quiz certification', 'quiz', 120, 15, '10 questions, seuil 8/10 pour valider.'],
      ['Livrable : rapport de remédiation', 'livrable', 240, 20, 'Prioriser 5 vulnérabilités et planifier les correctifs.'],
    ],
  },
  {
    id: 3, slug: 'build-a-rest-api', title: 'Build a REST API', subtitle: 'Du schéma au déploiement',
    category: 'Développement', track: 'codeur', difficulty: 'avance', xpReward: 900, trackPoints: 220, germs: 60,
    minutes: 120, participants: 64, rate: 41, author: 'Mehdi Alaoui', icon: '</>', gradient: 'magenta', days: 21, prereq: [1],
    objectives: ['Modéliser une API REST cohérente', 'Gérer erreurs et versions', 'Documenter et tester'],
    badges: ['API Architect'],
    steps: [
      ['Conception de l’API', 'lecture', 120, 20, 'Ressources, verbes, codes HTTP, versionnement.'],
      ['Implémentation Laravel', 'code', 320, 40, 'Modèles, migrations, contrôleurs, ressources.'],
      ['Authentification & rate limiting', 'code', 220, 30, 'Sanctum, policies, throttling.'],
      ['Tests et documentation', 'livrable', 240, 30, 'Tests Pest, OpenAPI, postman collection.'],
    ],
  },
  {
    id: 4, slug: 'data-detective', title: 'Data Detective', subtitle: 'Faire parler des données propres',
    category: 'Data & Analytics', track: 'batisseur', difficulty: 'intermediaire', xpReward: 600, trackPoints: 160, germs: 40,
    minutes: 60, participants: 94, rate: 61, author: 'Pr. Youssef Belhaj', icon: '◈', gradient: 'orange', days: 19, prereq: [],
    objectives: ['Nettoyer un jeu de données', 'Construire une visualisation honnête', 'Rédiger une recommandation'],
    badges: ['Data Mind'],
    steps: [
      ['Nettoyage de données réelles', 'code', 180, 20, 'Valeurs manquantes, doublons, types incohérents.'],
      ['Analyse exploratoire', 'code', 160, 20, 'Statistiques descriptives et lecture critique.'],
      ['Visualisation & storytelling', 'livrable', 260, 20, 'Un graphique, une histoire, une décision.'],
    ],
  },
  {
    id: 5, slug: 'devops-pipeline', title: 'DevOps Pipeline', subtitle: 'De la branche au déploiement',
    category: 'DevOps', track: 'batisseur', difficulty: 'avance', xpReward: 850, trackPoints: 200, germs: 55,
    minutes: 110, participants: 52, rate: 38, author: 'Nada Cherkaoui', icon: '⚙', gradient: 'cyan', days: 18, prereq: [3],
    objectives: ['Écrire un pipeline CI', 'Conteneuriser une application', 'Automatiser les tests'],
    badges: ['Pipeline Master'],
    steps: [
      ['CI : pipelines de base', 'lecture', 110, 15, 'GitHub Actions, secrets, environments.'],
      ['Docker multi-stage', 'code', 300, 35, 'Image optimisée, cache, sécurité.'],
      ['Tests automatisés en CI', 'code', 220, 30, 'Tests unitaires + intégration, quality gates.'],
      ['Déploiement & rollback', 'livrable', 220, 30, 'Documentation de déploiement et procédure de retour arrière.'],
    ],
  },
  {
    id: 6, slug: 'mt-mentorat', title: 'Devenir mentor', subtitle: 'Transmettre ce que l’on sait',
    category: 'Communauté', track: 'aidant', difficulty: 'intermediaire', xpReward: 500, trackPoints: 260, germs: 35,
    minutes: 70, participants: 71, rate: 72, author: 'Centre CODE212', icon: '★', gradient: 'magenta', days: 16, prereq: [],
    objectives: ['Rédiger une réponse utile', 'Encadrer un binôme', 'Animer une session live'],
    badges: ['Aideur'],
    steps: [
      ['Écrire pour aider', 'lecture', 90, 15, 'Méthode, ton, exemples reproductibles.'],
      ['Répondre dans La Forge', 'livrable', 180, 25, '3 réponses acceptées par un formateur.'],
      ['Session live d’entraide', 'live', 230, 30, 'Animer 30 min, fenced par le Centre.'],
    ],
  },
  {
    id: 7, slug: 'architecture-clean', title: 'Architecture Clean', subtitle: 'Concevoir pour durer',
    category: 'Architecture', track: 'batisseur', difficulty: 'expert', xpReward: 1100, trackPoints: 280, germs: 75,
    minutes: 150, participants: 38, rate: 29, author: 'Dr. Karim Idrissi', icon: '▦', gradient: 'violet', days: 14, prereq: [3, 5],
    objectives: ['Cartographier un domaine métier', 'Isoler la logique métier', 'Documenter les décisions (ADR)'],
    badges: ['Architecte'],
    steps: [
      ['Découpage en domaines', 'lecture', 160, 25, 'Bounded contexts, dépendances, hexagonal.'],
      ['Refactoring guidé', 'code', 420, 60, 'Extraire la logique métier d’un projet réel.'],
      ['Livrable : 3 ADR', 'livrable', 520, 65, 'Architecture Decision Records argumentés et sourcés.'],
    ],
  },
  {
    id: 8, slug: 'javascript-avance', title: 'JavaScript Avancé', subtitle: 'Asynchrone, typage et performance',
    category: 'Développement', track: 'codeur', difficulty: 'avance', xpReward: 820, trackPoints: 210, germs: 50,
    minutes: 100, participants: 77, rate: 47, author: 'Mehdi Alaoui', icon: 'JS', gradient: 'orange', days: 12, prereq: [1],
    objectives: ['Maîtriser event loop et promises', 'Typage progressif', 'Mesurer les performances'],
    badges: ['Async Adept'],
    steps: [
      ['Event loop & concurrence', 'lecture', 140, 20, 'Microtâches, workers, concurrence réelle.'],
      ['TypeScript en pratique', 'code', 320, 40, 'Types génériques, narrowing, satisfies.'],
      ['Profiling & optimisation', 'code', 360, 40, 'Mesurer avant d’optimiser, bundle analysis.'],
    ],
  },
  {
    id: 9, slug: 'git-collaboration', title: 'Git & Collaboration', subtitle: 'Travailler à plusieurs sans se marcher dessus',
    category: 'Outils', track: 'aidant', difficulty: 'debutant', xpReward: 380, trackPoints: 200, germs: 25,
    minutes: 40, participants: 143, rate: 79, author: 'Centre CODE212', icon: '⑂', gradient: 'cyan', days: 11, prereq: [],
    objectives: ['Écrire des commits utiles', 'Résoudre un conflit', 'Ouvrir une Pull Request propre'],
    badges: ['Git Guardian'],
    steps: [
      ['Modèle de branches du centre', 'lecture', 70, 10, 'trunk-based, conventions de nommage.'],
      ['TP conflits & rébase', 'code', 160, 20, 'Résoudre 5 conflits préparés.'],
      ['Livrable : PR commentée', 'livrable', 150, 10, 'Une PR lue et relue par un pair.'],
    ],
  },
  {
    id: 10, slug: 'veille-techno', title: 'Veille technologique', subtitle: 'Rester lucide face au bruit',
    category: 'Innovation', track: 'explorateur', difficulty: 'debutant', xpReward: 420, trackPoints: 240, germs: 30,
    minutes: 50, participants: 59, rate: 58, author: 'Cluster CCIS', icon: '◐', gradient: 'violet', days: 9, prereq: [],
    objectives: ['Construire un flux de veille', 'Évaluer la crédibilité d’une source', 'Partager une synthèse utile'],
    badges: ['Veille Active'],
    steps: [
      ['Sources fiables & RSS', 'lecture', 80, 15, 'Panorama des sourcesчай pour la tech.'],
      ['Filtre & synthèse', 'livrable', 190, 20, 'Une note de veille de 500 mots sourcée.'],
      ['Restitution dans La Forge', 'live', 150, 15, 'Présentation de 5 min à ton groupe.'],
    ],
  },
  {
    id: 11, slug: 'projet-fil-rouge', title: 'Projet fil rouge', subtitle: 'Construire, montrer, défendre',
    category: 'Projet', track: 'batisseur', difficulty: 'expert', xpReward: 1400, trackPoints: 320, germs: 100,
    minutes: 300, participants: 24, rate: 22, author: 'Jury Centre CODE212', icon: '⬢', gradient: 'magenta', days: 7, prereq: [5, 7],
    objectives: ['Livrer un projet complet', 'Documenter et présenter', 'Recevoir une évaluation signée'],
    badges: ['Bâtisseur', 'Certification projet'],
    steps: [
      ['Cadrage & plan', 'livrable', 180, 40, 'Périmètre, user stories, backlog, jalons.'],
      ['Développement', 'code', 700, 160, 'Itérations, revue de code, tests.'],
      ['Défense devant jury', 'live', 520, 100, 'Soutenance 10 min + questions.'],
    ],
  },
  {
    id: 12, slug: 'open-source-contrib', title: 'Contribuer à l’Open Source', subtitle: 'Sa première pull request',
    category: 'Communauté', track: 'explorateur', difficulty: 'intermediaire', xpReward: 640, trackPoints: 250, germs: 45,
    minutes: 90, participants: 44, rate: 45, author: 'Communauté open source', icon: '◎', gradient: 'orange', days: 5, prereq: [9],
    objectives: ['Trouver un projet accueillant', 'Rédiger une contribution acceptable', 'Faire relire sa PR'],
    badges: ['First Merge'],
    steps: [
      ['Choisir un projet', 'lecture', 90, 15, 'Signaux d’un projet friendly, guidelines.'],
      ['Contribuer', 'code', 320, 45, 'Fix ou doc, tests, commits propres.'],
      ['PR acceptée', 'livrable', 230, 30, 'Lien vers la PR fusionnée.'],
    ],
  },
]

export const quests: Quest[] = questSeeds.map((q) => ({
  id: q.id,
  slug: q.slug,
  title: q.title,
  subtitle: q.subtitle,
  description: `${q.subtitle}. Cette quête vous guide pas à pas à travers des exercices corrigés par les formateurs du centre CODE212, avec un livrable évalué et une attestation de compétence.`,
  category: q.category,
  track: q.track,
  difficulty: q.difficulty,
  status: 'publiee',
  xpReward: q.xpReward,
  trackPoints: q.trackPoints,
  germsReward: q.germs,
  durationMinutes: q.minutes,
  participants: q.participants,
  completionRate: q.rate,
  prerequisites: q.prereq,
  badges: q.badges,
  authorName: q.author,
  createdAt: iso(q.days),
  coverGradient: q.gradient,
  icon: q.icon,
  enrolled: false,
  progress: 0,
  steps: q.steps.map((s, i) => step(i + 1, s)),
  objectives: q.objectives,
}))

/* ------------------------------------------------------------------ badges */

const badgeSeeds: Array<[string, string, TrackCode, Badge['rarity'], number, string, string, number, number]> = [
  ['AI Explorer', 'Première quête IA terminée', 'codeur', 'commun', 50, '✦', 'Compléter une quête Intelligence artificielle', 0, 1],
  ['Cyber Guardian', 'Fondamentaux cybersécurité validés', 'codeur', 'rare', 120, '⌘', 'Terminer la quête Cybersecurity Sprint', 0, 1],
  ['API Architect', 'Backend complet maîtrisé', 'codeur', 'epique', 200, '</>', 'Livrer une API REST testée', 0, 1],
  ['Async Adept', 'Maîtrise de l’asynchrone', 'codeur', 'rare', 120, '⚡', 'Terminer JavaScript Avancé', 0, 1],
  ['Pipeline Master', 'CI/CD opérationnel', 'batisseur', 'rare', 130, '⚙', 'Terminer DevOps Pipeline', 0, 1],
  ['Data Mind', 'Lecture critique des données', 'batisseur', 'commun', 60, '◈', 'Terminer Data Detective', 1, 1],
  ['Architecte', 'Décisions d’architecture argumentées', 'batisseur', 'legendaire', 350, '▦', 'Terminer Architecture Clean', 0, 1],
  ['Bâtisseur', 'Projet fil rouge livré', 'batisseur', 'epique', 300, '⬢', 'Terminer Projet fil rouge', 0, 1],
  ['Aideur', 'Première réponse acceptée', 'aidant', 'commun', 50, '★', 'Aider un pair dans La Forge', 0, 1],
  ['Mentor', '10 réponses acceptées', 'aidant', 'rare', 140, '★', '10 réponses acceptées par des formateurs', 3, 10],
  ['Pilier', 'Session live animée', 'aidant', 'epique', 240, '◈', 'Animer une session d’entraide', 0, 1],
  ['Git Guardian', 'Collaborateur fiable', 'aidant', 'commun', 40, '⑂', 'Terminer Git & Collaboration', 0, 1],
  ['Veille Active', 'Curiosity structurée', 'explorateur', 'commun', 50, '◐', 'Terminer Veille technologique', 0, 1],
  ['First Merge', 'Première contribution acceptée', 'explorateur', 'rare', 130, '◎', 'Faire fusionner une pull request', 0, 1],
  ['Ambassadeur', 'Parrainage de 3 nouveaux arrivants', 'explorateur', 'epique', 260, '✧', 'Accompagner 3 nouveaux étudiants', 0, 3],
  ['Early Bird', 'Actif avant 8h, 5 jours de suite', 'explorateur', 'commun', 45, '☀', '5 connexions matinales', 0, 5],
  ['In serie', '7 jours de série', 'aidant', 'commun', 60, '🔥', 'Maintenir 7 jours consécutifs', 7, 7],
  ['Marathon', '30 jours de série', 'explorateur', 'legendaire', 400, '🏔', 'Maintenir 30 jours consécutifs', 0, 30],
  ['Première Quête', 'Tu as commencé', 'codeur', 'commun', 25, '◔', 'Terminer ta première quête', 0, 1],
  ['Dizaines', '10 quêtes terminées', 'codeur', 'rare', 110, '◑', 'Terminer 10 quêtes', 0, 10],
  ['Centurion', '100 quêtes terminées', 'codeur', 'legendaire', 500, '⬢', 'Terminer 100 quêtes', 0, 100],
  ['Parcours Complet', 'Un parcours intégral', 'batisseur', 'rare', 150, '▣', 'Terminer tous les parcours liés', 0, 1],
  ['Certifié', 'Première certification', 'codeur', 'rare', 150, '❖', 'Obtenir une certification', 0, 1],
  ['Double Certifié', 'Deux certifications', 'batisseur', 'epique', 220, '❖', 'Obtenir deux certifications', 0, 2],
  ['Réputation', '10 upvotes reçues', 'aidant', 'commun', 70, '↑', 'Recevoir 10 votes positifs', 0, 10],
  ['Polyvalent', '3 voies actives', 'explorateur', 'epique', 230, '✺', 'Progresser sur 3 voies', 2, 3],
  ['Voie Dominante', 'Une voie au rang 3', 'batisseur', 'rare', 160, '◆', 'Atteindre le rang 3 sur une voie', 0, 1],
  ['Retourneur', 'Revenir après 30 jours', 'aidant', 'commun', 55, '↺', 'Reprendre après une pause', 0, 1],
  ['Membre Fidèle', '30 jours sur la plateforme', 'explorateur', 'rare', 140, '❥', '30 jours d’activité', 0, 30],
  ['Ambassadeur UCA', 'Représenter le centre', 'explorateur', 'legendaire', 450, '★', 'Mission de représentation validée', 0, 1],
]

/** Etat d'avancement coherent : 8 badges obtenus, les autres en progression. */
const badgeProgress: Record<string, { earned: boolean; progress: number }> = {
  'Première Quête': { earned: true, progress: 1 },
  'Git Guardian': { earned: true, progress: 1 },
  'Aideur': { earned: true, progress: 1 },
  'Data Mind': { earned: true, progress: 1 },
  'In serie': { earned: true, progress: 7 },
  'Veille Active': { earned: true, progress: 1 },
  'Réputation': { earned: true, progress: 10 },
  'Early Bird': { earned: true, progress: 5 },
  'AI Explorer': { earned: false, progress: 0 },
  'Cyber Guardian': { earned: false, progress: 0 },
  'Mentor': { earned: false, progress: 3 },
  'Dizaines': { earned: false, progress: 4 },
  'Polyvalent': { earned: false, progress: 2 },
  'Parcours Complet': { earned: false, progress: 1 },
  'Membre Fidèle': { earned: false, progress: 12 },
  'Voie Dominante': { earned: false, progress: 1 },
}

export const badges: Badge[] = badgeSeeds.map(([name, description, track, rarity, xp, icon, rule, _earned, target], i) => {
  const state = badgeProgress[name] ?? { earned: false, progress: Math.max(0, target - 1) }
  const progress = state.earned ? target : Math.min(state.progress, Math.max(0, target - 1))
  return {
    code: `BDG-${String(i + 1).padStart(3, '0')}`,
    name,
    description,
    track,
    rarity,
    icon,
    xp,
    rule,
    earned: state.earned,
    earnedAt: state.earned ? iso(4 + i) : undefined,
    progress,
    target,
    evidence: state.earned ? 'Preuve validee par le Centre CODE212' : undefined,
  }
})

/* --------------------------------------------------------------- parcours */

export const paths: LearningPath[] = [
  {
    id: 1, slug: 'dev-web', title: 'Développement Web Full-Stack',
    description: 'Du HTML aux APIs sécurisées : 6 quêtes, un projet livrable, une certification.',
    track: 'codeur', level: 'intermediaire', quests: [1, 3, 8, 9], progress: 62, xpReward: 3200,
    estimatedHours: 14, enrolled: true, icon: '</>', gradient: 'violet',
    skills: ['React', 'Laravel', 'Git', 'TypeScript'],
  },
  {
    id: 2, slug: 'ia-data', title: 'IA & Data Science',
    description: 'Prompting, modèles, analyse de données et mise en production raisonnée.',
    track: 'codeur', level: 'avance', quests: [1, 4, 12], progress: 28, xpReward: 4100,
    estimatedHours: 18, enrolled: true, icon: '✦', gradient: 'magenta',
    skills: ['Prompt engineering', 'Pandas', 'Statistiques', 'Éthique'],
  },
  {
    id: 3, slug: 'cyber', title: 'Cybersécurité Offensive & Défensive',
    description: 'Comprendre l’attaque pour mieux défendre, dans un cadre éthique et encadré.',
    track: 'codeur', level: 'avance', quests: [2, 5], progress: 15, xpReward: 2800,
    estimatedHours: 12, enrolled: false, icon: '⌘', gradient: 'cyan',
    skills: ['OWASP', 'Analyse de logs', 'Docker', 'Durcissement'],
  },
  {
    id: 4, slug: 'devops', title: 'DevOps & Cloud',
    description: 'Pipelines, conteneurs, observabilité et déploiements reproductibles.',
    track: 'batisseur', level: 'avance', quests: [5, 3, 7], progress: 0, xpReward: 3600,
    estimatedHours: 16, enrolled: false, icon: '⚙', gradient: 'cyan',
    skills: ['Docker', 'CI/CD', 'Kubernetes', 'Observabilité'],
  },
  {
    id: 5, slug: 'leadership', title: 'Soft Skills & Leadership Tech',
    description: 'Mentorat, communication technique et leadership d’une équipe produit.',
    track: 'aidant', level: 'debutant', quests: [6, 9, 10], progress: 45, xpReward: 1900,
    estimatedHours: 8, enrolled: true, icon: '★', gradient: 'orange',
    skills: ['Mentorat', 'Communication', 'Gestion de projet', 'Veille'],
  },
]

/* ---------------------------------------------------------------- missions */

export const missions: Mission[] = [
  { id: 1, title: 'Quête de la semaine', description: 'Terminer 3 quêtes de n’importe quelle voie.', period: 'hebdomadaire', target: 3, progress: 2, xpReward: 250, germsReward: 20, claimed: false, expiresAt: iso(-3), icon: '◔' },
  { id: 2, title: 'Série de 5 jours', description: 'Te connecter 5 jours consécutifs cette semaine.', period: 'hebdomadaire', target: 5, progress: 5, xpReward: 180, germsReward: 15, claimed: false, expiresAt: iso(-3), icon: '🔥' },
  { id: 3, title: 'Aide un pair', description: 'Répondre à 2 questions dans La Forge.', period: 'hebdomadaire', target: 2, progress: 1, xpReward: 200, germsReward: 15, claimed: false, expiresAt: iso(-3), icon: '★' },
  { id: 4, title: 'Expertise mensuelle', description: 'Terminer 8 quêtes sur le mois.', period: 'mensuel', target: 8, progress: 5, xpReward: 600, germsReward: 50, claimed: false, expiresAt: iso(-14), icon: '⬢' },
  { id: 5, title: 'Communauté active', description: '10 contributions utiles (questions, réponses, veilles).', period: 'mensuel', target: 10, progress: 10, xpReward: 450, germsReward: 40, claimed: true, expiresAt: iso(-14), icon: '✺' },
]

/* -------------------------------------------------------------- challenges */

export const challenges: Challenge[] = [
  {
    id: 1, slug: 'ai-sprint-24h', title: 'AI Sprint 24H', description: '24 heures pour prototyper une solution IA utile à la vie étudiante.',
    category: 'Intelligence artificielle', mode: 'equipe', status: 'en_cours', difficulty: 'avance', xpReward: 1500,
    startsAt: iso(1, 8), endsAt: iso(-1, 8), participants: 148, maxParticipants: 200, prize: '2 000 germes + badge Hunter',
    joined: true, progress: 62, score: 740, teamName: 'Équipe Nova', track: 'codeur',
    rules: ['Équipe de 3 à 5 membres', 'Dépôt d’une démo de 3 minutes', 'Code ouvert exigé'],
  },
  {
    id: 2, slug: 'capture-the-flag', title: 'Capture The Flag', description: 'Le classique revisité : 6 catégories asynchrones, crypto et web.',
    category: 'Cybersécurité', mode: 'solo', status: 'en_cours', difficulty: 'expert', xpReward: 1200,
    startsAt: iso(3, 9), endsAt: iso(-2, 17), participants: 212, maxParticipants: 300, prize: 'Badge Cyber Guardian accéléré',
    joined: false, progress: 0, track: 'codeur',
    rules: ['Classement individuel pseudonymisé', 'Aucune triche, audit des logs', 'Durée 48h'],
  },
  {
    id: 3, slug: 'duel-algorithmes', title: 'Duel d’algorithmes', description: 'Duel en 1v1, 25 minutes, deux problèmes, un vainqueur.',
    category: 'Algorithmique', mode: 'duel', status: 'a_venir', difficulty: 'intermediaire', xpReward: 600,
    startsAt: iso(-2, 18), endsAt: iso(-4, 22), participants: 64, maxParticipants: 128, prize: '150 germes par victoire',
    joined: false, progress: 0, track: 'codeur',
    rules: ['Appariement par niveau', 'Victoire = +75 XP', 'Format best-of-3'],
  },
  {
    id: 4, slug: 'data-jam', title: 'Data Jam', description: '72h pour transformer un jeu de données ouvert en décision argumentée.',
    category: 'Data & Analytics', mode: 'equipe', status: 'a_venir', difficulty: 'intermediaire', xpReward: 1000,
    startsAt: iso(-5, 10), endsAt: iso(-8, 10), participants: 0, maxParticipants: 150, prize: 'Certification Data Literacy',
    joined: false, progress: 0, track: 'batisseur',
    rules: ['Datasets fournis par le centre', 'Pitch de 5 minutes', 'Code et données reproductibles'],
  },
  {
    id: 5, slug: 'code-review-cup', title: 'Code Review Cup', description: 'Relire le code des autres, améliorer le collectif.',
    category: 'Communauté', mode: 'solo', status: 'termine', difficulty: 'debutant', xpReward: 500,
    startsAt: iso(12, 9), endsAt: iso(5, 18), participants: 97, maxParticipants: 200, prize: 'Voie Aidant accélérée',
    joined: true, progress: 100, score: 920, track: 'aidant',
    rules: ['10 revues de qualité minimum', 'Notation par les pairs'],
  },
  {
    id: 6, slug: 'hack-uca-2026', title: 'Hack UCA 2026', description: 'Le hackathon inter-facultés : 48h, 5tracks, un podium.',
    category: 'Innovation', mode: 'equipe', status: 'a_venir', difficulty: 'expert', xpReward: 2500,
    startsAt: iso(-20, 9), endsAt: iso(-22, 18), participants: 0, maxParticipants: 400, prize: 'Sponsor + certification',
    joined: false, progress: 0, track: 'explorateur',
    rules: ['Inter-universités', 'Mentorat assuré par le centre', 'Pitch devant jury'],
  },
  {
    id: 7, slug: 'sql-marathon', title: 'SQL Marathon', description: '6hours pour battre le temps de résolution de requêtes.',
    category: 'Data & Analytics', mode: 'solo', status: 'termine', difficulty: 'intermediaire', xpReward: 700,
    startsAt: iso(20, 9), endsAt: iso(14, 15), participants: 133, maxParticipants: 200, prize: 'Badge Data Mind',
    joined: true, progress: 100, score: 1180, track: 'codeur',
    rules: ['6 manches de 45 minutes', 'Classement par temps moyen'],
  },
  {
    id: 8, slug: 'ui-challenge', title: 'UI Challenge', description: 'Reproduire et améliorer une interface, design system de Code212.',
    category: 'Design', mode: 'solo', status: 'en_cours', difficulty: 'intermediaire', xpReward: 800,
    startsAt: iso(2, 8), endsAt: iso(-3, 23), participants: 89, maxParticipants: 150, prize: 'Pack design (300 germes)',
    joined: false, progress: 0, track: 'batisseur',
    rules: ['Maquette + prototype fonctionnel', 'Évaluation design system'],
  },
]

/* --------------------------------------------------------------- classement */

const lbNames: Array<[string, string, string, number, number, number, number, LeaderboardEntry['trend']]> = [
  ['Omar Benali', 'O. Benali', 'Data science', 6240, 18, 12, 31, 'up'],
  ['Yasmine El Amrani', 'Yasmine', 'Génie informatique', 4820, 14, 9, 7, 'same'],
  ['Salma Tazi', 'S. Tazi', 'Réseaux & sécurité', 4390, 12, 11, 22, 'up'],
  ['Adam Berrada', 'A. Berrada', 'Génie logiciel', 3980, 9, 7, 5, 'down'],
  ['Nour Chraibi', 'N. Chraibi', 'Intelligence artificielle', 3620, 11, 8, 14, 'up'],
  ['Ilyas Mansouri', 'I. Mansouri', 'Data science', 3380, 7, 6, 9, 'same'],
  ['Hiba Ouazzani', 'H. Ouazzani', 'Génie informatique', 3140, 8, 5, 18, 'up'],
  ['Mehdi Zouiten', 'M. Zouiten', 'Cyber sécurité', 2980, 6, 6, 3, 'down'],
  ['Ghita Amrani', 'G. Amrani', 'Génie logiciel', 2760, 7, 4, 11, 'same'],
  ['Rachid El Idrissi', 'R. El Idrissi', 'Intelligence artificielle', 2540, 5, 5, 8, 'up'],
  ['Sofia Lemtouni', 'S. Lemtouni', 'Data science', 2380, 4, 4, 6, 'same'],
  ['Karim Bennani', 'K. Bennani', 'Réseaux & sécurité', 2210, 3, 3, 4, 'down'],
]

export const leaderboard: LeaderboardEntry[] = lbNames.map(([name, pseudo, program, xp, weekly, completed, streak, trend], i) => ({
  rank: i + 1,
  userId: 2,
  displayName: name,
  pseudonym: pseudo,
  program,
  level: xp >= 4500 ? 8 : xp >= 3600 ? 7 : xp >= 2700 ? 6 : xp >= 1800 ? 5 : xp >= 1100 ? 4 : 3,
  xp,
  weeklyXp: weekly * 120,
  questsCompleted: completed,
  streakDays: streak,
  isCurrentUser: name === 'Yasmine El Amrani',
  trend,
}))

/* ------------------------------------------------------------------ boutique */

export const rewards: Reward[] = [
  { id: 1, name: 'Avatar Néon', description: 'Avatar animé exclusif, visible partout sur la plateforme.', category: 'cosmetique', cost: 350, stock: 42, icon: '◈', gradient: 'violet', owned: 0 },
  { id: 2, name: 'Cadre de badge Or', description: 'Encadrement doré pour tes badgesvalidated.', category: 'cosmetique', cost: 500, stock: 18, icon: '❖', gradient: 'orange', limited: true, owned: 0 },
  { id: 3, name: 'Session mentor 1h', description: 'Une heure de mentorat individuel avec un formateur du centre.', category: 'mentorat', cost: 1200, stock: 8, icon: '★', gradient: 'magenta', limited: true, owned: 0 },
  { id: 4, name: 'Accès anticipé Labo IA', description: 'Accès prioritaire aux ateliers du laboratoire Intelligence Artificielle.', category: 'avantage', cost: 800, stock: 25, icon: '✦', gradient: 'cyan', owned: 0 },
  { id: 5, name: 'T-shirt Code212', description: 'Édition limitée du centre, taille M.', category: 'materiel', cost: 900, stock: 12, icon: '⬢', gradient: 'magenta', owned: 0 },
  { id: 6, name: 'Badge Orbital', description: 'Badge cosmétique animé, non transférable.', category: 'cosmetique', cost: 250, stock: 120, icon: '◎', gradient: 'cyan', owned: 0 },
  { id: 7, name: 'Visa examen blanc', description: 'Accès à une session d’examen blanc blanc.', category: 'avantage', cost: 600, stock: 30, icon: '❋', gradient: 'orange', owned: 0 },
  { id: 8, name: 'Clé USB Code212', description: 'Support de stockage 32 Go gravé au logo du centre.', category: 'materiel', cost: 450, stock: 0, icon: '⬡', gradient: 'violet', owned: 0 },
]

/* ---------------------------------------------------------------- La Forge */

export const forgeCategories: ForgeCategory[] = [
  { slug: 'entraide', name: 'Entraide', description: 'Posez une question, aidez un pair.', icon: '★', threads: 342, requiresApproval: false, moderatedBy: 'Salma Tazi' },
  { slug: 'projets', name: 'Projets', description: 'Montrez ce que vous construisez.', icon: '⬢', threads: 128, requiresApproval: false, moderatedBy: 'Dr. Karim Idrissi' },
  { slug: 'coding-league', name: 'Coding League', description: 'Annonces et résultats des compétitions.', icon: '⌘', threads: 64, requiresApproval: true, moderatedBy: 'Centre CODE212' },
  { slug: 'annonces', name: 'Annonces', description: 'Actualités du centre etubu sessions.', icon: '◈', threads: 41, requiresApproval: true, moderatedBy: 'Centre CODE212' },
  { slug: 'cafe', name: 'Café de la Forge', description: 'Conversations libres entre étudiants.', icon: '☕', threads: 217, requiresApproval: false, moderatedBy: 'Omar Benali' },
]

export const forgeThreads: ForgeThread[] = [
  {
    id: 1, category: 'entraide', title: 'Erreur TypeScript « Object is possibly undefined » dans un useEffect',
    body: 'Bonjour, je bloque sur un useEffect qui fetch un compte utilisateur. TypeScript me dit que user est possiblement undefined au moment du setState. Quelqu’un a une approche propre qui ne casse pas le rendu ?',
    authorId: 12, authorName: 'Adam Berrada', authorPseudonym: 'A. Berrada', authorRole: 'student',
    createdAt: iso(0, 9), replies: 7, views: 184, likes: 12, liked: false, solved: true, tags: ['typescript', 'react'], solutionIds: [1, 2],
    pinned: true,
  },
  {
    id: 2, category: 'projets', title: 'MediTrack — suivi des patients pour les stages cliniques',
    body: 'Je développe une application de suivi pour mon stage à l’hôpital. J’ai un prototype Laravel + Vue, jinterested par des retours sur le modèle de données.',
    authorId: 15, authorName: 'Ghita Amrani', authorPseudonym: 'G. Amrani', authorRole: 'student',
    createdAt: iso(1, 14), replies: 4, views: 96, likes: 8, liked: true, solved: false, tags: ['laravel', 'projet'], solutionIds: [],
  },
  {
    id: 3, category: 'coding-league', title: 'Inscriptions Coding League 2026 — dernière semaine',
    body: 'Les inscriptions pour la ligue de coding closes samedi. Les équipes de 3 sont prioritaires sur les individuelles cette année.',
    authorId: 3, authorName: 'Centre CODE212', authorPseudonym: 'Équipe CODE212', authorRole: 'admin',
    createdAt: iso(2, 10), replies: 21, views: 612, likes: 47, liked: false, solved: false, tags: ['annonce', 'compétition'], solutionIds: [], pinned: true,
  },
  {
    id: 4, category: 'entraide', title: 'Conteneur Docker qui sort en OOM sur le build Vite',
    body: 'Mon build Vite dépasse la mémoire sur une machine 4 Go. J’ai déjà essayé NODE_OPTIONS mais ça ne suffit pas sur les gros bundles.',
    authorId: 18, authorName: 'Rachid El Idrissi', authorPseudonym: 'R. El Idrissi', authorRole: 'student',
    createdAt: iso(3, 11), replies: 11, views: 305, likes: 19, liked: false, solved: true, tags: ['docker', 'vite'], solutionIds: [3],
  },
  {
    id: 5, category: 'cafe', title: 'Quelqu’un a déjà travaillé chez un éditeur de jeux à Casablanca ?',
    body: 'Je prépare mon stage de fin d’études et je suis curieux de savoir comment se passe une candidature dans ce secteur.',
    authorId: 21, authorName: 'Sofia Lemtouni', authorPseudonym: 'S. Lemtouni', authorRole: 'student',
    createdAt: iso(4, 17), replies: 9, views: 141, likes: 15, liked: false, solved: false, tags: ['carrière', 'stage'],
  } as unknown as ForgeThread,
  {
    id: 6, category: 'projets', title: 'Retour sur mon portfolio : je cherche un avis brutal',
    body: 'J’ai refait mon portfolio en React et Tailwind. Je cherche des retours francs, surtout sur la hiérarchie visuelle et les projets mis en avant.',
    authorId: 22, authorName: 'Karim Bennani', authorPseudonym: 'K. Bennani', authorRole: 'student',
    createdAt: iso(6, 13), replies: 14, views: 268, likes: 22, liked: false, solved: false, tags: ['portfolio', 'design'], solutionIds: [],
  },
]

export const forgeSolutions: ForgeSolution[] = [
  {
    id: 1, threadId: 1, authorId: 9, authorName: 'Omar Benali', authorPseudonym: 'O. Benali',
    body: 'Le plus simple : tu remontes l’état de chargement avant d’accéder à user.\n\n```ts\nconst [user, setUser] = useState<User | null>(null)\nuseEffect(() => {\n  let alive = true\n  fetch("/api/me").then(r => r.json()).then(d => alive && setUser(d))\n  return () => { alive = false }\n}, [])\n```\n\nLe flag `alive` évite aussi le setState après unmount.',
    accepted: true, acceptedAt: iso(0, 11), createdAt: iso(0, 10), likes: 24, mine: false,
  },
  {
    id: 2, threadId: 1, authorId: 12, authorName: 'Adam Berrada', authorPseudonym: 'A. Berrada',
    body: 'Tu peux aussi discriminer le union : `if (!data) return` avant le setState.',
    accepted: false, createdAt: iso(0, 10), likes: 6, mine: true,
  },
  {
    id: 3, threadId: 4, authorId: 3, authorName: 'Dr. Karim Idrissi', authorPseudonym: 'K. Idrissi',
    body: 'Construisez l’image avec `--memory=2g` et montez le cache npm. Le build multi-stage sans les devDependencies réduit l’empreinte de moitié.',
    accepted: true, acceptedAt: iso(3, 15), createdAt: iso(3, 13), likes: 18, mine: false,
  },
]

/* -------------------------------------------------------------- certifications */

export const certifications: Certification[] = [
  {
    id: 1, code: 'C212-AI-2026-0842', title: 'AI & Prompt Engineering', issuer: 'Code212 · Intelligence artificielle',
    track: 'codeur', issuedAt: iso(12), status: 'obtenue', progress: 100, signed: false,
    criteria: ['3 quêtes validées', 'Quiz final ≥ 80 %', 'Livrable évalué par un formateur'],
    skills: ['Prompting', 'Évaluation LLM', 'Documentation'],
  },
  {
    id: 2, code: 'C212-WD-2026-0618', title: 'Web Development Essentials', issuer: 'Code212 · Développement',
    track: 'codeur', issuedAt: iso(44), status: 'obtenue', progress: 100, signed: false,
    criteria: ['5 quêtes validées', 'Projet fil rouge rendu', 'Revue de code par les pairs'],
    skills: ['React', 'Laravel', 'Git'],
  },
  {
    id: 3, code: 'C212-DATA-2026-0121', title: 'Data Literacy Foundations', issuer: 'Code212 · Data & Analytics',
    track: 'batisseur', issuedAt: iso(70), status: 'en_cours', progress: 70, signed: false,
    criteria: ['3 quêtes validées', 'Analyse documentée', 'Quiz final ≥ 70 %'],
    skills: ['Statistiques', 'Visualisation', 'Pandas'],
  },
  {
    id: 4, code: 'C212-CYB-2026-0093', title: 'Cyber Security Awareness', issuer: 'Code212 · Cybersécurité',
    track: 'codeur', issuedAt: iso(95), status: 'expiree', progress: 100, signed: false,
    criteria: ['2 quêtes validées', 'Quiz final ≥ 80 %'],
    skills: ['OWASP', 'Analyse de logs'],
  },
]

/* --------------------------------------------------------- rules & submissions */

export const xpRules: XpRule[] = [
  { id: 1, code: 'quest.complete', label: 'Quête terminée', description: 'Récompense à la validation d’une quête par un formateur.', xp: 450, dailyCap: 1500, track: null, active: true, version: 3, category: 'quetes' },
  { id: 2, code: 'quest.step', label: 'Étape validée', description: 'Bonus par étape validée dans une quête en cours.', xp: 80, dailyCap: 800, track: null, active: true, version: 2, category: 'quetes' },
  { id: 3, code: 'quest.hard', label: 'Quête difficile', description: 'Bonus de difficulté : +50 % de la récompense.', xp: 220, dailyCap: 600, track: null, active: true, version: 1, category: 'quetes' },
  { id: 4, code: 'forge.answer', label: 'Réponse acceptée', description: 'Rémunération d’une réponse validée par l’auteur du fil.', xp: 40, dailyCap: 200, track: 'aidant', active: true, version: 4, category: 'communaute' },
  { id: 5, code: 'forge.question', label: 'Question publiée', description: 'Question utile publiée dans La Forge.', xp: 20, dailyCap: 100, track: 'aidant', active: true, version: 2, category: 'communaute' },
  { id: 6, code: 'forge.answer.accepted', label: 'Solution acceptée', description: 'Palier supérieur pour une solution acceptée.', xp: 120, dailyCap: 300, track: 'aidant', active: true, version: 1, category: 'communaute' },
  { id: 7, code: 'presence.checkin', label: 'Présence validée', description: 'Session de présence validée (source Libki à confirmer).', xp: 50, dailyCap: 100, track: null, active: false, version: 1, category: 'presence' },
  { id: 8, code: 'event.participation', label: 'Participation à un événement', description: 'Participation à un événement Code212 ou Coding League.', xp: 80, dailyCap: 200, track: null, active: true, version: 1, category: 'evenement' },
  { id: 9, code: 'streak.weekly', label: 'Série hebdomadaire', description: 'Bonus de 7 jours consécutifs.', xp: 150, dailyCap: 150, track: null, active: true, version: 2, category: 'evenement' },
  { id: 10, code: 'penalty.inactivity', label: 'Malus d’inactivité', description: 'Pénalité pour inactivité prolongée (suspendu : aucune sanction automatique).', xp: -50, dailyCap: 0, track: null, active: false, version: 1, category: 'penalite' },
]

export const submissions: Submission[] = [
  {
    id: 1, questId: 3, questTitle: 'Build a REST API', studentId: 12, studentName: 'Adam Berrada', studentPseudonym: 'A. Berrada',
    stepId: 2, stepTitle: 'Implémentation Laravel', content: 'Dépôt du dépôt Git du projet fil rouge, tests Pest inclus.',
    status: 'en_attente', submittedAt: iso(0, 9), xpAwarded: 0,
  },
  {
    id: 2, questId: 4, questTitle: 'Data Detective', studentId: 21, studentName: 'Sofia Lemtouni', studentPseudonym: 'S. Lemtouni',
    stepId: 3, stepTitle: 'Visualisation & storytelling', content: 'Analyse du jeu de données Mobilités 2025.',
    status: 'en_attente', submittedAt: iso(1, 16), xpAwarded: 0,
  },
  {
    id: 3, questId: 1, questTitle: 'AI Prompt Engineering', studentId: 15, studentName: 'Ghita Amrani', studentPseudonym: 'G. Amrani',
    stepId: 4, stepTitle: 'Livrable : bibliothèque de prompts', content: 'Bibliothèque de 5 prompts documentés.',
    status: 'validee', submittedAt: iso(4, 11), reviewedAt: iso(4, 15), reviewerName: 'Dr. Salma Bennani', xpAwarded: 130,
  },
  {
    id: 4, questId: 11, questTitle: 'Projet fil rouge', studentId: 18, studentName: 'Rachid El Idrissi', studentPseudonym: 'R. El Idrissi',
    stepId: 3, stepTitle: 'Défense devant jury', content: 'Soutenance recorded — 12 min.',
    status: 'en_attente', submittedAt: iso(0, 8), xpAwarded: 0,
  },
]

export const rewardOrders: RewardOrder[] = [
  { id: 1, userId: 12, userName: 'Adam Berrada', rewardId: 5, rewardName: 'T-shirt Code212', quantity: 1, total: 900, status: 'en_attente', createdAt: iso(1, 12) },
  { id: 2, userId: 21, userName: 'Sofia Lemtouni', rewardId: 3, rewardName: 'Session mentor 1h', quantity: 1, total: 1200, status: 'en_attente', createdAt: iso(2, 10) },
  { id: 3, userId: 15, userName: 'Ghita Amrani', rewardId: 1, rewardName: 'Avatar Néon', quantity: 1, total: 350, status: 'approuvee', createdAt: iso(5, 9) },
  { id: 4, userId: 9, userName: 'Omar Benali', rewardId: 6, rewardName: 'Badge Orbital', quantity: 2, total: 500, status: 'livree', createdAt: iso(8, 14) },
]

/* --------------------------------------------------------------- profil actif */

export const currentUser = {
  id: 2,
  firstName: 'Yasmine',
  lastName: 'El Amrani',
  displayName: 'Yasmine El Amrani',
  pseudonym: 'Yasmine',
  email: 'y.elamrani@uca.ac.ma',
  studentCode: 'UCA-2024-GI-1842',
  program: 'Génie informatique',
  cohort: '2024 · Promotion 2',
  roles: ['student'] as const,
  level: 8,
  levelTitle: 'Architecte',
  xp: 4820,
  germs: 640,
  streakDays: 7,
  bestStreak: 12,
  questsCompleted: 9,
  questsInProgress: 3,
  badgesEarned: 8,
  competitionOptIn: true,
  pseudonymized: false,
  weeklyGoalXp: 3000,
  weeklyXp: 2620,
  joinedAt: '2025-09-08T09:00:00.000Z',
}

export const weeklyActivity = [
  { day: 'Lun', xp: 220, label: 'Lundi' },
  { day: 'Mar', xp: 340, label: 'Mardi' },
  { day: 'Mer', xp: 280, label: 'Mercredi' },
  { day: 'Jeu', xp: 460, label: 'Jeudi' },
  { day: 'Ven', xp: 390, label: 'Vendredi' },
  { day: 'Sam', xp: 520, label: 'Samedi' },
  { day: 'Dim', xp: 410, label: 'Dimanche' },
]

export const engagement = [
  { day: '11 nov.', active: 320, completed: 180, label: 'Mar. 11' },
  { day: '12 nov.', active: 410, completed: 240, label: 'Mer. 12' },
  { day: '13 nov.', active: 360, completed: 210, label: 'Jeu. 13' },
  { day: '14 nov.', active: 520, completed: 320, label: 'Ven. 14' },
  { day: '15 nov.', active: 480, completed: 290, label: 'Sam. 15' },
  { day: '16 nov.', active: 610, completed: 390, label: 'Dim. 16' },
  { day: '17 nov.', active: 690, completed: 430, label: 'Lun. 17' },
]

export const trackDistribution = [
  { track: 'codeur' as TrackCode, name: 'Codeur', points: 18420, students: 1240, color: '#6701e6' },
  { track: 'aidant' as TrackCode, name: 'Aidant', points: 9860, students: 862, color: '#c5027f' },
  { track: 'batisseur' as TrackCode, name: 'Bâtisseur', points: 7340, students: 604, color: '#00b8d4' },
  { track: 'explorateur' as TrackCode, name: 'Explorateur', points: 5210, students: 431, color: '#f59e0b' },
]

export const adminOverview: AdminOverview = {
  kpis: {
    students: 2486, studentsDelta: 12.8,
    activeQuests: 18, questsDelta: 3,
    completionRate: 68.7, completionDelta: 4.1,
    xpDistributed: 1240000, xpDelta: 16.3,
    pendingSubmissions: submissions.filter((s) => s.status === 'en_attente').length,
    moderationQueue: 4,
    avgSessionMinutes: 228,
  },
  engagement,
  topQuests: [
    { id: 9, title: 'Git & Collaboration', participants: 143, completionRate: 79, xp: 380 },
    { id: 1, title: 'AI Prompt Engineering', participants: 128, completionRate: 68, xp: 450 },
    { id: 4, title: 'Data Detective', participants: 94, completionRate: 61, xp: 600 },
    { id: 2, title: 'Cybersecurity Sprint', participants: 86, completionRate: 54, xp: 700 },
  ],
  trackDistribution,
  pendingSubmissions: submissions.filter((s) => s.status === 'en_attente'),
  recentOrders: rewardOrders,
  moderationQueue: [
    { id: 1, type: 'discussion', title: 'Conteneur Docker qui sort en OOM', reason: 'Hors sujet / contenu non vérifié', reporter: 'Ilyas Mansouri', createdAt: iso(0, 12) },
    { id: 2, type: 'solution', title: 'Suggestion de contournement non vérifiée', reason: 'Risque sécurité', reporter: 'Modération auto', createdAt: iso(1, 9) },
    { id: 3, type: 'discussion', title: 'Annonce de coursIER payante', reason: 'Publicité / lien externe', reporter: 'Nour Chraibi', createdAt: iso(2, 15) },
    { id: 4, type: 'discussion', title: 'Comparaison de frameworks', reason: 'Discussion hors charte', reporter: 'Sofia Lemtouni', createdAt: iso(3, 11) },
  ],
}

/* ============================================ gestion des rôles et accès */

export const slugify = (value: string) =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')

type ManagedUserSeed = [
  firstName: string,
  lastName: string,
  program: string,
  school: string,
  level: number,
  xp: number,
  quests: number,
  status: ManagedUser['status'],
  daysAgo: number,
  lastSeenDaysAgo: number,
]

const userSeeds: ManagedUserSeed[] = [
  ['Mehdi', 'Zouiten', 'Cyber sécurité', 'FSM', 9, 6820, 71, 'Actif', 720, 0],
  ['Yasmine', 'El Amrani', 'Génie informatique', 'FST', 8, 5240, 63, 'Actif', 690, 0],
  ['Omar', 'Benali', 'Data science', 'ENSAM', 8, 4980, 58, 'Actif', 660, 1],
  ['Salma', 'Tazi', 'Réseaux & sécurité', 'ENI', 7, 4710, 52, 'Actif', 640, 2],
  ['Adam', 'Berrada', 'Génie logiciel', 'EST', 7, 4180, 47, 'Actif', 610, 3],
  ['Nour', 'Chraibi', 'Intelligence artificielle', 'FSM', 7, 3960, 44, 'Actif', 580, 1],
  ['Hiba', 'Ouazzani', 'Génie informatique', 'FST', 6, 3620, 41, 'Actif', 540, 5],
  ['Ilyas', 'Mansouri', 'Data science', 'ENSAM', 6, 3480, 38, 'Actif', 520, 4],
  ['Mehdi', 'Alaoui', 'Mathématiques appliquées', 'FSM', 5, 2940, 31, 'En attente', 40, 12],
  ['Ghita', 'Amrani', 'Génie logiciel', 'ENA', 6, 2860, 29, 'Actif', 500, 2],
  ['Rachid', 'El Idrissi', 'Intelligence artificielle', 'ENI', 6, 2640, 27, 'Actif', 480, 6],
  ['Sofia', 'Lemtouni', 'Data science', 'EST', 5, 2450, 25, 'Actif', 460, 3],
  ['Karim', 'Bennani', 'Réseaux & sécurité', 'FSM', 5, 2310, 24, 'Actif', 440, 9],
  ['Aya', 'Nassiri', 'Génie informatique', 'FST', 5, 2180, 22, 'Actif', 420, 1],
  ['Anas', 'Bouzid', 'Génie civil', 'ENSAM', 4, 1860, 19, 'Inactif', 390, 26],
  ['Leïla', 'Fkih', 'Data science', 'FSM', 4, 1740, 17, 'Actif', 360, 4],
  ['Hamza', 'Ouali', 'Réseaux & sécurité', 'ENI', 4, 1620, 16, 'Actif', 340, 7],
  ['Sanaa', 'Kettani', 'Génie logiciel', 'EST', 4, 1490, 14, 'Actif', 300, 2],
  ['Youssef', 'Riahi', 'Intelligence artificielle', 'ENA', 3, 1120, 11, 'Actif', 280, 11],
  ['Meryem', 'Alaoui', 'Mathématiques appliquées', 'FSM', 3, 980, 9, 'Actif', 260, 5],
  ['Adil', 'Sabri', 'Cyber sécurité', 'FST', 3, 860, 8, 'En attente', 120, 20],
  ['Nabila', 'Cherkaoui', 'Data science', 'ENSAM', 3, 740, 6, 'Actif', 200, 8],
  ['Tarik', 'Bennis', 'Génie informatique', 'ENI', 2, 430, 4, 'Actif', 180, 3],
  ['Loubna', 'Filali', 'Génie logiciel', 'EST', 2, 320, 3, 'Inactif', 160, 34],
  ['Ali', 'Sekkat', 'Réseaux & sécurité', 'FSM', 2, 260, 2, 'Suspendu', 150, 21],
  ['Souhail', 'Amine', 'Data science', 'FSM', 1, 90, 1, 'Actif', 45, 1],
]

const PERMISSION_KEYS_BY_MODULE = Object.fromEntries(
  PERMISSION_MODULES.map((m) => [m.code, m.permissions.map((p) => p.key)]),
)

/** Rôles système : permissions figées, issues du catalogue `SYSTEM_ROLES`. */
const systemRoleRows = SYSTEM_ROLES.map((seed, index) => ({
  id: index + 1,
  code: seed.code,
  name: seed.name,
  description: seed.description,
  color: seed.color,
  isSystem: true,
  permissions:
    seed.permissions === '*'
      ? PERMISSION_MODULES.flatMap((m) => m.permissions.map((p) => p.key))
      : seed.permissions,
  memberCount: 0,
  createdBy: 'Système',
  createdAt: iso(400 - index * 10),
  revokedAt: null,
  scope: 'global' as const,
}))

/** Rôles personnalisés de démonstration. */
const customRoleRows = [
  {
    id: 7,
    code: 'referent_data',
    name: 'Référent Data & IA',
    description: 'Pilote le parcours Data et IA, prépare les quiz de positionnement et encadre les mentors.',
    color: '#00b8d4',
    isSystem: false,
    permissions: [
      ...PERMISSION_KEYS_BY_MODULE.quests.filter((k) => k !== 'quests.delete'),
      ...PERMISSION_KEYS_BY_MODULE.placement,
      ...PERMISSION_KEYS_BY_MODULE.mentorship,
    ],
    memberCount: 0,
    createdBy: 'Mehdi Zouiten',
    createdAt: iso(96),
    revokedAt: null,
    scope: 'global' as const,
  },
  {
    id: 8,
    code: 'ambassador_forge',
    name: 'Ambassadeur de la Forge',
    description: 'Relève la communauté : premier rempart de la modération, relais des annonces officielles.',
    color: '#f59e0b',
    isSystem: false,
    permissions: [
      'moderation.reports.read',
      'quests.read',
      'paths.read',
      'arena.read',
      'missions.read',
    ],
    memberCount: 0,
    createdBy: 'Mehdi Zouiten',
    createdAt: iso(41),
    revokedAt: null,
    scope: 'global' as const,
  },
]

/** Rôle à périmètre : la modération se joue par rubrique de La Forge. */
const moderatorRoleRow = {
  id: 9,
  code: 'moderator',
  name: 'Modérateur (La Forge)',
  description: 'Périmètre de modération par rubrique. Aucun accès global : la portée est limitée aux sections confiées.',
  color: '#64748b',
  isSystem: true,
  permissions: [] as string[],
  memberCount: 0,
  createdBy: 'Système',
  createdAt: iso(400),
  revokedAt: null,
  scope: 'forge' as const,
}

export const managedRoles: Role[] = [...systemRoleRows, ...customRoleRows, moderatorRoleRow].map((role) => ({
  ...role,
  permissions: role.permissions,
}))

export const managedUsers: ManagedUser[] = userSeeds.map(
  ([firstName, lastName, program, school, level, xp, quests, status, daysAgo, lastSeen], index) => {
    const email = `${slugify(firstName)}.${slugify(lastName)}@uca.ac.ma`
    return {
      id: 101 + index,
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
      email: `${slugify(firstName)}.${slugify(lastName)}@mail.uca.ma`,
      academicEmail: email,
      studentCode: `212-${String(2400 + index * 7).padStart(5, '0')}`,
      program,
      school,
      level,
      xp,
      questsCompleted: quests,
      status,
      joinedAt: iso(daysAgo),
      lastActiveAt: iso(lastSeen, 19),
      roleCodes: [],
      roleNames: [],
      isModerator: false,
      moderatedSections: [],
    }
  },
)

/* --- affectations de rôles ------------------------------------------------ */

type AssignmentSeed = [
  userIndex: number,
  roleCode: string,
  grantedBy: string,
  daysAgo: number,
  reason: string,
  expiresInDays: number | null,
]

const assignmentSeeds: AssignmentSeed[] = [
  [0, 'admin', 'Système', 700, 'Nomination initiale de la Direction du centre.', null],
  [1, 'mentor', 'Mehdi Zouiten', 320, 'Mentor référent du parcours Génie informatique.', null],
  [2, 'coding_league', 'Mehdi Zouiten', 240, 'Pilote la Coding League 2026.', null],
  [3, 'evaluator', 'Yasmine El Amrani', 210, 'Évalue les livrables du module Réseaux.', null],
  [4, 'quest_creator', 'Mehdi Zouiten', 180, 'Conçoit les quêtes d’introduction.', null],
  [5, 'referent_data', 'Mehdi Zouiten', 90, 'Référent du parcours Data.', null],
  [6, 'question_bank', 'Omar Benali', 75, 'Prépare les quiz de positionnement.', null],
  [7, 'ambassador_forge', 'Mehdi Zouiten', 38, 'Relais de la Forge sur les forums.', 120],
]

export const roleAssignments: RoleAssignment[] = assignmentSeeds.map(
  ([userIndex, roleCode, grantedBy, daysAgo, reason, expiresInDays], index) => {
    const user = managedUsers[userIndex]
    const role = managedRoles.find((r) => r.code === roleCode)!
    return {
      id: 301 + index,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.academicEmail,
      roleId: role.id,
      roleCode: role.code,
      roleName: role.name,
      roleColor: role.color,
      grantedBy,
      grantedAt: iso(daysAgo, 11),
      expiresAt: expiresInDays === null ? null : iso(-expiresInDays, 11),
      reason,
    }
  },
)

/* --- modérateurs de La Forge ---------------------------------------------- */

type ModeratorSeed = [
  userIndex: number,
  sections: string[],
  grantedBy: string,
  daysAgo: number,
  note: string,
  expiresInDays: number | null,
]

const moderatorSeeds: ModeratorSeed[] = [
  [9, ['entraide', 'cafe'], 'Mehdi Zouiten', 150, 'Répond aux questions d’entraide depuis septembre.', 60],
  [10, ['coding-league', 'projets'], 'Omar Benali', 120, 'Anime les discussions Coding League.', 30],
  [11, ['entraide'], 'Yasmine El Amrani', 88, 'Relais des questions bloquées.', null],
  [12, ['annonces'], 'Mehdi Zouiten', 200, 'Publie les annonces officielles.', -12],
]

export const moderatorAssignments: ModeratorAssignment[] = moderatorSeeds.map(
  ([userIndex, sections, grantedBy, daysAgo, note, expiresInDays], index) => {
    const user = managedUsers[userIndex]
    return {
      id: 401 + index,
      userId: user.id,
      userName: user.fullName,
      userEmail: user.academicEmail,
      sections,
      grantedBy,
      grantedAt: iso(daysAgo, 9),
      expiresAt: expiresInDays === null ? null : iso(-expiresInDays, 9),
      note,
      revokedAt: null,
    }
  },
)

/* --- journal d'audit ------------------------------------------------------ */

export const roleAudit: RoleAuditEvent[] = [
  { id: 501, action: 'role_assigned', target: 'Omar Benali', detail: 'Rôle « Responsable Coding League » attribué.', actor: 'Mehdi Zouiten', createdAt: iso(0, 8) },
  { id: 502, action: 'moderator_assigned', target: 'Ghita Amrani', detail: 'Modération des rubriques Entraide et Café de la Forge.', actor: 'Mehdi Zouiten', createdAt: iso(1, 15) },
  { id: 503, action: 'role_updated', target: 'Ambassadeur de la Forge', detail: 'Permission « moderation.reports.read » ajoutée.', actor: 'Mehdi Zouiten', createdAt: iso(3, 17) },
  { id: 504, action: 'role_created', target: 'Référent Data & IA', detail: 'Rôle personnalisé créé avec 12 permissions.', actor: 'Mehdi Zouiten', createdAt: iso(38, 14) },
  { id: 505, action: 'moderator_revoked', target: 'Karim Bennani', detail: 'Périmètre « Annonces » révoqué.', actor: 'Mehdi Zouiten', createdAt: iso(11, 10) },
  { id: 506, action: 'role_assigned', target: 'Hiba Ouazzani', detail: 'Rôle « Gestionnaire de la banque de questions » attribué.', actor: 'Omar Benali', createdAt: iso(12, 13) },
  { id: 507, action: 'role_revoked', target: 'Évaluateur externe', detail: 'Rôle temporaire révoqué en fin de session d’évaluation.', actor: 'Yasmine El Amrani', createdAt: iso(22, 16) },
  { id: 508, action: 'role_assigned', target: 'Salma Tazi', detail: 'Rôle « Évaluateur » attribué.', actor: 'Yasmine El Amrani', createdAt: iso(26, 11) },
]

/* --- cohérence des vues (rôles effectifs, modérateurs, compteurs) --------- */

managedRoles.forEach((role) => {
  role.memberCount =
    role.code === 'moderator'
      ? moderatorAssignments.filter((m) => !m.revokedAt).length
      : roleAssignments.filter((a) => a.roleCode === role.code).length
})

managedUsers.forEach((user) => {
  const assignments = roleAssignments.filter((a) => a.userId === user.id)
  user.roleCodes = assignments.map((a) => a.roleCode)
  user.roleNames = assignments.map((a) => a.roleName)
  const moderation = moderatorAssignments.filter((m) => m.userId === user.id && !m.revokedAt)
  user.isModerator = moderation.length > 0
  user.moderatedSections = [...new Set(moderation.flatMap((m) => m.sections))]
})

/* =================================================== espace modération */

import { FORGE_SECTIONS } from '@/lib/permissions'
import { APPEAL_PATH } from '@/lib/moderation'

/** Identité du modérateur de démonstration (rubriques : entraide, cafe). */
export const currentModerator = {
  id: 109,
  name: 'Ghita Amrani',
  pseudonym: 'GhitaCode',
  sections: ['entraide', 'cafe'],
  since: iso(150),
}

type ReportSeed = [
  id: number,
  targetType: 'discussion' | 'solution',
  title: string,
  excerpt: string,
  section: string,
  authorId: number,
  motif: ModerationMotif,
  reason: string,
  severity: ModerationSeverity,
  status: ModerationReportStatus,
  daysAgo: number,
  reportCount: number,
]

const reportSeeds: ReportSeed[] = [
  [701, 'discussion', 'Pourquoi personne ne répond aux messages ?', 'Je pose la question depuis trois jours, on est 40 dans le fil et personne ne répond…', 'entraide', 112, 'hors_sujet', 'Le fil ne répond pas à la question annoncée et accumule des messages hors sujet.', 'faible', 'ouverte', 1, 1],
  [702, 'solution', 'Solution proposée sans indentation', 'Voici mon code, ça marche pas…', 'entraide', 118, 'contenu_inapproprie', 'La réponse contient du contenu choquant dans les captures d’écran.', 'moyenne', 'ouverte', 2, 1],
  [703, 'discussion', 'Offre deildeveloppeur freelance', 'Je propose mes services, MP pour le portfolio.', 'cafe', 121, 'spam', 'Publicité non sollicitée répétée dans plusieurs rubriques.', 'faible', 'ouverte', 3, 4],
  [704, 'solution', 'Contestation de mon résultat', 'C’est pas moi qui ai triché, c’est le prof.', 'coding-league', 115, 'haine', 'Accusation nominative envers un enseignant.', 'critique', 'ouverte', 3, 2],
  [705, 'discussion', 'Raccourcis vs tableaux', 'Tu utilises quoi pour tes tables de hachage ?', 'entraide', 119, 'autre', 'Contenu litigieux, le ton est monté mais sans règle enfreinte.', 'faible', 'ouverte', 4, 1],
  [706, 'discussion', 'Groupe de studygram', 'Rejoignez notre groupe Telegram, 200 members.', 'projets', 122, 'spam', 'Recrutement externe massif dans la rubrique projets.', 'faible', 'ouverte', 5, 3],
  [707, 'solution', 'Je résous l’exercice 4', 'Voici la correction complète', 'projets', 117, 'fraude', 'Partage d’une correction d’exercice évaluation.', 'elevee', 'ouverte', 6, 2],
  [708, 'discussion', 'Le prof a favoritisme', 'C’est évident, il note ses potes.', 'cafe', 123, 'haine', 'Accusation générale de favoritisme, sans nom.', 'elevee', 'en_traitement', 2, 5],
  [709, 'solution', 'Réponse avec insultes', 'T’es vraiment nul en algo', 'entraide', 124, 'harcelement', 'Insulte directe envers un autre apprenant.', 'elevee', 'en_traitement', 1, 2],
  [710, 'discussion', 'Annonce de l’atelier', 'Atelier Python samedi à 10h', 'annonces', 116, 'autre', 'Signalement abusif pour vérifier le doublon avec l’annonce officielle.', 'faible', 'resolue', 9, 1],
  [711, 'solution', 'Correction de l’exercice 2', 'Voici une correction possible', 'projets', 113, 'fraude', 'Correction publiée après la date de l’exercice.', 'elevee', 'resolue', 12, 1],
  [712, 'discussion', 'Merci pour l’aide', 'C’était exactement ça, merci !', 'entraide', 120, 'autre', 'Signalement abusif : message de remerciement, rien à voir.', 'faible', 'rejetee', 14, 1],
  [713, 'discussion', 'Problème de compilation', 'Je n’arrive pas à compiler', 'entraide', 125, 'hors_sujet', 'Fil sans rapport avec la rubrique, relancé par erreur.', 'faible', 'escaladee', 8, 2],
]

const authorNames: Record<number, [string, string]> = {
  112: ['Mehdi Alaoui', 'MehdiCode'],
  113: ['Aya Nassiri', 'AyaNS'],
  115: ['Rachid El Idrissi', 'RachidIA'],
  116: ['Sofia Lemtouni', 'SofiaData'],
  117: ['Karim Bennani', 'KarimSec'],
  118: ['Tarik Bennis', 'TarikB'],
  119: ['Loubna Filali', 'LoubnaF'],
  120: ['Nabila Cherkaoui', 'NabilaC'],
  121: ['Sanaa Kettani', 'SanaaK'],
  122: ['Ali Sekkat', 'AliS'],
  123: ['Souhail Amine', 'SouhailA'],
  124: ['Adil Sabri', 'AdilSa'],
  125: ['Hamza Ouali', 'HamzaO'],
}

const reporterNames: Record<number, string> = {
  112: 'Yasmine El Amrani',
  118: 'Yasmine El Amrani',
  121: 'Omar Benali',
  115: 'Hiba Ouazzani',
  119: 'Nour Chraibi',
  122: 'Adam Berrada',
  117: 'Mehdi Zouiten',
  116: 'Mehdi Zouiten',
  113: 'Salma Tazi',
  120: 'Yasmine El Amrani',
  125: 'Ilyas Mansouri',
}

export const moderationReports: ModerationReport[] = reportSeeds.map(
  ([id, targetType, title, excerpt, section, authorId, motif, reason, severity, status, daysAgo, reportCount]) => {
    const [authorName, authorPseudonym] = authorNames[authorId] ?? ['Apprenant', 'Pseudo']
    const reporterName = reporterNames[authorId] ?? 'Membre de la communauté'
    return {
      id,
      targetType,
      targetId: 900 + id,
      title,
      excerpt,
      section,
      authorId,
      authorName,
      authorPseudonym,
      reporterId: 0,
      reporterName,
      motif,
      reason,
      severity,
      status,
      createdAt: iso(daysAgo, 9 + (id % 8)),
      reportCount,
    }
  },
)

export const reportedUsers: ReportedUser[] = [
  { id: 121, fullName: 'Sanaa Kettani', pseudonym: 'SanaaK', email: 'sanaa.kettani@uca.ac.ma', program: 'Génie logiciel', school: 'EST', reportsReceived: 9, contentHidden: 4, warnings: 2, temporaryBans: 2, permanentBans: 0, riskLevel: 'critique', status: 'banni_temporaire', lastActivityAt: iso(1, 22), firstReportedAt: iso(96), topMotifs: [{ motif: 'spam', count: 6 }, { motif: 'hors_sujet', count: 3 }], notes: 'Publication commerciale répétée dans trois rubriques différentes.' },
  { id: 123, fullName: 'Souhail Amine', pseudonym: 'SouhailA', email: 'souhail.amine@uca.ac.ma', program: 'Data science', school: 'FSM', reportsReceived: 7, contentHidden: 3, warnings: 1, temporaryBans: 1, permanentBans: 0, riskLevel: 'eleve', status: 'surveille', lastActivityAt: iso(2, 19), firstReportedAt: iso(41), topMotifs: [{ motif: 'haine', count: 4 }, { motif: 'harcelement', count: 3 }], notes: 'Accusations nominatives envers l’encadrement, deux avertissements.' },
  { id: 117, fullName: 'Karim Bennani', pseudonym: 'KarimSec', email: 'karim.bennani@uca.ac.ma', program: 'Réseaux & sécurité', school: 'FSM', reportsReceived: 5, contentHidden: 2, warnings: 1, temporaryBans: 0, permanentBans: 0, riskLevel: 'moyen', status: 'surveille', lastActivityAt: iso(0, 8), firstReportedAt: iso(18), topMotifs: [{ motif: 'fraude', count: 3 }, { motif: 'contenu_inapproprie', count: 2 }], notes: 'Corrections d’exercices publiées avant les échéances.' },
  { id: 124, fullName: 'Adil Sabri', pseudonym: 'AdilSa', email: 'adil.sabri@uca.ac.ma', program: 'Cyber sécurité', school: 'FST', reportsReceived: 4, contentHidden: 2, warnings: 0, temporaryBans: 1, permanentBans: 0, riskLevel: 'moyen', status: 'banni_temporaire', lastActivityAt: iso(1, 20), firstReportedAt: iso(12), topMotifs: [{ motif: 'harcelement', count: 4 }], notes: 'Insulte directe dans une réponse technique.' },
  { id: 112, fullName: 'Mehdi Alaoui', pseudonym: 'MehdiCode', email: 'mehdi.alaoui@uca.ac.ma', program: 'Mathématiques appliquées', school: 'FSM', reportsReceived: 3, contentHidden: 1, warnings: 0, temporaryBans: 0, permanentBans: 0, riskLevel: 'faible', status: 'actif', lastActivityAt: iso(0, 14), firstReportedAt: iso(9), topMotifs: [{ motif: 'hors_sujet', count: 3 }], notes: 'Fil mal placé, sans intention.' },
  { id: 118, fullName: 'Tarik Bennis', pseudonym: 'TarikB', email: 'tarik.bennis@uca.ac.ma', program: 'Génie informatique', school: 'ENI', reportsReceived: 2, contentHidden: 1, warnings: 0, temporaryBans: 0, permanentBans: 0, riskLevel: 'faible', status: 'actif', lastActivityAt: iso(0, 9), firstReportedAt: iso(6), topMotifs: [{ motif: 'contenu_inapproprie', count: 2 }], notes: 'Capture d’écran inadaptée dans une réponse.' },
  { id: 122, fullName: 'Ali Sekkat', pseudonym: 'AliS', email: 'ali.sekkat@uca.ac.ma', program: 'Réseaux & sécurité', school: 'FSM', reportsReceived: 6, contentHidden: 3, warnings: 2, temporaryBans: 1, permanentBans: 1, riskLevel: 'critique', status: 'banni_definitif', lastActivityAt: iso(21, 17), firstReportedAt: iso(120), topMotifs: [{ motif: 'spam', count: 5 }, { motif: 'fraude', count: 1 }], notes: 'Exclu définitivement de la plateforme par la Direction.' },
  { id: 119, fullName: 'Loubna Filali', pseudonym: 'LoubnaF', email: 'loubna.filali@uca.ac.ma', program: 'Génie logiciel', school: 'EST', reportsReceived: 2, contentHidden: 0, warnings: 0, temporaryBans: 0, permanentBans: 0, riskLevel: 'faible', status: 'actif', lastActivityAt: iso(0, 16), firstReportedAt: iso(4), topMotifs: [{ motif: 'autre', count: 2 }], notes: 'Signalements abusifs, aucun manquement avéré.' },
  { id: 115, fullName: 'Rachid El Idrissi', pseudonym: 'RachidIA', email: 'rachid.el.idrissi@uca.ac.ma', program: 'Intelligence artificielle', school: 'ENI', reportsReceived: 3, contentHidden: 1, warnings: 1, temporaryBans: 0, permanentBans: 0, riskLevel: 'moyen', status: 'surveille', lastActivityAt: iso(1, 11), firstReportedAt: iso(26), topMotifs: [{ motif: 'haine', count: 2 }, { motif: 'fraude', count: 1 }], notes: 'Tension récurrente lors de la Coding League.' },
  { id: 125, fullName: 'Hamza Ouali', pseudonym: 'HamzaO', email: 'hamza.ouali@uca.ac.ma', program: 'Réseaux & sécurité', school: 'FST', reportsReceived: 8, contentHidden: 5, warnings: 3, temporaryBans: 2, permanentBans: 0, riskLevel: 'critique', status: 'banni_temporaire', lastActivityAt: iso(0, 23), firstReportedAt: iso(88), topMotifs: [{ motif: 'harcelement', count: 4 }, { motif: 'contenu_inapproprie', count: 3 }, { motif: 'haine', count: 1 }], notes: 'Réapparition après un premier bannissement de 3 jours.' },
]

export const moderationBans: ModerationBan[] = [
  { id: 801, userId: 121, userName: 'Sanaa Kettani', userPseudonym: 'SanaaK', section: 'cafe', scope: 'rubrique', type: 'temporaire', durationDays: 7, reason: 'Publication commerciale répétée dans trois rubriques.', imposedBy: 'Ghita Amrani', imposedByRole: 'moderateur', createdAt: iso(2, 10), expiresAt: iso(-5, 10), revokedAt: null, appealPath: APPEAL_PATH, notifiedAt: iso(2, 10), sourceReportId: 703 },
  { id: 802, userId: 125, userName: 'Hamza Ouali', userPseudonym: 'HamzaO', section: 'entraide', scope: 'rubrique', type: 'temporaire', durationDays: 3, reason: 'Insultes directes envers un apprenant.', imposedBy: 'Ghita Amrani', imposedByRole: 'moderateur', createdAt: iso(11, 15), expiresAt: iso(-8, 15), revokedAt: null, appealPath: APPEAL_PATH, notifiedAt: iso(11, 15), sourceReportId: 709 },
  { id: 803, userId: 124, userName: 'Adil Sabri', userPseudonym: 'AdilSa', section: 'entraide', scope: 'rubrique', type: 'temporaire', durationDays: 5, reason: 'Insulte directe répétée.', imposedBy: 'Ghita Amrani', imposedByRole: 'moderateur', createdAt: iso(4, 9), expiresAt: iso(-1, 9), revokedAt: null, appealPath: APPEAL_PATH, notifiedAt: iso(4, 9), sourceReportId: 709 },
  { id: 804, userId: 122, userName: 'Ali Sekkat', userPseudonym: 'AliS', section: 'toutes', scope: 'plateforme', type: 'definitif', durationDays: null, reason: 'Récidive : exclusions temporaires non respectées et fraude aux évaluations.', imposedBy: 'Mehdi Zouiten', imposedByRole: 'direction', createdAt: iso(21, 17), expiresAt: null, revokedAt: null, appealPath: APPEAL_PATH, notifiedAt: iso(21, 17), sourceReportId: 706 },
  { id: 805, userId: 122, userName: 'Ali Sekkat', userPseudonym: 'AliS', section: 'cafe', scope: 'rubrique', type: 'temporaire', durationDays: 2, reason: 'Recrudescence de spam.', imposedBy: 'Ghita Amrani', imposedByRole: 'moderateur', createdAt: iso(30, 11), expiresAt: iso(-28, 11), revokedAt: iso(28, 9), revokedBy: 'Mehdi Zouiten', appealPath: APPEAL_PATH, notifiedAt: iso(30, 11), sourceReportId: 703 },
  { id: 806, userId: 117, userName: 'Karim Bennani', userPseudonym: 'KarimSec', section: 'projets', scope: 'rubrique', type: 'temporaire', durationDays: 1, reason: 'Publication d’une correction après l’échéance.', imposedBy: 'Dr. Karim Idrissi', imposedByRole: 'moderateur', createdAt: iso(7, 14), expiresAt: iso(-6, 14), revokedAt: null, appealPath: APPEAL_PATH, notifiedAt: iso(7, 14), sourceReportId: 707 },
]

export const banEscalations: BanEscalation[] = [
  { id: 901, userId: 125, userName: 'Hamza Ouali', userPseudonym: 'HamzaO', section: 'entraide', requestedBy: 'Ghita Amrani', requestedAt: iso(3, 16), reason: 'Réapparition 8 jours après un bannissement de 3 jours, insultes repetitions.', evidence: '2 avertissements, 1 bannissement, 4 signalements pour harcèlement, réactivation du compte le jour même.', reportIds: [709], status: 'en_attente', priority: 'haute' },
  { id: 902, userId: 121, userName: 'Sanaa Kettani', userPseudonym: 'SanaaK', section: 'cafe', requestedBy: 'Ghita Amrani', requestedAt: iso(5, 12), reason: 'Publicité commerciale dans 3 rubriques, 9 signalements.', evidence: '6 signalements spam, 4 contenus masqués, 2 bannissements temporaires déjà servis.', reportIds: [703, 706], status: 'en_attente', priority: 'normale' },
  { id: 903, userId: 122, userName: 'Ali Sekkat', userPseudonym: 'AliS', section: 'cafe', requestedBy: 'Ghita Amrani', requestedAt: iso(24, 10), reason: 'Non-respect du bannissement temporaire et fraude aux évaluations.', evidence: '2 signalements supplémentaires après le bannissement, compte recréé sous une autre adresse.', reportIds: [706], status: 'acceptee', decidedBy: 'Mehdi Zouiten', decidedAt: iso(21, 17), decisionNote: 'Exclusion définitive prononcée. Dossier transmis au responsable pédagogique.', priority: 'haute' },
]

export const moderationActions: ModerationAction[] = [
  { id: 1001, action: 'bannir_temporaire', targetType: 'ban', targetId: 801, targetLabel: 'Sanaa Kettani · Café de la Forge · 7 j', userId: 121, userName: 'Sanaa Kettani', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Publicité commerciale répétée.', createdAt: iso(2, 10) },
  { id: 1002, action: 'escalader', targetType: 'escalation', targetId: 901, targetLabel: 'Hamza Ouali · Entraide', userId: 125, userName: 'Hamza Ouali', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Réapparition après bannissement.', createdAt: iso(3, 16) },
  { id: 1003, action: 'avertir_auteur', targetType: 'report', targetId: 708, targetLabel: 'Le prof a favoritisme', userId: 123, userName: 'Souhail Amine', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Avertissement écrit, ton à revoir.', createdAt: iso(2, 11) },
  { id: 1004, action: 'masquer_contenu', targetType: 'report', targetId: 702, targetLabel: 'Solution proposée sans indentation', userId: 118, userName: 'Tarik Bennis', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Captures d’écran inadaptées.', createdAt: iso(1, 18) },
  { id: 1005, action: 'bannir_temporaire', targetType: 'ban', targetId: 803, targetLabel: 'Adil Sabri · Entraide · 5 j', userId: 124, userName: 'Adil Sabri', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Insulte directe répétée.', createdAt: iso(4, 9) },
  { id: 1006, action: 'classer_sans_suite', targetType: 'report', targetId: 712, targetLabel: 'Merci pour l’aide', userId: 120, userName: 'Nabila Cherkaoui', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Signalement abusif.', createdAt: iso(13, 16) },
  { id: 1007, action: 'escalader', targetType: 'escalation', targetId: 902, targetLabel: 'Sanaa Kettani · Café de la Forge', userId: 121, userName: 'Sanaa Kettani', actor: 'Ghita Amrani', actorRole: 'moderateur', note: '9 signalements, récidive.', createdAt: iso(5, 12) },
  { id: 1008, action: 'delier', targetType: 'ban', targetId: 805, targetLabel: 'Ali Sekkat · Café de la Forge · 2 j', userId: 122, userName: 'Ali Sekkat', actor: 'Mehdi Zouiten', actorRole: 'direction', note: 'Bannissement levé avant exclusion définitive.', createdAt: iso(28, 9) },
  { id: 1009, action: 'bannir_temporaire', targetType: 'ban', targetId: 802, targetLabel: 'Hamza Ouali · Entraide · 3 j', userId: 125, userName: 'Hamza Ouali', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Insultes directes.', createdAt: iso(11, 15) },
  { id: 1010, action: 'masquer_contenu', targetType: 'report', targetId: 707, targetLabel: 'Je résous l’exercice 4', userId: 117, userName: 'Karim Bennani', actor: 'Dr. Karim Idrissi', actorRole: 'moderateur', note: 'Correction d’évaluation publiée.', createdAt: iso(5, 13) },
  { id: 1011, action: 'classer_sans_suite', targetType: 'report', targetId: 710, targetLabel: 'Annonce de l’atelier', userId: 116, userName: 'Sofia Lemtouni', actor: 'Mehdi Zouiten', actorRole: 'direction', note: 'Doublon avec l’annonce officielle.', createdAt: iso(8, 12) },
  { id: 1012, action: 'avertir_auteur', targetType: 'report', targetId: 705, targetLabel: 'Raccourcis vs tableaux', userId: 119, userName: 'Loubna Filali', actor: 'Ghita Amrani', actorRole: 'moderateur', note: 'Réponse floue : préciser la question avant de commenter.', createdAt: iso(3, 14) },
]

/** Rubriques et leur charge : permet au modérateur de piloter son périmètre. */
export const moderatorSections: ModeratorSection[] = FORGE_SECTIONS.map((section) => {
  const reports = moderationReports.filter((r) => r.section === section.slug)
  return {
    slug: section.slug,
    label: section.label,
    pending: reports.filter((r) => r.status === 'ouverte' || r.status === 'en_traitement').length,
    totalReports: reports.length,
    moderators: section.slug === 'entraide' || section.slug === 'cafe' ? ['Ghita Amrani'] : section.slug === 'coding-league' ? ['Omar Benali'] : section.slug === 'projets' ? ['Dr. Karim Idrissi'] : ['Centre CODE212'],
    mine: currentModerator.sections.includes(section.slug),
  }
})

/* =================================================== moule administration */

/**
 * Contexte d'administration : identite, perimetre, synchronisation UCA,
 * alertes en attente et compteurs de pilotage.
 *
 * Ces donnees sont celles que renvoie `GET /api/v1/admin/context` en mode reel.
 */
export const adminContext: AdminContext = {
  identity: {
    name: 'Walid Bouarifi',
    role: 'Directeur · Super Admin',
    roleCode: 'admin',
    scopeLabel: 'Centre CODE212 · Université Cadi Ayyad',
    isGlobalAccess: true,
    avatarKind: 'super_admin',
  },
  sync: {
    source: 'UCA',
    lastSyncAt: iso(0, 8),
    pendingRecords: 14,
    status: 'attention',
  },
  alerts: [
    { label: 'Validations', count: 3, tone: 'info' },
    { label: 'Signalements', count: 4, tone: 'warning' },
    { label: 'Escalades', count: 2, tone: 'danger' },
  ],
  counters: [
    { key: 'students', label: 'Apprenants actifs', value: 2486, to: '/admin/students' },
    { key: 'quests', label: 'Quêtes publiées', value: 18, to: '/admin/quests' },
    { key: 'validations', label: 'Validations en attente', value: 3, to: '/admin/validation' },
    { key: 'reports', label: 'Signalements ouverts', value: 4, to: '/admin/moderation' },
    { key: 'roles', label: 'Membres de l’équipe', value: 9, to: '/admin/roles' },
    { key: 'moderators', label: 'Modérateurs nommés', value: 3, to: '/admin/roles' },
  ],
  permissions: ['*'],
}
