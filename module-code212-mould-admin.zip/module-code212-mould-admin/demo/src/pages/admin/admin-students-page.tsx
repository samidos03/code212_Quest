import { useMemo, useState } from 'react'
import { Download, ShieldCheck, UserCheck, UserPlus, UserX, Users } from 'lucide-react'
import { useAdminStudents } from '@/hooks/use-api'
import { AdminPage } from '@/components/admin/admin-page'
import type { AdminKpiDef } from '@/components/admin/admin-kpi'
import { AdminFilter, AdminResultCount, AdminSearch, AdminToolbar } from '@/components/admin/admin-toolbar'
import { AdminTable, AdminTableRow } from '@/components/admin/admin-table'
import { AdminEmptyState, AdminEmptyAction } from '@/components/admin/admin-empty-state'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { formatNumber, initials } from '@/lib/utils'

/**
 * Écran « Étudiants » — construit avec le moule d'administration.
 *
 * La structure du page (bandeau de contexte, en-tête, indicateurs, barre
 * d'outils, table, note de cadrage) est celle du patron commun : seul le
 * contenu métier change d'un écran à l'autre.
 */
export function AdminStudentsPage() {
  const { data: students, isLoading } = useAdminStudents()
  const { toast } = useToast()
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')

  const list = useMemo(
    () =>
      (students ?? []).filter(
        (student) =>
          (status === 'all' || student.status === status) &&
          `${student.name} ${student.email} ${student.program}`.toLowerCase().includes(search.toLowerCase()),
      ),
    [students, search, status],
  )

  const all = students ?? []
  const countBy = (value: string) => all.filter((s) => s.status === value).length

  const kpis: AdminKpiDef[] = [
    { label: 'Comptes referrals', value: formatNumber(all.length), note: 'annuaire institutionnel', icon: Users, tone: 'primary' },
    { label: 'Actifs', value: formatNumber(countBy('Actif')), note: 'actifs sur les 30 derniers jours', icon: UserCheck, tone: 'success' },
    { label: 'En attente', value: formatNumber(countBy('En attente')), note: 'jamais connectés', icon: UserPlus, tone: 'warning' },
    { label: 'Inactifs', value: formatNumber(countBy('Inactif')), note: 'plus de 30 jours', icon: UserX, tone: 'danger' },
  ]

  const template = 'grid grid-cols-1 gap-2 lg:grid-cols-[2fr_1.4fr_1fr_1fr_auto] lg:items-center lg:gap-4'

  return (
    <AdminPage
      kicker="Communauté apprenante"
      title="Étudiants"
      description="Les comptes proviennent de l’annuaire institutionnel. Les données affichées sont celles nécessaires au suivi pédagogique."
      actions={
        <Button variant="outline" onClick={() => toast('Export généré', { description: 'Le fichier CSV sera disponible dans les downloads de l’instance.', kind: 'info' })}>
          <Download className="h-4 w-4" /> Exporter
        </Button>
      }
      kpis={kpis}
      kpiColumns={4}
      toolbar={
        <AdminToolbar>
          <AdminSearch value={search} onChange={setSearch} placeholder="Rechercher un étudiant…" />
          <AdminFilter
            label="Filtrer par statut"
            value={status}
            onValueChange={setStatus}
            options={[
              { value: 'all', label: 'Tous les statuts' },
              { value: 'Actif', label: 'Actifs' },
              { value: 'En attente', label: 'En attente' },
              { value: 'Inactif', label: 'Inactifs' },
            ]}
          />
          <AdminResultCount count={list.length} label="étudiants" />
        </AdminToolbar>
      }
      footer={
        <p>
          L’accès aux données nominatives est réservé aux rôles habilités et fait l’objet d’un journal
          d’audit. Les analyses par cohorte sont agrégées et ne permettent pas de réindividualiser un
          étudiant.
        </p>
      }
    >
      <AdminTable
        columns={[
          { key: 'student', label: 'Étudiant' },
          { key: 'program', label: 'Programme' },
          { key: 'xp', label: 'XP / Niveau' },
          { key: 'status', label: 'Statut' },
          { key: 'actions', label: '', headerClassName: 'text-right' },
        ]}
        template={template}
        loading={isLoading}
        count={list.length}
        countLabel="étudiants affichés"
        empty={
          <AdminEmptyState
            title="Aucun étudiant ne correspond"
            description="Aucun compte ne satisfait la recherche et le filtre de statut. Élargissez la sélection."
            tone="search"
            action={<AdminEmptyAction onClick={() => { setSearch(''); setStatus('all') }}>Réinitialiser les filtres</AdminEmptyAction>}
          />
        }
      >
        {list.map((student) => (
          <AdminTableRow key={student.id}>
            <div className="flex min-w-0 items-center gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-gradient text-[12px] font-bold text-white">
                {initials(student.name)}
              </span>
              <div className="min-w-0">
                <p className="truncate text-[13.5px] font-semibold text-fg">{student.name}</p>
                <p className="truncate text-[11.5px] text-fg-subtle">{student.email}</p>
              </div>
            </div>

            <span className="truncate text-[12.5px] text-fg-muted">{student.program}</span>

            <div className="flex items-center gap-2">
              <span className="font-display text-[15px] font-bold tabular-nums text-primary">{formatNumber(student.xp)}</span>
              <span className="text-[11.5px] text-fg-subtle">· niv. {student.level}</span>
            </div>

            <span>
              <Badge
                variant={student.status === 'Actif' ? 'success' : student.status === 'En attente' ? 'warning' : 'default'}
              >
                {student.status}
              </Badge>
            </span>

            <div className="flex justify-end gap-1.5">
              <Button variant="ghost" size="icon-sm" aria-label="Voir la fiche">
                <UserCheck className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon-sm" aria-label="Rôles et permissions">
                <ShieldCheck className="h-4 w-4" />
              </Button>
            </div>
          </AdminTableRow>
        ))}
      </AdminTable>
    </AdminPage>
  )
}
