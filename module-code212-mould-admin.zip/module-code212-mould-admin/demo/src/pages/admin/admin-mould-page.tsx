import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  ArrowUpRight,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  Code2,
  Filter,
  LayoutPanelTop,
  Rows3,
  Search,
  ShieldCheck,
  Users,
} from 'lucide-react'
import { AdminPage } from '@/components/admin/admin-page'
import type { AdminKpiDef } from '@/components/admin/admin-kpi'
import {
  AdminFilter,
  AdminResultCount,
  AdminSearch,
  AdminSegmented,
  AdminToolbar,
} from '@/components/admin/admin-toolbar'
import { AdminTable, AdminTableRow } from '@/components/admin/admin-table'
import { AdminEmptyState, AdminEmptyAction } from '@/components/admin/admin-empty-state'
import { AdminPanel } from '@/components/admin/admin-panel'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/toast'
import { useAdminContext } from '@/hooks/use-api'
import { cn, formatRelative, initials } from '@/lib/utils'

/**
 * Page de référence du « moule Administration ».
 *
 * Elle sert de patron de fabrication : chaque brique est présentée, expliquée
 * et mise en situation. Le bac à sable permet de voir les trois états d'une
 * liste (données, chargement, vide) sans toucher au code.
 */
export function AdminMouldPage() {
  const { data: context } = useAdminContext()
  const { toast } = useToast()

  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const [scope, setScope] = useState('all')
  const [state, setState] = useState<'donnees' | 'chargement' | 'vide'>('donnees')

  const rows = useMemo(() => {
    const base = context?.counters ?? []
    return base
      .filter((c) => status === 'all' || (status === 'alerte' && c.value > 5) || (status === 'calme' && c.value <= 5))
      .filter((c) => `${c.label} ${c.key}`.toLowerCase().includes(search.toLowerCase()))
  }, [context, search, status])

  const kpis: AdminKpiDef[] = [
    { label: 'Apprenants actifs', value: '2 486', note: '+12,8 % sur 30 jours', icon: Users, tone: 'primary' },
    { label: 'Validations en attente', value: '3', note: 'délai moyen 19 h', icon: ClipboardList, tone: 'warning' },
    { label: 'Signalements ouverts', value: '4', note: 'dont 1 hors délai de 48 h', icon: AlertTriangle, tone: 'danger' },
    { label: 'Taux de complétion', value: '68,7 %', note: '+4,1 pts', icon: BarChart3, tone: 'success' },
  ]

  const template = 'grid grid-cols-1 gap-2 lg:grid-cols-[1.8fr_1.2fr_1fr_1fr_auto] lg:items-center lg:gap-4'

  return (
    <AdminPage
      kicker="Système de conception · Référentiel"
      title="Moule d’administration"
      description="Le patron commun à tous les écrans d’administration : même bandeau de contexte, mêmes indicateurs, même barre d’outils, mêmes tables et mêmes états. Un nouvel écran se construit en remplissant les emplacements — jamais en réécrivant la structure."
      actions={
        <Button variant="outline" onClick={() => toast('Copie dans le presse-papiers', { description: 'Le squelette de page est prêt à être collé.', kind: 'info' })}>
          <Code2 className="h-4 w-4" /> Copier le squelette
        </Button>
      }
      kpis={kpis}
      kpiColumns={4}
      toolbar={
        <AdminToolbar>
          <AdminSearch value={search} onChange={setSearch} placeholder="Rechercher un compteur…" />
          <AdminFilter
            label="Filtrer par volume"
            value={status}
            onValueChange={setStatus}
            options={[
              { value: 'all', label: 'Tous les compteurs' },
              { value: 'alerte', label: 'Volume elevated' },
              { value: 'calme', label: 'Volume calme' },
            ]}
          />
          <AdminSegmented
            value={scope}
            onValueChange={setScope}
            options={[
              { value: 'all', label: 'Tous' },
              { value: 'mine', label: 'Mon périmètre' },
            ]}
          />
          <AdminResultCount count={rows.length} label="compteurs" />
        </AdminToolbar>
      }
      footer={
        <p>
          Le moule ne remplace pas le jugement de l’administrateur : il garantit seulement que
          l’information est presented de la même manière sur tous les écrans, et que rien ne
          dépend d’un écran plutôt que d’un autre.
        </p>
      }
    >
      {/* ------------------------------------------------- anatomie */}
      <AdminPanel
        kicker="Anatomie"
        title="Les cinq emplacements d’un écran d’administration"
        className="mb-5"
        action={<Badge variant="primary">Ordre imposé</Badge>}
      >
        <ol className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
          {[
            { icon: ShieldCheck, title: 'Bandeau de contexte', text: 'Qui pilote, quel périmètre, quoi en attente.' },
            { icon: LayoutPanelTop, title: 'En-tête', text: 'Chapô, titre, description, actions d’écriture.' },
            { icon: BarChart3, title: 'Indicateurs', text: 'Quatre à cinq chiffres qui résument la situation.' },
            { icon: Filter, title: 'Barre d’outils', text: 'Recherche, filtres, compteur, actions.' },
            { icon: Rows3, title: 'Contenu', text: 'Table, cartes ou graphiques — même cadre.' },
          ].map((step, index) => (
            <li key={step.title} className="rounded-xl border border-border bg-surface-2 p-3.5">
              <div className="flex items-center gap-2">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-brand-gradient text-[11px] font-bold text-white">
                  {index + 1}
                </span>
                <step.icon className="h-4 w-4 text-primary" />
              </div>
              <p className="mt-2.5 text-[13px] font-bold text-fg">{step.title}</p>
              <p className="mt-1 text-[11.5px] leading-snug text-fg-muted">{step.text}</p>
            </li>
          ))}
        </ol>
      </AdminPanel>

      {/* ------------------------------------------------- bac a sable */}
      <AdminPanel
        kicker="Bac à sable"
        title="Table de données — les trois états"
        action={
          <AdminSegmented
            value={state}
            onValueChange={(value) => setState(value as 'donnees' | 'chargement' | 'vide')}
            options={[
              { value: 'donnees', label: 'Données' },
              { value: 'chargement', label: 'Chargement' },
              { value: 'vide', label: 'Vide' },
            ]}
          />
        }
        className="mb-5"
        footer={
          <p className="text-[11.5px] text-fg-subtle">
            Le gabarit de grille est déclaré une seule fois (<code className="font-mono">template</code>) et
            propagé aux lignes : l’alignement des colonnes ne dépend plus de chaque page.
          </p>
        }
      >
        <AdminTable
          columns={[
            { key: 'label', label: 'Indicateur' },
            { key: 'key', label: 'Clé' },
            { key: 'value', label: 'Valeur' },
            { key: 'link', label: 'Destination' },
            { key: 'actions', label: '', headerClassName: 'text-right' },
          ]}
          template={template}
          loading={state === 'chargement'}
          count={state === 'donnees' ? rows.length : undefined}
          countLabel="compteurs"
          empty={
            <AdminEmptyState
              title="Aucun compteur ne correspond"
              description="Élargissez la recherche ou changez de filtre : les compteurs affichés sont ceux du périmètre courant."
              tone="search"
              action={<AdminEmptyAction onClick={() => { setSearch(''); setStatus('all') }}>Réinitialiser les filtres</AdminEmptyAction>}
            />
          }
          footer={
            state === 'donnees' && rows.length > 0 ? (
              <Button variant="ghost" size="sm" onClick={() => toast('Export CSV', { description: 'Le fichier sera disponible dans les téléchargements.', kind: 'info' })}>
                Exporter la sélection
              </Button>
            ) : null
          }
        >
          {state === 'donnees' &&
            rows.map((counter) => (
              <AdminTableRow key={counter.key}>
                <div className="flex items-center gap-3">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-surface-3 text-[11px] font-bold text-fg-muted">
                    {initials(counter.label)}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-[13.5px] font-semibold text-fg">{counter.label}</span>
                    <span className="block truncate text-[11px] text-fg-subtle">
                      {counter.to ? `→ ${counter.to}` : 'Sans destination'}
                    </span>
                  </span>
                </div>
                <span className="font-mono text-[12px] text-fg-muted">{counter.key}</span>
                <span className="font-display text-[15px] font-bold tabular-nums text-primary">
                  {counter.value.toLocaleString('fr-FR')}
                </span>
                <span className="truncate text-[12.5px] text-fg-muted">{counter.to ?? '—'}</span>
                <div className="flex justify-end gap-1.5">
                  <Button variant="ghost" size="sm">Ouvrir</Button>
                </div>
              </AdminTableRow>
            ))}
        </AdminTable>
      </AdminPanel>

      {/* ------------------------------------------------- etats */}
      <div className="grid gap-5 lg:grid-cols-2">
        <AdminPanel kicker="États" title="Liste vide et recherche infructueuse">
          <AdminEmptyState
            title="Aucun signalement en attente"
            description="La file de modération de vos rubriques est vide. Les signalements des autres rubriques restent visibles en lecture seule."
            action={<AdminEmptyAction onClick={() => toast('Journal consulté', { kind: 'info' })}>Consulter le journal</AdminEmptyAction>}
          />
        </AdminPanel>

        <AdminPanel kicker="États" title="Anomalie de synchronisation">
          <div className="flex items-start gap-3 rounded-xl border border-warning/30 bg-warning-soft/50 p-4">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
            <div className="min-w-0">
              <p className="text-[13px] font-bold text-fg">14 enregistrements UCA en attente</p>
              <p className="mt-1 text-[12px] leading-relaxed text-fg-muted">
                L’annuaire a été modifié hors de la plateforme. Les compteurs d’apprenants peuvent être
                décalés jusqu’à la prochaine synchronisation, déclenchée manuellement depuis le bandeau
                de contexte.
              </p>
              <p className="mt-2 text-[11px] text-fg-subtle">
                Dernière synchronisation {context ? formatRelative(context.sync.lastSyncAt) : '—'}.
              </p>
              <Button variant="outline" size="sm" className="mt-3">
                <ArrowUpRight className="h-3.5 w-3.5" /> Lancer la synchronisation
              </Button>
            </div>
          </div>
        </AdminPanel>
      </div>

      {/* ------------------------------------------------- squelette */}
      <AdminPanel kicker="Référence" title="Le squelette à recopier" className="mt-5">
        <pre className="overflow-x-auto rounded-xl border border-border bg-surface-2 p-4 font-mono text-[11.5px] leading-relaxed text-fg-muted">
{`import { AdminPage } from '@/components/admin/admin-page'
import { AdminKpiStrip } from '@/components/admin/admin-kpi'
import { AdminToolbar, AdminSearch, AdminFilter } from '@/components/admin/admin-toolbar'
import { AdminTable, AdminTableRow } from '@/components/admin/admin-table'
import { AdminPanel } from '@/components/admin/admin-panel'

export function MaPageAdmin() {
  const { data, isLoading } = useMaDonnee()

  return (
    <AdminPage
      kicker="Capitole"
      title="Titre de l'ecran"
      description="Ce que l'administrateur doit comprendre en une phrase."
      actions={<Button variant="outline">Exporter</Button>}
      kpis={[{ label: 'A traiter', value: String(data?.pending ?? 0), icon: ListTree }]}
      toolbar={
        <AdminToolbar>
          <AdminSearch value={search} onChange={setSearch} placeholder="Rechercher…" />
          <AdminFilter label="Statut" value={status} onValueChange={setStatus} options={options} />
          <AdminResultCount count={list.length} label="elements" />
        </AdminToolbar>
      }
    >
      <AdminTable columns={columns} template={TEMPLATE} loading={isLoading} count={list.length} countLabel="elements">
        {list.map((row) => (
          <AdminTableRow key={row.id}>…</AdminTableRow>
        ))}
      </AdminTable>
    </AdminPage>
  )
}`}
        </pre>
        <div className="mt-4 flex flex-wrap items-center gap-2 text-[11.5px] text-fg-muted">
          <Search className="h-3.5 w-3.5" />
          <span>Les primitives restent neutres : ni titre, ni libellé métier n’est codé en dur.</span>
          <CheckCircle2 className="ml-auto h-4 w-4 text-success" />
        </div>
      </AdminPanel>

      <div className={cn('mt-5 flex items-center gap-2 rounded-xl border border-border bg-surface-2 px-4 py-3 text-[11.5px] text-fg-muted')}>
        <Rows3 className="h-4 w-4 shrink-0 text-primary" />
        <span>
          Rappel : tout écran d’administration construit avec ce moule s’ouvre dans l’espace
          « Administration » et partage le bandeau de contexte, les permissions effectives et la
          synchronisation UCA.
        </span>
      </div>
    </AdminPage>
  )
}
