/**
 * Référentiel de modération — Code212 Quest.
 *
 * Un seul endroit pour les motifs de signalement, les décisions possibles,
 * la voie de recours et le calcul du niveau de risque. Ces libellés sont
 * partagés avec l'API (`apps/api/app/Support/ModerationCatalog.php`).
 */

import type {
  ModerationDecision,
  ModerationMotif,
  ModerationRiskLevel,
  ModerationSeverity,
  ModerationStatus,
} from '@/types'

/* --------------------------------------------------------------- motifs */

export interface ModerationMotifDef {
  code: ModerationMotif
  label: string
  description: string
  /** Gravité par défaut : sert au tri quand le signalement n'en précise pas. */
  defaultSeverity: ModerationSeverity
}

export const MODERATION_MOTIFS: ModerationMotifDef[] = [
  {
    code: 'harcelement',
    label: 'Harcèlement',
    description: 'Atteinte personnelle répétée, intimidation ou mise en demeure.',
    defaultSeverity: 'elevee',
  },
  {
    code: 'haine',
    label: 'Haine ou discrimination',
    description: 'Propos haineux fondés sur une caractéristique protégée.',
    defaultSeverity: 'critique',
  },
  {
    code: 'contenu_inapproprie',
    label: 'Contenu inapproprié',
    description: 'Contenu choquant ou contraire aux règles de la communauté.',
    defaultSeverity: 'moyenne',
  },
  {
    code: 'spam',
    label: 'Spam et publicité',
    description: 'Messages promotionnels répétés ou hors sujet.',
    defaultSeverity: 'faible',
  },
  {
    code: 'fraude',
    label: 'Fraude ou triche',
    description: 'Copie de travaux, usurpation d’identité ou manipulation des résultats.',
    defaultSeverity: 'elevee',
  },
  {
    code: 'hors_sujet',
    label: 'Hors sujet',
    description: 'Contenu sans lien avec la Forge ou ses rubriques.',
    defaultSeverity: 'faible',
  },
  {
    code: 'autre',
    label: 'Autre motif',
    description: 'Motif non listé, à qualifier dans la note de modération.',
    defaultSeverity: 'moyenne',
  },
]

export const MOTIF_LABEL: Record<ModerationMotif, string> = Object.fromEntries(
  MODERATION_MOTIFS.map((m) => [m.code, m.label]),
) as Record<ModerationMotif, string>

/* ------------------------------------------------------------- décisions */

export interface ModerationDecisionDef {
  code: ModerationDecision
  label: string
  description: string
  /** Le modérateur peut-il la prendre seul, ou faut-il la Direction ? */
  authority: 'moderateur' | 'direction'
  tone: 'default' | 'primary' | 'accent' | 'cyan' | 'warning' | 'danger' | 'success'
}

export const MODERATION_DECISIONS: ModerationDecisionDef[] = [
  {
    code: 'classer_sans_suite',
    label: 'Classer sans suite',
    description: 'Le signalement ne viole pas les règles : on clôt et on l’accusé de réception.',
    authority: 'moderateur',
    tone: 'default',
  },
  {
    code: 'masquer_contenu',
    label: 'Masquer le contenu',
    description: 'Le contenu est retiré de la rubrique, l’auteur est informé.',
    authority: 'moderateur',
    tone: 'warning',
  },
  {
    code: 'avertir_auteur',
    label: 'Avertir l’auteur',
    description: 'Avertissement écrit, sans sanction : première étape avant toute exclusion.',
    authority: 'moderateur',
    tone: 'accent',
  },
  {
    code: 'bannir_temporaire',
    label: 'Bannissement temporaire',
    description: 'Exclusion de la rubrique confiée, de 1 à 7 jours.',
    authority: 'moderateur',
    tone: 'danger',
  },
  {
    code: 'escalader',
    label: 'Escalader à la Direction',
    description: 'Demande de bannissement définitif : seule la Direction peut la décider.',
    authority: 'direction',
    tone: 'primary',
  },
  {
    code: 'delier',
    label: 'Délier (annuler une sanction)',
    description: 'Lever une sanctionDispatchée par erreur ou après recours.',
    authority: 'direction',
    tone: 'success',
  },
]

export const DECISION_LABEL: Record<ModerationDecision, string> = Object.fromEntries(
  MODERATION_DECISIONS.map((d) => [d.code, d.label]),
) as Record<ModerationDecision, string>

/* -------------------------------------------------------- voie de recours */

/**
 * Voie de recours communiquée à l’utilisateur dans chaque notification.
 * Elle est identique partout : c'est l'information la plus importante
 * pour que la personne sache quoi faire.
 */
export const APPEAL_PATH =
  'Pour contester cette décision, répondez à cette notification sous 7 jours ' +
  'ou écrivez à moderation@code212.ma. Votre demande est examinée par la Direction du ' +
  'Centre CODE212 et vous reçoit une réponse motivée.'

/* ----------------------------------------------------------------- risque */

export const RISK_LABEL: Record<ModerationRiskLevel, string> = {
  faible: 'Risque faible',
  moyen: 'Risque moyen',
  eleve: 'Risque élevé',
  critique: 'Risque critique',
}

export const RISK_TONE: Record<ModerationRiskLevel, 'success' | 'warning' | 'danger'> = {
  faible: 'success',
  moyen: 'warning',
  eleve: 'danger',
  critique: 'danger',
}

export const SEVERITY_LABEL: Record<ModerationSeverity, string> = {
  faible: 'Faible',
  moyenne: 'Moyenne',
  elevee: 'Élevée',
  critique: 'Critique',
}

export const SEVERITY_TONE: Record<ModerationSeverity, 'default' | 'warning' | 'danger'> = {
  faible: 'default',
  moyenne: 'warning',
  elevee: 'danger',
  critique: 'danger',
}

export const REPORT_STATUS_LABEL: Record<string, string> = {
  ouverte: 'Ouverte',
  en_traitement: 'En traitement',
  resolue: 'Résolue',
  rejetee: 'Rejetée',
  escaladee: 'Escaladée',
}

export const USER_STATUS_LABEL: Record<ModerationStatus, string> = {
  actif: 'Actif',
  surveille: 'Sous surveillance',
  banni_temporaire: 'Banni temporairement',
  banni_definitif: 'Banni définitivement',
}

/**
 * Niveau de risque d'un compte, calculé sur son historique de modération.
 *
 * Pondération : les infractions lourdes comptent double, le definitif l'emporte
 * toujours, et le nombre d'avertissements seul ne suffit pas à monter en risque.
 */
export function computeRiskLevel(input: {
  permanentBans: number
  temporaryBans: number
  reportsReceived: number
  contentHidden: number
  warnings: number
}): ModerationRiskLevel {
  const { permanentBans, temporaryBans, reportsReceived, contentHidden, warnings } = input

  if (permanentBans > 0) return 'critique'

  const score =
    reportsReceived * 2 +
    contentHidden * 3 +
    warnings * 1 +
    temporaryBans * 8

  if (score >= 30) return 'critique'
  if (score >= 18) return 'eleve'
  if (score >= 8) return 'moyen'
  return 'faible'
}

/** Statut courant d'un compte, déduit de ses sanctions. */
export function computeUserStatus(input: {
  permanentBans: number
  activeTemporaryBans: number
  riskLevel: ModerationRiskLevel
}): ModerationStatus {
  if (input.permanentBans > 0) return 'banni_definitif'
  if (input.activeTemporaryBans > 0) return 'banni_temporaire'
  if (input.riskLevel === 'eleve' || input.riskLevel === 'critique') return 'surveille'
  return 'actif'
}

/** Durée de bannissement temporaire : 1 à 7 jours, conformément à la charte. */
export const TEMPORARY_BAN_MIN_DAYS = 1
export const TEMPORARY_BAN_MAX_DAYS = 7

/** Délai au-delà duquel un signalement est considéré comme en retard (48 h). */
export const REPORT_SLA_HOURS = 48
