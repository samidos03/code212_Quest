/**
 * Établissements de rattachement des apprenants (Université Cadi Ayyad).
 * Alimente les filtres de la page « Rôles & accès ».
 */
export const SCHOOLS: Record<string, string> = {
  FSM: 'FSM — Faculté des Sciences, Marrakech',
  FST: 'FST — Faculté des Sciences et Techniques',
  ENSAM: 'ENSAM — École Nationale Supérieure d’Arts et Métiers',
  ENI: 'ENI — École Nationale d’Informatique',
  EST: 'EST — École Supérieure de Technologie',
  ENA: 'ENA — École Nationale de l’Architecture',
}

export const SCHOOL_LABEL = (code: string) => SCHOOLS[code] ?? code
