/**
 * Catalogue des permissions — Code212 Quest.
 *
 * Source de vérité côté front, alignée sur `app/Support/PermissionCatalog.php`
 * (apps/api). Chaque permission est atomique et rattachée à un module métier :
 * on ne peut donc pas active une moitié de module par accident.
 *
 * Répartition : 9 modules, 42 permissions.
 */

export type PermissionModuleCode =
  | 'moderation'
  | 'quests'
  | 'paths'
  | 'missions'
  | 'certifications'
  | 'arena'
  | 'placement'
  | 'mentorship'
  | 'roles'

export interface PermissionDef {
  key: string
  label: string
  description: string
}

export interface PermissionModuleDef {
  code: PermissionModuleCode
  label: string
  description: string
  /** Icône Lucide (nom du composant) — résolue dans le composant de matrice. */
  icon: string
  permissions: PermissionDef[]
}

export const PERMISSION_MODULES: PermissionModuleDef[] = [
  {
    code: 'moderation',
    label: 'Modération',
    description: 'Traitement des signalements, nettoyage des contenus et encadrement des modérateurs.',
    icon: 'ShieldCheck',
    permissions: [
      { key: 'moderation.reports.read', label: 'Consulter les signalements', description: 'Voir la file de modération et son historique.' },
      { key: 'moderation.content.hide', label: 'Masquer un contenu', description: 'Retirer un fil ou une réponse de la Forge.' },
      { key: 'moderation.ban.manage', label: 'Gérer les exclusions', description: 'Activer ou lever une exclusion temporaire d’un compte.' },
      { key: 'moderation.moderators.manage', label: 'Gérer les modérateurs', description: 'Nommer et révoquer les modérateurs par rubrique.' },
    ],
  },
  {
    code: 'quests',
    label: 'Quêtes & supervision',
    description: 'Concevoir les quêtes, les publier et superviser les livrables des étudiants.',
    icon: 'ScrollText',
    permissions: [
      { key: 'quests.read', label: 'Consulter les quêtes', description: 'Voir le catalogue et le contenu des quêtes.' },
      { key: 'quests.create', label: 'Créer une quête', description: 'Rédiger une quête et ses étapes.' },
      { key: 'quests.publish', label: 'Publier une quête', description: 'Rendre une quête visible par les apprenants.' },
      { key: 'quests.update', label: 'Modifier une quête', description: 'Éditer une quête déjà publiée.' },
      { key: 'quests.delete', label: 'Supprimer une quête', description: 'Retirer définitivement une quête du catalogue.' },
      { key: 'quests.submissions.validate', label: 'Valider les livrables', description: 'Noter et valider les travaux soumis.' },
    ],
  },
  {
    code: 'paths',
    label: 'Parcours de compétences',
    description: 'Structurer les parcours, leur contenu et leur ouverture aux étudiants.',
    icon: 'BookOpenCheck',
    permissions: [
      { key: 'paths.read', label: 'Consulter les parcours', description: 'Voir les parcours et leur progression.' },
      { key: 'paths.create', label: 'Créer un parcours', description: 'Composer un parcours de compétences.' },
      { key: 'paths.update', label: 'Modifier un parcours', description: 'Éditer les étapes et les ressources d’un parcours.' },
      { key: 'paths.publish', label: 'Publier un parcours', description: 'Ouvrir un parcours aux apprenants.' },
    ],
  },
  {
    code: 'missions',
    label: 'Missions',
    description: 'Créer, lancer et clôturer les missions périodiques de la plateforme.',
    icon: 'Target',
    permissions: [
      { key: 'missions.read', label: 'Consulter les missions', description: 'Voir les missions et le taux de participation.' },
      { key: 'missions.create', label: 'Créer une mission', description: 'Rédiger une mission et sa récompense.' },
      { key: 'missions.launch', label: 'Lancer une mission', description: 'Activer une mission sur une durée donnée.' },
      { key: 'missions.close', label: 'Clôturer une mission', description: 'Arrêter une mission en cours et attribuer les gains.' },
    ],
  },
  {
    code: 'certifications',
    label: 'Certifications',
    description: 'Définir, délivrer et révoquer les certifications CODE212.',
    icon: 'Award',
    permissions: [
      { key: 'certifications.read', label: 'Consulter les certifications', description: 'Voir les certifications et les critères.' },
      { key: 'certifications.create', label: 'Créer une certification', description: 'Définir un référentiel de certification.' },
      { key: 'certifications.criteria.manage', label: 'Gérer les critères', description: 'Ajouter ou retirer des critères dinition.' },
      { key: 'certifications.issue', label: 'Délivrer une certification', description: 'Décerner la certification à un apprenant.' },
      { key: 'certifications.revoke', label: 'Révoquer une certification', description: 'Retirer une certification délivrée.' },
    ],
  },
  {
    code: 'arena',
    label: 'Arène & compétitions',
    description: 'Organiser les défis chronométrés, les duels, les hackathons et la Coding League.',
    icon: 'Swords',
    permissions: [
      { key: 'arena.read', label: 'Consulter l’Arène', description: 'Voir les défis et les classements.' },
      { key: 'arena.challenges.create', label: 'Créer un défi', description: 'Paramétrer un défi chronométré, duel ou hackathon.' },
      { key: 'arena.challenges.open', label: 'Ouvrir les inscriptions', description: 'Publier un défi et ouvrir les inscriptions.' },
      { key: 'arena.challenges.arbitrate', label: 'Arbitrer un défi', description: 'Trancher les litiges et valider les résultats.' },
      { key: 'arena.challenges.close', label: 'Clôturer un défi', description: 'Fermer un défi et figer le classement.' },
      { key: 'arena.coding_league.manage', label: 'Piloter la Coding League', description: 'Organiser les étapes, équipes et calendriers de la ligue.' },
    ],
  },
  {
    code: 'placement',
    label: 'Banque de questions',
    description: 'Préparer, relire et publier les quiz de positionnement.',
    icon: 'ListChecks',
    permissions: [
      { key: 'placement.questions.read', label: 'Consulter la banque', description: 'Voir les questions et leur statut.' },
      { key: 'placement.questions.create', label: 'Rédiger une question', description: 'Ajouter une question et ses explications.' },
      { key: 'placement.questions.review', label: 'Relire une question', description: 'Vérifier la formulation et la réponse correcte.' },
      { key: 'placement.questions.publish', label: 'Publier dans le test', description: 'Rendre une question disponible pour le positionnement.' },
    ],
  },
  {
    code: 'mentorship',
    label: 'Mentorat',
    description: 'Suivre les apprenants, organiser les sessions et donner du feedback.',
    icon: 'GraduationCap',
    permissions: [
      { key: 'mentorship.learners.read', label: 'Consulter les apprenants', description: 'Voir la progression des étudiants suivis.' },
      { key: 'mentorship.sessions.manage', label: 'Organiser les sessions', description: 'Planifier les sessions de mentorat.' },
      { key: 'mentorship.feedback.write', label: 'Rédiger du feedback', description: 'Commenter les livrables et progressions.' },
    ],
  },
  {
    code: 'roles',
    label: 'Rôles & accès',
    description: 'Administrer les rôles, les permissions et les affectations de l’équipe.',
    icon: 'KeyRound',
    permissions: [
      { key: 'roles.read', label: 'Consulter les rôles', description: 'Voir les rôles et leurs permissions.' },
      { key: 'roles.create', label: 'Créer un rôle', description: 'Créer un rôle personnalisé.' },
      { key: 'roles.update', label: 'Modifier un rôle', description: 'Modifier les permissions d’un rôle.' },
      { key: 'roles.revoke', label: 'Révoquer un rôle', description: 'Suspendre un rôle et ses accès.' },
      { key: 'roles.delete', label: 'Supprimer un rôle', description: 'Supprimer un rôle personnalisé sans membre.' },
      { key: 'roles.assign', label: 'Affecter un rôle', description: 'Nommer ou retirer un membre de l’équipe.' },
    ],
  },
]

/** Index plat permission → définition (recherche O(1)). */
export const PERMISSION_INDEX: Record<string, PermissionDef & { module: PermissionModuleCode }> = Object.fromEntries(
  PERMISSION_MODULES.flatMap((module) => module.permissions.map((p) => [p.key, { ...p, module: module.code }])),
)

export const ALL_PERMISSION_KEYS = Object.keys(PERMISSION_INDEX)

/** Rubriques de La Forge susceptibles d’être confiées à un modérateur. */
export interface ForgeSectionDef {
  slug: string
  label: string
  description: string
}

export const FORGE_SECTIONS: ForgeSectionDef[] = [
  { slug: 'entraide', label: 'Entraide', description: 'Questions techniques, blocages, aide entre étudiants.' },
  { slug: 'projets', label: 'Projets', description: 'Présentations et dépôts de projets étudiants.' },
  { slug: 'coding-league', label: 'Coding League', description: 'Discussions des compétitions et équipes.' },
  { slug: 'annonces', label: 'Annonces', description: 'Informations officielles de la Forge.' },
  { slug: 'cafe', label: 'Café de la Forge', description: 'Discussion libre, hors sujets techniques.' },
]

export const FORGE_SECTION_LABEL: Record<string, string> = Object.fromEntries(
  FORGE_SECTIONS.map((s) => [s.slug, s.label]),
)

/* ------------------------------------------------- rôles système (catalogue) */

export interface SystemRoleSeed {
  code: string
  name: string
  description: string
  color: string
  /** `*` = toutes les permissions du module, sinon liste de clés. */
  permissions: string[] | '*'
}

/**
 * Les 6 rôles système demandés par la direction. Le rôle `admin` est
 * traité à part côté API (accès total, pas de ligne `role_permissions`).
 */
export const SYSTEM_ROLES: SystemRoleSeed[] = [
  {
    code: 'admin',
    name: 'Administrateur',
    description: 'Accès complet à la plateforme, y compris la gestion des rôles et des exclusions.',
    color: '#6701e6',
    permissions: '*',
  },
  {
    code: 'quest_creator',
    name: 'Créateur de quêtes',
    description: 'Conçoit des quêtes et des missions, et supervise les parcours de compétences.',
    color: '#c5027f',
    permissions: [
      'quests.read', 'quests.create', 'quests.publish', 'quests.update', 'quests.delete', 'quests.submissions.validate',
      'missions.read', 'missions.create', 'missions.launch', 'missions.close',
      'paths.create', 'paths.update',
      'roles.read',
    ],
  },
  {
    code: 'evaluator',
    name: 'Évaluateur',
    description: 'Examine les travaux soumis par les étudiants et rend un avis motivé.',
    color: '#00b8d4',
    permissions: [
      'quests.read', 'quests.submissions.validate',
      'missions.read', 'paths.read', 'certifications.read',
      'roles.read',
    ],
  },
  {
    code: 'coding_league',
    name: 'Responsable Coding League',
    description: 'Organise les compétitions, les duels, les hackathons et le calendrier de la ligue.',
    color: '#f59e0b',
    permissions: [
      'arena.read', 'arena.challenges.create', 'arena.challenges.open', 'arena.challenges.arbitrate',
      'arena.challenges.close', 'arena.coding_league.manage',
      'quests.read', 'missions.read', 'placement.questions.read',
      'roles.read',
    ],
  },
  {
    code: 'question_bank',
    name: 'Gestionnaire de la banque de questions',
    description: 'Prépare, relit et valide les quiz de positionnement des nouveaux arrivants.',
    color: '#10b981',
    permissions: [
      'placement.questions.read', 'placement.questions.create', 'placement.questions.review', 'placement.questions.publish',
      'quests.read', 'roles.read',
    ],
  },
  {
    code: 'mentor',
    name: 'Mentor',
    description: 'Accompagne les étudiants dans leur progression et anime les sessions de mentorat.',
    color: '#8b5cf6',
    permissions: [
      'quests.read', 'quests.submissions.validate', 'missions.read', 'paths.read', 'placement.questions.read',
      'mentorship.learners.read', 'mentorship.sessions.manage', 'mentorship.feedback.write',
      'roles.read',
    ],
  },
]

/** Rôle de modération : ne porte pas de permissions, mais un périmètre par rubrique. */
export const MODERATOR_ROLE_CODE = 'moderator'

/**
 * Conflits d’intérêts : un compte cumulant ces rôles perd l’accès aux
 * validations, sinon l’administrateur juge lui-même les travaux qu’il a
 * publiés et le contrôle des pairs devient décoratif.
 */
export const CONFLICTING_ROLE_PAIRS: Array<[string, string]> = [
  ['admin', 'evaluator'],
  ['admin', 'quest_creator'],
  ['quest_creator', 'evaluator'],
]
