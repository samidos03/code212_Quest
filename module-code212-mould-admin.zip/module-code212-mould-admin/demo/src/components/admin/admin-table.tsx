import { createContext, useContext } from 'react'
import type { ReactNode } from 'react'
import { AdminEmptyState, AdminTableSkeleton } from '@/components/admin/admin-empty-state'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — table de données.
 *
 * La table est le composant le plus répété des écrans d'administration. Pour
 * que l'alignement des colonnes ne dépende plus du soin apporté par chaque
 * page, le gabarit de grille est déclaré UNE fois (prop `template`) et
 * propagé aux lignes par contexte.
 *
 * Usage :
 *   <AdminTable columns={cols} template={TEMPLATE} loading={isLoading} empty={…}>
 *     {list.map((row) => (
 *       <AdminTableRow key={row.id}>…</AdminTableRow>
 *     ))}
 *   </AdminTable>
 */
export interface AdminTableColumn {
  key: string
  label: string
  /** Classes de la cellule (par exemple `text-right`). */
  className?: string
  /** Classes de l'en-tête de colonne. */
  headerClassName?: string
}

const TemplateContext = createContext<string>('')

export function AdminTable({
  columns,
  template,
  loading = false,
  empty,
  count,
  countLabel,
  footer,
  children,
  className,
}: {
  columns: AdminTableColumn[]
  /** Gabarit de grille partagé par l'en-tête et les lignes. */
  template: string
  loading?: boolean
  /** Contenu affiché quand il n'y a rien à montrer. */
  empty?: ReactNode
  count?: number
  countLabel?: string
  /** Pied de table : pagination, export, légende. */
  footer?: ReactNode
  children?: ReactNode
  className?: string
}) {
  const hasRows = Array.isArray(children) ? children.length > 0 : Boolean(children)

  return (
    <div className={cn('panel overflow-hidden', className)}>
      <TemplateContext.Provider value={template}>
        {/* en-tête */}
        <div
          className={cn(
            template,
            'hidden border-b border-border px-5 py-3 text-[10.5px] font-bold uppercase tracking-[0.14em] text-fg-subtle lg:grid',
          )}
        >
          {columns.map((column) => (
            <span key={column.key} className={cn('min-w-0', column.headerClassName)}>
              {column.label}
            </span>
          ))}
        </div>

        {/* corps */}
        {loading ? (
          <AdminTableSkeleton />
        ) : hasRows ? (
          <div className="divide-y divide-border">{children}</div>
        ) : (
          empty ?? (
            <AdminEmptyState
              title="Aucun résultat"
              description="Ajustez vos filtres ou votre recherche pour élargir la sélection."
              tone="search"
            />
          )
        )}
      </TemplateContext.Provider>

      {/* pied */}
      {(footer || (count !== undefined && countLabel)) && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border bg-surface-2 px-5 py-3">
          {count !== undefined && countLabel && (
            <p className="text-[11.5px] text-fg-subtle">
              <span className="font-bold tabular-nums text-fg-muted">{count}</span> {countLabel}
            </p>
          )}
          {footer}
        </div>
      )}
    </div>
  )
}

/**
 * Ligne de table : applique automatiquement le gabarit déclaré par la table.
 */
export function AdminTableRow({
  children,
  className,
  onClick,
}: {
  children: ReactNode
  className?: string
  onClick?: () => void
}) {
  const template = useContext(TemplateContext)

  return (
    <div
      className={cn(template, 'px-5 py-3.5', onClick && 'cursor-pointer transition-colors hover:bg-surface-2', className)}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

/**
 * Cellule de tableau : applique le `className` de la colonne correspondante.
 */
export function AdminTableCell({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return <div className={cn('min-w-0', className)}>{children}</div>
}
