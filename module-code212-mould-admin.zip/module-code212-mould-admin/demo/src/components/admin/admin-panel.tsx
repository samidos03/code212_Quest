import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — panneau de section.
 *
 * Toute zone de contenu d'un écran d'administration est un panneau : un
 * titre (avec son chapeau facultatif), une action à droite, et un corps.
 * Le même gabarit sert pour une carte, un bloc de graphique ou un tableau.
 */
export function AdminPanel({
  title,
  kicker,
  action,
  children,
  footer,
  className,
  bodyClassName,
}: {
  title?: string
  kicker?: string
  action?: ReactNode
  children: ReactNode
  footer?: ReactNode
  className?: string
  bodyClassName?: string
}) {
  return (
    <section className={cn('panel', className)}>
      {(title || action) && (
        <div className="flex items-end justify-between gap-4 px-5 pt-4">
          <div className="min-w-0">
            {kicker && <p className="kicker mb-1">{kicker}</p>}
            {title && <h2 className="text-[17px] font-bold text-fg sm:text-[18px]">{title}</h2>}
          </div>
          {action && <div className="flex shrink-0 items-center gap-2">{action}</div>}
        </div>
      )}
      <div className={cn(title || action ? 'p-5 pt-4' : 'p-5', bodyClassName)}>{children}</div>
      {footer && <div className="border-t border-border px-5 py-3">{footer}</div>}
    </section>
  )
}
