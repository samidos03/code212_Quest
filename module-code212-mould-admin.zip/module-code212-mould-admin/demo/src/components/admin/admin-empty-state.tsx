import type { ReactNode } from 'react'
import { Inbox, SearchX } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — états d'une liste.
 *
 * Tout écran d'administration doit anticiper trois situations : le chargement,
 * l'absence de résultat et l'échec. Les trois sont fournies ici pour que la
 * mise en forme ne diverge pas d'un écran à l'autre.
 */
export function AdminEmptyState({
  title,
  description,
  icon,
  action,
  tone = 'neutral',
  className,
}: {
  title: string
  description?: string
  icon?: ReactNode
  action?: ReactNode
  tone?: 'neutral' | 'search'
  className?: string
}) {
  const Icon = tone === 'search' ? SearchX : Inbox

  return (
    <div className={cn('flex flex-col items-center px-6 py-14 text-center', className)}>
      <span className="grid h-11 w-11 place-items-center rounded-2xl bg-surface-2 text-fg-subtle">
        {icon ?? <Icon className="h-5 w-5" />}
      </span>
      <p className="mt-3.5 font-display text-[17px] font-bold text-fg">{title}</p>
      {description && <p className="mt-1 max-w-md text-[13px] leading-relaxed text-fg-muted">{description}</p>}
      {action && <div className="mt-4 flex items-center gap-2">{action}</div>}
    </div>
  )
}

/**
 * Action proposée dans un état vide.
 */
export function AdminEmptyAction({
  children,
  onClick,
  variant = 'outline',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'outline' | 'primary'
}) {
  return (
    <Button variant={variant} onClick={onClick}>
      {children}
    </Button>
  )
}

/**
 * Squelettes de chargement : la forme d'un tableau.
 */
export function AdminTableSkeleton({ rows = 5, className }: { rows?: number; className?: string }) {
  return (
    <div className={cn('divide-y divide-border', className)}>
      {Array.from({ length: rows }, (_, i) => (
        <Skeleton key={i} className="h-16 w-full rounded-none" />
      ))}
    </div>
  )
}
