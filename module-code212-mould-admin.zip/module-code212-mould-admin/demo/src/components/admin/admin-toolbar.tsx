import type { ReactNode } from 'react'
import { Search } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — barre d'outils.
 *
 * Toute liste d'administration commence par la même barre : recherche à gauche,
 * filtres, puis compteur de résultats et actions à droite. Cette barre est le
 * seul endroit où l'on place des filtres : les résultats se comptent à droite,
 * les actions d'écriture à l'extrémité droite.
 */
export function AdminToolbar({
  children,
  actions,
  className,
}: {
  children?: ReactNode
  actions?: ReactNode
  className?: string
}) {
  return (
    <div className={cn('mb-4 flex flex-wrap items-center gap-3', className)}>
      {children}
      <div className="ml-auto flex flex-wrap items-center gap-2">{actions}</div>
    </div>
  )
}

/**
 * Champ de recherche avec icône et raccourci clavier.
 */
export function AdminSearch({
  value,
  onChange,
  placeholder = 'Rechercher…',
  className,
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}) {
  return (
    <div className={cn('relative min-w-[240px] flex-1', className)}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-fg-subtle" />
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="pl-9"
        aria-label={placeholder}
      />
    </div>
  )
}

/**
 * Filtre déroulant.
 */
export function AdminFilter({
  value,
  onValueChange,
  options,
  label,
  className,
}: {
  value: string
  onValueChange: (value: string) => void
  options: { value: string; label: string }[]
  label: string
  className?: string
}) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className={cn('w-[210px]', className)} aria-label={label}>
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}

/**
 * Sélecteur segmenté (2 à 3 modes d'affichage ou de périmètre).
 */
export function AdminSegmented({
  value,
  onValueChange,
  options,
  className,
}: {
  value: string
  onValueChange: (value: string) => void
  options: { value: string; label: string }[]
  className?: string
}) {
  return (
    <div className={cn('flex items-center gap-1 rounded-xl border border-border bg-surface-2 p-1', className)}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          onClick={() => onValueChange(option.value)}
          className={cn(
            'rounded-lg px-3 py-1.5 text-[12.5px] font-semibold transition-all',
            value === option.value ? 'bg-surface text-fg shadow-sm' : 'text-fg-muted hover:text-fg',
          )}
        >
          {option.label}
        </button>
      ))}
    </div>
  )
}

/**
 * Compteur de résultats.
 */
export function AdminResultCount({
  count,
  label,
  className,
}: {
  count: number
  label: string
  className?: string
}) {
  return (
    <Badge variant="primary" className={className}>
      {count} {label}
    </Badge>
  )
}

/**
 * Bouton d'action de barre d'outils (export, rafraîchissement…).
 */
export function AdminToolbarAction({
  children,
  onClick,
  variant = 'outline',
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'outline' | 'ghost' | 'primary'
}) {
  return (
    <Button variant={variant} size="sm" onClick={onClick}>
      {children}
    </Button>
  )
}
