import { AlertTriangle, CheckCircle2, Info, RefreshCw, ShieldCheck } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useAdminContext } from '@/hooks/use-api'
import { SuperAdminAvatar } from '@/components/shared/super-admin-avatar'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { cn, formatRelative, initials } from '@/lib/utils'

/**
 * Moule d'administration — bandeau de contexte.
 *
 * Première brique du patron commun à tous les écrans d'administration. Il
 * rappelle en permanence QUI pilote, QUEL périmètre s'applique, QUAND la
 * dernière synchronisation a eu lieu, et CE QUI réclame une décision.
 *
 * Objectif : aucun écran d'administration ne s'ouvre sans que l'administrateur
 * sache dans quel cadre il agit.
 */
export function AdminContextBar({ className }: { className?: string }) {
  const { data, isLoading } = useAdminContext()

  if (isLoading || !data) {
    return (
      <div className={cn('mb-5 h-[62px] animate-pulse rounded-2xl border border-border bg-surface-2', className)} />
    )
  }

  const { identity, sync, alerts } = data
  const syncTone =
    sync.status === 'echec' ? 'text-danger' : sync.status === 'attention' ? 'text-warning' : 'text-success'
  const SyncIcon = sync.status === 'ok' ? CheckCircle2 : sync.status === 'attention' ? Info : AlertTriangle

  return (
    <div
      className={cn(
        'mb-5 overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-card)]',
        className,
      )}
    >
      <div className="flex flex-wrap items-center gap-x-5 gap-y-3 px-4 py-3 sm:px-5">
        {/* identité */}
        <div className="flex min-w-0 items-center gap-3">
          {identity.avatarKind === 'super_admin' ? (
            <SuperAdminAvatar size={38} />
          ) : (
            <Avatar className="h-9 w-9 rounded-xl">
              <AvatarFallback>{initials(identity.name)}</AvatarFallback>
            </Avatar>
          )}
          <div className="min-w-0">
            <p className="truncate text-[13.5px] font-bold leading-tight text-fg">{identity.name}</p>
            <p className="truncate text-[11.5px] text-fg-subtle">
              {identity.role} · {identity.scopeLabel}
            </p>
          </div>
        </div>

        <span className="hidden h-8 w-px bg-border lg:block" />

        {/* périmètre */}
        <div className="flex min-w-0 items-center gap-2">
          <ShieldCheck className="h-4 w-4 shrink-0 text-primary" />
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-fg-subtle">Périmètre</p>
            <p className="truncate text-[12.5px] font-semibold text-fg">
              {identity.isGlobalAccess ? 'Centre entier — accès global' : identity.scopeLabel}
            </p>
          </div>
        </div>

        <span className="hidden h-8 w-px bg-border lg:block" />

        {/* synchronisation */}
        <div className="flex min-w-0 items-center gap-2">
          <SyncIcon className={cn('h-4 w-4 shrink-0', syncTone)} />
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-fg-subtle">
              Synchronisation {sync.source}
            </p>
            <p className="truncate text-[12.5px] font-semibold text-fg">
              {formatRelative(sync.lastSyncAt)}
              {sync.pendingRecords > 0 && (
                <span className="ml-1.5 font-normal text-warning">
                  · {sync.pendingRecords} enregistrement(s) en attente
                </span>
              )}
            </p>
          </div>
        </div>

        {/* alertes + action */}
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {alerts.map((alert) => (
            <Badge key={alert.label} variant={alert.tone === 'danger' ? 'danger' : alert.tone === 'warning' ? 'warning' : 'primary'}>
              {alert.label} · {alert.count}
            </Badge>
          ))}
          <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
            <RefreshCw className="h-3.5 w-3.5" /> Synchroniser
          </Button>
        </div>
      </div>
    </div>
  )
}

/**
 * Contexte d'administration, hors composant (utilisable dans un en-tête).
 */
export function useAdminContextData() {
  return useAdminContext()
}
