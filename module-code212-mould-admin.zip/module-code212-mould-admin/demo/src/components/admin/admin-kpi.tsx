import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — bandeau d'indicateurs.
 *
 * Un indicateur = un libellé, une valeur, une note (variation, délai, détail) et
 * un état visuel. Le ton (`tone`) porte la lecture : primaire = situation
 * normale, accent = à surveiller, cyan = information, warning = retard,
 * danger = action requise.
 */
export type AdminKpiTone = 'primary' | 'accent' | 'cyan' | 'warning' | 'danger' | 'success'

export interface AdminKpiDef {
  label: string
  value: string
  note?: string
  icon?: LucideIcon
  tone?: AdminKpiTone
}

const TONE_CLASS: Record<AdminKpiTone, string> = {
  primary: 'bg-primary-soft text-primary',
  accent: 'bg-accent-soft text-accent',
  cyan: 'bg-cyan-soft text-cyan-fg',
  warning: 'bg-warning-soft text-warning',
  danger: 'bg-danger-soft text-danger',
  success: 'bg-success-soft text-success',
}

export function AdminKpi({ kpi, className }: { kpi: AdminKpiDef; className?: string }) {
  const tone = kpi.tone ?? 'primary'
  const Icon = kpi.icon

  return (
    <div className={cn('panel p-3.5', className)}>
      <div className="flex items-start justify-between gap-2">
        <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-fg-subtle">{kpi.label}</p>
        {Icon && (
          <span className={cn('grid h-8 w-8 shrink-0 place-items-center rounded-lg', TONE_CLASS[tone])}>
            <Icon className="h-4 w-4" />
          </span>
        )}
      </div>
      <p className="mt-2 font-display text-[23px] font-bold leading-none text-fg">{kpi.value}</p>
      {kpi.note && <p className="mt-1.5 text-[11px] leading-snug text-fg-muted">{kpi.note}</p>}
    </div>
  )
}

/**
 * Bandeau d'indicateurs : une grille responsive de 2 à 5 colonnes.
 */
export function AdminKpiStrip({
  kpis,
  columns = 4,
  className,
}: {
  kpis: AdminKpiDef[]
  columns?: 2 | 3 | 4 | 5
  className?: string
}) {
  const grid =
    columns === 5
      ? 'grid-cols-2 lg:grid-cols-3 xl:grid-cols-5'
      : columns === 3
        ? 'grid-cols-2 lg:grid-cols-3'
        : columns === 2
          ? 'grid-cols-1 sm:grid-cols-2'
          : 'grid-cols-2 lg:grid-cols-4'

  return (
    <div className={cn('mb-5 grid gap-3', grid, className)}>
      {kpis.map((kpi) => (
        <AdminKpi key={kpi.label} kpi={kpi} />
      ))}
    </div>
  )
}
