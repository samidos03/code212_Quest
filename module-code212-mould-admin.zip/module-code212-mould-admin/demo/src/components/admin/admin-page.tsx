import type { ReactNode } from 'react'
import { PageHeader } from '@/components/shared/page-header'
import { AdminContextBar } from '@/components/admin/admin-context-bar'
import { AdminKpiStrip, type AdminKpiDef } from '@/components/admin/admin-kpi'
import { cn } from '@/lib/utils'

/**
 * Moule d'administration — cadre de page.
 *
 * Le patron commun à tous les écrans d'administration, dans un ordre fixe :
 *
 *   1. le bandeau de contexte (qui pilote, quel périmètre, quoi en attente) ;
 *   2. l'en-tête (chapô, titre, description, actions) ;
 *   3. les indicateurs ;
 *   4. la barre d'outils (recherche, filtres, compteur, actions) ;
 *   5. le contenu.
 *
 * Un nouvel écran d'administration se construit en remplissant ces emplacements,
 * jamais en réécrivant la structure.
 */
export function AdminPage({
  kicker,
  title,
  description,
  actions,
  kpis,
  kpiColumns = 4,
  toolbar,
  children,
  footer,
  context = true,
  className,
}: {
  kicker?: string
  title: string
  description?: string
  /** Actions d'écriture de l'écran (exporter, créer, synchroniser). */
  actions?: ReactNode
  /** Bandeau d'indicateurs (optionnel). */
  kpis?: AdminKpiDef[]
  kpiColumns?: 2 | 3 | 4 | 5
  /** Barre d'outils (optionnel). */
  toolbar?: ReactNode
  children: ReactNode
  /** Pied de page (notes de cadrage, légende). */
  footer?: ReactNode
  /** Masquer le bandeau de contexte (écrans d'édition plein écran). */
  context?: boolean
  className?: string
}) {
  return (
    <div className={cn('animate-[fadeUp_.18s_ease-out]', className)}>
      {context && <AdminContextBar />}

      <PageHeader kicker={kicker} title={title} description={description} actions={actions} className="mb-5" />

      {kpis && kpis.length > 0 && <AdminKpiStrip kpis={kpis} columns={kpiColumns} />}

      {toolbar}

      {children}

      {footer && (
        <footer className="mt-6 border-t border-border pt-4 text-[11.5px] leading-relaxed text-fg-subtle">
          {footer}
        </footer>
      )}
    </div>
  )
}
