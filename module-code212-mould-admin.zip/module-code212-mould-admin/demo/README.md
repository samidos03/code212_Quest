# Harnais de démonstration — module « Moule d'administration »

Mini-application contenant **uniquement** le module, pour le tester sans
l'application complète. Aucune installation de l'application n'est nécessaire.

---

## 1. Lancer

```bash
cd demo
npm install       # ou : ln -s ../../code212-quest/apps/web/node_modules node_modules
npm run dev
```

Ouvrez **http://localhost:5174**.

| Commande | Effet |
|---|---|
| `npm run dev` | Serveur de développement (port 5174) |
| `npm run build` | Build de production (typecheck + Vite) |
| `npm run preview` | Sert le build sur le port 5174 |
| `npm run typecheck` | TypeScript strict, sans émission |

> Si l'application est déjà installée sur la machine, l'installation des dépendances est inutile :
> `ln -s ../chemin/vers/apps/web/node_modules node_modules` (les versions sont identiques).

---

## 2. Deux vues

| Vue | Contenu |
|---|---|
| **Référentiel** | La page de référence : anatomie du patron, chaque brique expliquée, bac à sable (données / chargement / vide), états d'erreur, squelette de code à recopier. |
| **Écran métier** | L'écran « Étudiants » reconstruit avec le moule : bandeau de contexte, 4 indicateurs, barre d'outils, table, état vide, note de cadrage en pied de page. |

Le sélecteur en haut de page bascule de l'un à l'autre.

---

## 3. Ce que contient ce harnais

| Élément | Rôle |
|---|---|
| `src/pages/admin/admin-mould-page.tsx` | **Le référentiel**, fichier identique à celui livré dans `new-files/` |
| `src/pages/admin/admin-students-page.tsx` | **La démonstration**, fichier identique à celui livré dans `new-files/` |
| `src/components/admin/*` | Les 7 primitives du moule, identiques au livrable |
| `src/components/shared/super-admin-avatar.tsx` | Emblème du compte de direction |
| `src/lib/utils.ts` · `src/lib/permissions.ts` · `src/lib/moderation.ts` | Référentiels, identiques au livrable |
| `src/components/ui/*` | Composants partagés (bouton, dialogue, champ, select, badge, toast) |
| `src/components/shared/page-header.tsx` | En-tête de page |
| `src/services/api.ts` · `src/hooks/use-api.ts` | Façade API et hooks — identiques au livrable |
| `src/services/mock/*` | Adaptateur de démonstration : **données en mémoire** |
| `src/types/index.ts` | Types métier |
| `src/index.css` · `tailwind.config.ts` · `public/fonts` · `public/avatars` | Design system Code212 (identique à l'application) |

**La page de référence, les primitives et l'écran de démonstration sont les
fichiers exacts du livrable** : ce que vous voyez ici est ce que le stagiaire
obtiendra après intégration.

---

## 4. Ce qui fonctionne

- Le bandeau de contexte : identité, rôle, périmètre, synchronisation UCA,
  alertes, resynchronisation.
- Les 5 emplacements du patron, dans l'ordre imposé.
- Les 4 états d'indicateur (normal, à surveiller, retard, action requise).
- La barre d'outils : recherche, filtre, sélecteur segmenté, compteur.
- La table : données, chargement (squelettes), vide, recherche infructueuse,
  pied de table.
- Le panneau de section avec action à droite.
- La recherche (filtre en direct) et le compteur de résultats.
- La navigation entre les deux vues.

## 5. Ce qui est simulé

- **Les données sont en mémoire** : un rechargement de la page remet tout à l'état initial
  (bouton « Réinitialiser » en haut).
- **L'API Laravel n'est pas sollicitée.** L'adaptateur `src/services/mock` reproduit les mêmes
  règles que le backend (identité, périmètre, compteurs, alertes).
- Pour tester contre la vraie API : `VITE_USE_MOCK=false` et `VITE_API_BASE_URL=…`, puis
  `npm run dev`. Le proxy `/api` de `vite.config.ts` pointe par défaut sur
  `http://localhost:8000` (variable `VITE_API_PROXY` pour changer).

---

## 6. Vérifications passées

- `tsc -b` : aucune erreur (mode strict, `noUnusedLocals`).
- `vite build` : vert.
- Parcours navigateur automatisé : référentiel, 3 états de table, bascule vers
  l'écran métier, recherche, mobile 390 → **0 erreur console**.
