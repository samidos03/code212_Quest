# Guide d'intégration — module « Moule d'administration »

Public visé : un·e développeur·se qui reprend le paquet dans le monorepo
`code212-quest` et qui n'a pas participé à la conception du module.

Durée indicative : 1 journée d'intégration + recette.

---

## 0. Pré-requis

- Node 20+ et npm (front) ;
- PHP 8.2+ et Composer (API) ;
- l'outil `patch` pour l'application automatique des correctifs.

```bash
node -v && npm -v && php -v && composer -V && patch --version | head -1
```

---

## 1. Poser le paquet

```bash
unzip module-code212-mould-admin.zip -d /tmp/module-code212-mould-admin
cd /tmp/module-code212-mould-admin
ls new-files patches patches/nouveaux-fichiers demo
```

---

## 2. Appliquer le module

```bash
cd /chemin/vers/code212-quest
bash /tmp/module-code212-mould-admin/apply.sh .
```

Le script :

1. copie les 13 fichiers de `new-files/` — dont
   `apps/web/src/pages/admin/admin-students-page.tsx`, **écrasé
   intentionnellement** (c'est la démonstration du moule) ;
2. applique les 9 patchs de `patches/` sur les fichiers existants.

### 2.1 Sortie attendue

```
[1/2] Copie des fichiers nouveaux
      13 fichier(s) copié(s)
[2/2] Application des patchs sur les fichiers existants
      9 patch(s) appliqué(s), 0 déjà intégré(s)
```

Un `SKIP` signale un patch déjà appliqué ou un contexte qui a bougé. Dans les
deux cas, **aucun fichier `.rej` n'est laissé** : il faut alors comparer le
fichier concerné avec la version du paquet.

### 2.2 Application manuelle (sans `patch`)

- Fichiers nouveaux : copier `new-files/` à leur place, ou lire le diff
  correspondant dans `patches/nouveaux-fichiers/`.
- Fichiers modifiés : appliquer les patchs de `patches/` :

```bash
patch -p1 < /tmp/module-code212-mould-admin/patches/01-apps-web-src-types-index.patch
```

---

## 3. Front (`apps/web`)

### 3.1 Ce qui arrive

- `src/components/admin/*` — les 7 primitives du moule ;
- `src/pages/admin/admin-mould-page.tsx` — la page de référence (`/admin/mould`) ;
- `src/pages/admin/admin-students-page.tsx` — l'écran *Étudiants* reconstruit ;
- le type `AdminContext`, le jeu de données de démonstration, l'endpoint mock,
  la façade API et le hook `useAdminContext()` ;
- la rubrique « Système de conception » dans la navigation de l'espace
  Administration ;
- la route `/admin/mould` ;
- une correction du fil d'Ariane (le chemin le plus long l'emporte, pour que
  `/admin/mould` n'affiche plus « Vue d'ensemble »).

### 3.2 Vérification

```bash
cd apps/web
npm install
npm run typecheck     # aucune erreur attendue
npm run build         # build vert attendu
```

### 3.3 Smoke test manuel

```bash
npm run dev
```

- http://localhost:5173/admin/mould — le référentiel : anatomie, briques, bac à
  sable (données / chargement / vide), squelette de code ;
- http://localhost:5173/admin/students — l'écran reconstruit : bandeau de
  contexte, 4 indicateurs, barre d'outils, table, état vide ;
- le bandeau de contexte affiche « Directeur · Super Admin », le périmètre, la
  synchronisation UCA et les alertes.

> En mode démo (`VITE_USE_MOCK=true`, par défaut) les données sont en mémoire.

---

## 4. API (`apps/api`)

### 4.1 Ce qui arrive

- `app/Services/AdminWorkspaceService.php` — assemble identité, périmètre,
  synchronisation, alertes, compteurs et permissions effectives ;
- `app/Http/Resources/AdminWorkspaceResource.php` ;
- `app/Http/Controllers/Api/V1/Admin/AdminWorkspaceController.php` ;
- la route `GET /api/v1/admin/context` (groupe `/admin`, donc rôles
  `admin`/`moderator`) ;
- `tests/Feature/AdminWorkspaceContextTest.php` — 5 tests.

### 4.2 Vérification

```bash
cd apps/api
composer install
php artisan test --filter=AdminWorkspaceContextTest
```

```bash
curl -H "Authorization: Bearer $TOKEN" http://localhost:8000/api/v1/admin/context
```

Réponse attendue : `identity`, `sync`, `alerts`, `counters`, `permissions`.

> Ces tests n'ont **pas** pu être exécutés dans l'environnement de préparation
> (PHP absent). C'est le premier point à valider à l'intégration.

---

## 5. Recette

1. ouvrir `/admin/mould` : le référentiel doit s'afficher sans erreur ;
2. basculer le bac à sable sur « Chargement » puis « Vide » : la table doit
   montrer ses trois états ;
3. ouvrir `/admin/students` : bandeau de contexte, 4 indicateurs, barre
   d'outils, table alignée, état vide quand la recherche ne renvoie rien ;
4. vérifier en mobile (390 px) que le bandeau de contexte reste lisible ;
5. restreindre le rôle : sans rôle `admin`/`moderator`, `GET /admin/context`
   doit répondre **403** ;
6. rejouer `apply.sh` : aucun fichier ne doit être modifié, aucun `.rej`.

---

## 6. Étendre le moule

### 6.1 Ajouter une brique

1. créer `apps/web/src/components/admin/admin-<brique>.tsx` ;
2. l'exporter depuis le catalogue des primitives ;
3. l'ajouter au `README.md` du module et à la page `/admin/mould` (une section
   « anatomie » suffit à faire connaître la brique).

### 6.2 Migrer un écran existant

Le cas le plus courant : un écran d'administration déjà écrit à la main.

1. remplacer l'en-tête et la barre d'outils par `<AdminPage>` et
   `<AdminToolbar>` ;
2. remplacer la table par `<AdminTable>` + `<AdminTableRow>`, en déclarant le
   gabarit de grille **une seule fois** ;
3. remplacer l'état vide par `<AdminEmptyState>` ;
4. passer la note de cadrage en pied de page (`footer` du cadre).

Le résultat est mechaniquement identique d'un écran à l'autre : c'est
exactement l'objet du moule.

### 6.3 Modifier le contexte d'administration

`AdminWorkspaceService` (API) et `adminContext` (mock) portent les mêmes
champs. **Modifier les deux ensemble**, sinon l'écran diverge entre le mode
démo et le mode réel.

---

## 7. Repli

```bash
cd /chemin/vers/code212-quest
for p in /tmp/module-code212-mould-admin/patches/*.patch; do
  patch -p1 -R --batch --silent < "$p"
done
rm -rf apps/web/src/components/admin
rm -f apps/web/src/pages/admin/admin-mould-page.tsx
```

`apps/web/src/pages/admin/admin-students-page.tsx` doit être restauré depuis
le dépôt (ou depuis l'historique Git) : il est fourni en remplacement complet.

---

## 8. Points à confirmer avec la Direction

- le nombre d'indicateurs à afficher en tête d'écran (4 aujourd'hui, 5 maximum) ;
- la place de la synchronisation UCA dans le bandeau (à droite, à gauche ?) ;
- l'ordre de priorité des alertes ;
- les écrans à migrer en priorité et l'ordre de la migration ;
- la fréquence de rafraîchissement du contexte (5 minutes en cache aujourd'hui).
